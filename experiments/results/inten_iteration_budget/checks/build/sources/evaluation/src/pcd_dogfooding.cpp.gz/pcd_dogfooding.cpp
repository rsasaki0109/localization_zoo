/// PCD連番データでの Dogfooding ツール
///
/// 使い方:
///   ./pcd_dogfooding <pcd_dir> <gt_csv> [max_frames] [--force-ct-lio]
///   Methods include litamin2,gicp,small_gicp,voxel_gicp,ndt,fixed_map_ndt,kiss_icp,kiss_multi_horizon,genz_icp,lf_gicp,l_lo,adaptive_icp,d2lio,ct_voxelmap,cube_lio,r_voxelmap,degen_sense,vibration_lio,id_lio,rf_lio,bievr_lio,ua_lio,damm_loam,lodestar,terrain_rbf_lio,lidar_iba,dali_slam,intensity_flow,svn_icp,pcr_dat,small_mighty,m_gclo,quadric_lo,dilo,nhc_lio,student_t_lo,spectral_lo,gmm_lo,gnc_lo,mcc_lo,imls_slam,mesh_loam,elo,tc_lvgf,opl_lvio,v_loam15,tc_vlo,ad_vlo,tc_mvlo,tricp_lo,kc_lo,i_loam,pl_loam,inten_loam,mcgicp,icpsc,vlom,odonet,nhc_net,nn_zupt,imu_dead_reckoning,dlo,dlio,aloam,floam,lego_loam,mulls,ct_icp,ct_icp_ndt,ct_icp_ndt_keyframe,ct_lio,xicp,fast_lio2,hdl_graph_slam,vgicp_slam,suma,balm2,isc_loam,loam_livox,lio_sam,lins,fast_lio_slam,point_lio,rko_lio,fr_lio,pg_lio,clins.
///
/// pcd_dir: 00000000/cloud.pcd, 00000001/cloud.pcd, ... が並ぶディレクトリ
/// gt_csv:  lidar_pose.x,y,z,roll,pitch,yaw を含むCSV

#include "gicp/gicp_registration.h"
#include "kiss_icp/kiss_icp.h"
#include "genz_icp/genz_icp.h"
#include "lf_gicp/lf_gicp.h"
#include "l_lo/l_lo.h"
#include "adaptive_icp/adaptive_icp.h"
#include "d2lio/d2lio.h"
#include "ct_voxelmap/ct_voxelmap.h"
#include "r_voxelmap/r_voxelmap.h"
#include "damm_loam/damm_loam.h"
#include "lodestar/lodestar.h"
#include "terrain_rbf_lio/terrain_rbf_lio.h"
#include "lidar_iba/lidar_iba.h"
#include "dali_slam/dali_slam.h"
#include "intensity_flow/intensity_flow.h"
#include "svn_icp/svn_icp.h"
#include "pcr_dat/pcr_dat.h"
#include "small_mighty/small_mighty.h"
#include "m_gclo/m_gclo.h"
#include "quadric_lo/quadric_lo.h"
#include "dilo/dilo.h"
#include "dilo/dilo_paper.h"
#include "nhc_lio/nhc_lio.h"
#include "student_t_lo/student_t_lo.h"
#include "spectral_lo/spectral_lo.h"
#include "gmm_lo/gmm_lo.h"
#include "gnc_lo/gnc_lo.h"
#include "mcc_lo/mcc_lo.h"
#include "imls_slam/imls_paper_odometry.h"
#include "imls_slam/imls_slam.h"
#include "mesh_loam/mesh_loam.h"
#include "elo/elo.h"
#include "tc_lvgf/tc_lvgf.h"
#include "opl_lvio/opl_lvio.h"
#include "v_loam15/v_loam15.h"
#include "tc_vlo/tc_vlo.h"
#include "ad_vlo/ad_vlo.h"
#include "tc_mvlo/tc_mvlo.h"
#include "tricp_lo/tricp_lo.h"
#include "kc_lo/kc_lo.h"
#include "i_loam/i_loam.h"
#include "pl_loam/pl_loam.h"
#include "inten_loam/inten_loam.h"
#include "inten_loam/inten_loam_paper.h"
#include "inten_trace_jsonl.h"
#include "mcgicp/mcgicp.h"
#include "icpsc/icpsc.h"
#include "vlom/vlom.h"
#include "odonet/odonet.h"
#include "nhc_net/nhc_net.h"
#include "nn_zupt/nn_zupt.h"
#include "imu_dead_reckoning/imu_dead_reckoning.h"
#include "degen_sense/degen_sense.h"
#include "vibration_lio/vibration_lio.h"
#include "id_lio/id_lio.h"
#include "rf_lio/rf_lio.h"
#include "bievr_lio/bievr_lio.h"
#include "ua_lio/ua_lio.h"
#include "cube_lio/cube_lio.h"
#include "rko_lio/rko_lio.h"
#include "fr_lio/fr_lio.h"
#include "pg_lio/pg_lio.h"
#include "litamin2/litamin2_odometry.h"
#include "litamin2/litamin2_registration.h"
#include "ndt/ndt_registration.h"
#include "scan_context/scan_context.h"
#include "small_gicp/small_gicp_registration.h"
#include "voxel_gicp/voxel_gicp_registration.h"
#include "aloam/scan_registration.h"
#include "aloam/laser_odometry.h"
#include "aloam/laser_mapping.h"
#include "floam/floam.h"
#include "dlo/dlo.h"
#include "dlio/dlio.h"
#include "lego_loam/lego_loam.h"
#include "mulls/mulls.h"
#include "mulls/mulls_lo.h"
#include "ct_icp/ct_icp_registration.h"
#include "ct_lio/ct_lio_registration.h"
#include "xicp/xicp_registration.h"
#include "fast_lio2/fast_lio2.h"
#include "hdl_graph_slam/hdl_graph_slam.h"
#include "vgicp_slam/vgicp_slam.h"
#include "suma/suma.h"
#include "suma/suma_paper.h"
#include "balm2/balm2.h"
#include "isc_loam/isc_loam.h"
#include "loam_livox/loam_livox.h"
#include "lio_sam/lio_sam.h"
#include "lins/lins.h"
#include "fast_lio_slam/fast_lio_slam.h"
#include "point_lio/point_lio.h"
#include "clins/clins.h"

#define PCL_NO_PRECOMPILE
#include "common/range_filter.h"
#include <pcl/io/pcd_io.h>
#include <random>
#include <unordered_set>
#include <pcl/io/ply_io.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/conversions.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <Eigen/Core>
#include <Eigen/Geometry>

#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <system_error>
#include <thread>
#include <vector>

namespace fs = std::filesystem;
using Clock = std::chrono::high_resolution_clock;

// Pose of the sensor in the frame the scans and the ground truth are stored
// in (--input-sensor-pose x y z roll pitch yaw). Scans are moved into the
// sensor frame and ground-truth poses are composed with it, so methods that
// assume a sensor-centred, z-up scan (range images, ground models) see one.
// NCLT stores body-frame (z-down) scans with the HDL-32E 0.957 m above the
// body origin. Identity keeps every stored result unchanged.
Eigen::Matrix4d g_input_sensor_pose = Eigen::Matrix4d::Identity();
bool g_input_sensor_pose_set = false;

struct GTPose {
  double timestamp;
  double x, y, z, roll, pitch, yaw;

  Eigen::Matrix4d toMatrix() const {
    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    Eigen::AngleAxisd rx(roll, Eigen::Vector3d::UnitX());
    Eigen::AngleAxisd ry(pitch, Eigen::Vector3d::UnitY());
    Eigen::AngleAxisd rz(yaw, Eigen::Vector3d::UnitZ());
    T.block<3, 3>(0, 0) = (rz * ry * rx).toRotationMatrix();
    T(0, 3) = x; T(1, 3) = y; T(2, 3) = z;
    return T;
  }
  // Ground-truth pose of the sensor (--input-sensor-pose).
  Eigen::Matrix4d sensorMatrix() const {
    return g_input_sensor_pose_set ? Eigen::Matrix4d(toMatrix() * g_input_sensor_pose)
                                   : toMatrix();
  }

};

enum class TimeDomain {
  kFrameIndex,
  kSeconds,
  kUnknown,
};

std::string timeDomainName(TimeDomain domain) {
  switch (domain) {
    case TimeDomain::kFrameIndex:
      return "frame_index";
    case TimeDomain::kSeconds:
      return "seconds";
    case TimeDomain::kUnknown:
      return "unknown";
  }
  return "unknown";
}

void rotationMatrixToRpy(const Eigen::Matrix3d& R, double& roll,
                         double& pitch, double& yaw) {
  const double sinp = std::clamp(-R(2, 0), -1.0, 1.0);
  if (std::abs(sinp) >= 1.0) {
    pitch = std::copysign(M_PI / 2.0, sinp);
    roll = 0.0;
    yaw = std::atan2(-R(0, 1), R(0, 2));
  } else {
    pitch = std::asin(sinp);
    roll = std::atan2(R(2, 1), R(2, 2));
    yaw = std::atan2(R(1, 0), R(0, 0));
  }
}

double parseFiniteDoubleToken(const std::string& token,
                              const std::string& path,
                              size_t line_number,
                              size_t column_number) {
  std::istringstream ss(token);
  double value = 0.0;
  if (!(ss >> value)) {
    std::ostringstream msg;
    msg << path << ":" << line_number << ":" << column_number
        << ": expected finite numeric value, got '" << token << "'";
    throw std::runtime_error(msg.str());
  }
  ss >> std::ws;
  if (!ss.eof() || !std::isfinite(value)) {
    std::ostringstream msg;
    msg << path << ":" << line_number << ":" << column_number
        << ": expected finite numeric value, got '" << token << "'";
    throw std::runtime_error(msg.str());
  }
  return value;
}

void validateRotationMatrix(const Eigen::Matrix3d& R,
                            const std::string& path,
                            size_t line_number) {
  if (!R.allFinite()) {
    std::ostringstream msg;
    msg << path << ":" << line_number
        << ": KITTI pose rotation contains NaN or Inf";
    throw std::runtime_error(msg.str());
  }
  const double det = R.determinant();
  const double orthogonality_error =
      (R.transpose() * R - Eigen::Matrix3d::Identity()).norm();
  if (det <= 0.0 || std::abs(det - 1.0) > 1e-3 ||
      orthogonality_error > 1e-3) {
    std::ostringstream msg;
    msg << path << ":" << line_number
        << ": KITTI pose rotation is not a valid SO(3) matrix"
        << " (det=" << det
        << ", orthogonality_error=" << orthogonality_error << ")";
    throw std::runtime_error(msg.str());
  }
}

void parseKittiPoseLine(const std::string& line,
                        size_t index,
                        const std::string& path,
                        size_t line_number,
                        GTPose& pose) {
  std::istringstream ss(line);
  std::vector<double> vals;
  std::string token;
  while (ss >> token) {
    vals.push_back(
        parseFiniteDoubleToken(token, path, line_number, vals.size() + 1));
  }
  if (vals.size() != 12) {
    std::ostringstream msg;
    msg << path << ":" << line_number
        << ": expected KITTI 3x4 pose with 12 values, got "
        << vals.size();
    throw std::runtime_error(msg.str());
  }

  Eigen::Matrix3d R;
  R << vals[0], vals[1], vals[2],
       vals[4], vals[5], vals[6],
       vals[8], vals[9], vals[10];
  validateRotationMatrix(R, path, line_number);
  pose.timestamp = static_cast<double>(index);
  pose.x = vals[3];
  pose.y = vals[7];
  pose.z = vals[11];
  rotationMatrixToRpy(R, pose.roll, pose.pitch, pose.yaw);
}

struct ImuSampleCsv {
  double timestamp = 0.0;
  Eigen::Vector3d gyro = Eigen::Vector3d::Zero();
  Eigen::Vector3d accel = Eigen::Vector3d::Zero();
};

enum class FrameTimestampSource {
  kFrameTimestampCsv,
  kGraphTrajectory,
  kSampledGT,
};

struct FrameGapStats {
  bool valid = false;
  double min_gap = 0.0;
  double max_gap = 0.0;
  double mean_gap = 0.0;
  double median_gap = 0.0;
};

struct EIGEN_ALIGN16 PointXYZITime {
  PCL_ADD_POINT4D;
  float intensity;
  float time;
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

POINT_CLOUD_REGISTER_POINT_STRUCT(
    PointXYZITime,
    (float, x, x)
    (float, y, y)
    (float, z, z)
    (float, intensity, intensity)
    (float, time, time))

struct LoadedScan {
  std::vector<Eigen::Vector3d> points;
  std::vector<double> relative_times;
  bool has_per_point_time = false;
};

struct LoadedXYZI {
  Eigen::Vector3d point = Eigen::Vector3d::Zero();
  float intensity = 0.0f;
};

std::string trimCsvToken(std::string token) {
  while (!token.empty() &&
         (token.back() == '\r' || token.back() == '\n' || token.back() == ' ' ||
          token.back() == '\t')) {
    token.pop_back();
  }
  size_t begin = 0;
  while (begin < token.size() &&
         (token[begin] == ' ' || token[begin] == '\t')) {
    begin++;
  }
  return token.substr(begin);
}

std::string normalizeMethodId(std::string method) {
  method = trimCsvToken(method);
  for (char& c : method) {
    if (c == '-') c = '_';
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  }
  return method;
}

std::vector<std::string> splitMethodList(const std::string& csv) {
  std::vector<std::string> methods;
  std::istringstream ss(csv);
  std::string token;
  while (std::getline(ss, token, ',')) {
    token = normalizeMethodId(token);
    if (!token.empty()) methods.push_back(token);
  }
  return methods;
}

std::vector<double> parsePositiveDoubleList(const std::string& csv) {
  std::vector<double> values;
  std::istringstream ss(csv);
  std::string token;
  while (std::getline(ss, token, ',')) {
    token = trimCsvToken(token);
    if (token.empty()) continue;
    values.push_back(std::max(1e-6, std::stod(token)));
  }
  return values;
}

std::vector<int> parsePositiveIntList(const std::string& csv) {
  std::vector<int> values;
  std::istringstream ss(csv);
  std::string token;
  while (std::getline(ss, token, ',')) {
    token = trimCsvToken(token);
    if (token.empty()) continue;
    values.push_back(std::max(1, std::stoi(token)));
  }
  return values;
}

bool isSupportedMethod(const std::string& method) {
  return method == "litamin2" || method == "gicp" || method == "ndt" ||
         method == "fixed_map_ndt" || method == "kiss_icp" ||
         method == "kiss_multi_horizon" || method == "kiss_pose_graph" ||
         method == "kiss_pose_graph_causal" ||
         method == "genz_icp" || method == "lf_gicp" || method == "l_lo" ||
         method == "adaptive_icp" ||
         method == "small_gicp" ||
         method == "voxel_gicp" || method == "aloam" || method == "floam" ||
         method == "dlo" || method == "dlio" || method == "lego_loam" ||
         method == "mulls" || method == "ct_lio" || method == "ct_icp" ||
         method == "ct_icp_ndt" || method == "ct_icp_ndt_keyframe" ||
         method == "xicp" || method == "fast_lio2" ||
         method == "hdl_graph_slam" || method == "vgicp_slam" ||
         method == "suma" || method == "balm2" || method == "isc_loam" ||
         method == "loam_livox" || method == "lio_sam" || method == "lins" ||
         method == "fast_lio_slam" || method == "point_lio" ||
         method == "rko_lio" || method == "fr_lio" || method == "pg_lio" ||
         method == "d2lio" ||
         method == "ct_voxelmap" || method == "cube_lio" ||
         method == "r_voxelmap" || method == "degen_sense" ||
         method == "vibration_lio" || method == "id_lio" ||
         method == "rf_lio" || method == "bievr_lio" ||
         method == "ua_lio" || method == "damm_loam" ||
         method == "lodestar" || method == "terrain_rbf_lio" ||
         method == "lidar_iba" || method == "dali_slam" ||
         method == "intensity_flow" || method == "svn_icp" ||
         method == "pcr_dat" || method == "small_mighty" ||
         method == "m_gclo" || method == "quadric_lo" ||
         method == "dilo" || method == "nhc_lio" ||
         method == "student_t_lo" || method == "spectral_lo" ||
         method == "gmm_lo" || method == "gnc_lo" || method == "mcc_lo" ||
         method == "imls_slam" || method == "mesh_loam" || method == "elo" ||
         method == "tc_lvgf" || method == "opl_lvio" ||
         method == "v_loam15" || method == "tc_vlo" ||
         method == "ad_vlo" || method == "tc_mvlo" ||
         method == "tricp_lo" || method == "kc_lo" ||
         method == "i_loam" || method == "pl_loam" || method == "inten_loam" ||
         method == "mcgicp" ||          method == "icpsc" || method == "vlom" ||
         method == "odonet" || method == "nhc_net" || method == "nn_zupt" ||
         method == "imu_dead_reckoning" ||
         method == "clins";
}

bool isMethodEnabled(const std::vector<std::string>& methods,
                     const std::string& method) {
  return std::find(methods.begin(), methods.end(), method) != methods.end();
}

std::vector<GTPose> loadGTPoses(const std::string& csv_path,
                                TimeDomain* time_domain = nullptr,
                                std::string* format = nullptr) {
  if (time_domain) *time_domain = TimeDomain::kUnknown;
  if (format) *format = "unknown";

  std::vector<GTPose> poses;
  std::ifstream file(csv_path);
  if (!file.is_open()) {
    throw std::runtime_error("Failed to open GT file: " + csv_path);
  }

  std::string line;
  if (!std::getline(file, line)) return poses;
  size_t line_number = 1;

  // ヘッダからカラムインデックスを取得
  std::istringstream header_ss(line);
  std::string col;
  std::vector<std::string> cols;
  while (std::getline(header_ss, col, ',')) cols.push_back(trimCsvToken(col));

  int idx_ts = -1, idx_x = -1, idx_y = -1, idx_z = -1;
  int idx_roll = -1, idx_pitch = -1, idx_yaw = -1;
  for (size_t i = 0; i < cols.size(); i++) {
    if (cols[i] == "timestamp") idx_ts = i;
    if (cols[i] == "lidar_pose.x") idx_x = i;
    if (cols[i] == "lidar_pose.y") idx_y = i;
    if (cols[i] == "lidar_pose.z") idx_z = i;
    if (cols[i] == "lidar_pose.roll") idx_roll = i;
    if (cols[i] == "lidar_pose.pitch") idx_pitch = i;
    if (cols[i] == "lidar_pose.yaw") idx_yaw = i;
  }

  if (idx_x < 0) {
    GTPose gp;
    parseKittiPoseLine(line, poses.size(), csv_path, line_number, gp);
    poses.push_back(gp);
    while (std::getline(file, line)) {
      line_number++;
      parseKittiPoseLine(line, poses.size(), csv_path, line_number, gp);
      poses.push_back(gp);
    }
    if (time_domain) *time_domain = TimeDomain::kFrameIndex;
    if (format) *format = "kitti_3x4";
    return poses;
  }

  if (idx_y < 0 || idx_z < 0 || idx_roll < 0 || idx_pitch < 0 ||
      idx_yaw < 0) {
    std::ostringstream msg;
    msg << csv_path << ":1"
        << ": GT CSV requires lidar_pose.x/y/z/roll/pitch/yaw columns";
    throw std::runtime_error(msg.str());
  }

  while (std::getline(file, line)) {
    line_number++;
    std::istringstream ss(line);
    std::vector<std::string> vals;
    std::string token;
    while (std::getline(ss, token, ',')) vals.push_back(trimCsvToken(token));

    const int max_idx =
        std::max({idx_ts, idx_x, idx_y, idx_z, idx_roll, idx_pitch, idx_yaw});
    if (max_idx >= static_cast<int>(vals.size())) {
      std::ostringstream msg;
      msg << csv_path << ":" << line_number
          << ": expected at least " << (max_idx + 1)
          << " CSV columns, got " << vals.size();
      throw std::runtime_error(msg.str());
    }

    GTPose gp;
    gp.timestamp = idx_ts >= 0
                       ? parseFiniteDoubleToken(vals[idx_ts], csv_path,
                                                line_number, idx_ts + 1)
                       : static_cast<double>(poses.size());
    gp.x = parseFiniteDoubleToken(vals[idx_x], csv_path, line_number, idx_x + 1);
    gp.y = parseFiniteDoubleToken(vals[idx_y], csv_path, line_number, idx_y + 1);
    gp.z = parseFiniteDoubleToken(vals[idx_z], csv_path, line_number, idx_z + 1);
    gp.roll =
        parseFiniteDoubleToken(vals[idx_roll], csv_path, line_number, idx_roll + 1);
    gp.pitch = parseFiniteDoubleToken(vals[idx_pitch], csv_path, line_number,
                                      idx_pitch + 1);
    gp.yaw =
        parseFiniteDoubleToken(vals[idx_yaw], csv_path, line_number, idx_yaw + 1);
    poses.push_back(gp);
  }
  if (time_domain) {
    *time_domain = idx_ts >= 0 ? TimeDomain::kSeconds : TimeDomain::kFrameIndex;
  }
  if (format) *format = "csv_lidar_pose";
  return poses;
}

std::vector<Eigen::Matrix4d> loadKittiPoseMatrices(
    const std::string& pose_path) {
  std::ifstream file(pose_path);
  if (!file.is_open()) {
    throw std::runtime_error("Failed to open external pose file: " + pose_path);
  }

  std::vector<Eigen::Matrix4d> poses;
  std::string line;
  std::size_t line_number = 0;
  while (std::getline(file, line)) {
    ++line_number;
    if (line.find_first_not_of(" \t\r\n") == std::string::npos) continue;
    std::istringstream stream(line);
    std::vector<double> values;
    std::string token;
    while (stream >> token) {
      values.push_back(parseFiniteDoubleToken(
          token, pose_path, line_number, values.size() + 1));
    }
    if (values.size() != 12) {
      std::ostringstream message;
      message << pose_path << ":" << line_number
              << ": expected KITTI 3x4 pose with 12 values, got "
              << values.size();
      throw std::runtime_error(message.str());
    }
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    for (int row = 0; row < 3; ++row) {
      for (int column = 0; column < 4; ++column) {
        pose(row, column) =
            values[static_cast<std::size_t>(row * 4 + column)];
      }
    }
    validateRotationMatrix(pose.block<3, 3>(0, 0), pose_path, line_number);
    poses.push_back(pose);
  }
  if (poses.empty()) {
    throw std::runtime_error("No poses loaded from external pose file: " +
                             pose_path);
  }
  return poses;
}

std::vector<ImuSampleCsv> loadImuCsv(const std::string& csv_path) {
  std::vector<ImuSampleCsv> samples;
  std::ifstream file(csv_path);
  if (!file.is_open()) return samples;

  std::string line;
  if (!std::getline(file, line)) return samples;

  std::istringstream header_ss(line);
  std::string col;
  std::vector<std::string> cols;
  while (std::getline(header_ss, col, ',')) cols.push_back(trimCsvToken(col));

  int idx_stamp = -1;
  int idx_gx = -1, idx_gy = -1, idx_gz = -1;
  int idx_ax = -1, idx_ay = -1, idx_az = -1;
  for (size_t i = 0; i < cols.size(); i++) {
    if (cols[i] == "stamp") idx_stamp = i;
    if (cols[i] == "angular_vel.x") idx_gx = i;
    if (cols[i] == "angular_vel.y") idx_gy = i;
    if (cols[i] == "angular_vel.z") idx_gz = i;
    if (cols[i] == "linear_acc.x") idx_ax = i;
    if (cols[i] == "linear_acc.y") idx_ay = i;
    if (cols[i] == "linear_acc.z") idx_az = i;
  }

  while (std::getline(file, line)) {
    std::istringstream ss(line);
    std::vector<std::string> vals;
    std::string token;
    while (std::getline(ss, token, ',')) vals.push_back(trimCsvToken(token));

    if (idx_stamp < 0 || idx_az < 0 || idx_stamp >= static_cast<int>(vals.size()) ||
        idx_az >= static_cast<int>(vals.size())) {
      continue;
    }

    ImuSampleCsv sample;
    sample.timestamp = std::stod(vals[idx_stamp]);
    sample.gyro = Eigen::Vector3d(std::stod(vals[idx_gx]), std::stod(vals[idx_gy]),
                                  std::stod(vals[idx_gz]));
    sample.accel = Eigen::Vector3d(std::stod(vals[idx_ax]), std::stod(vals[idx_ay]),
                                   std::stod(vals[idx_az]));
    samples.push_back(sample);
  }

  return samples;
}

fs::path resolvePointCloudPath(const std::string& requested_path) {
  const fs::path requested(requested_path);
  const fs::path parent = requested.parent_path();
  if (requested.filename() == "cloud.pcd" && parent.extension() == ".bin" &&
      fs::is_regular_file(parent)) {
    return parent;
  }
  return requested;
}

bool loadKittiBin(const fs::path& path,
                  pcl::PointCloud<pcl::PointXYZI>* cloud) {
  std::error_code size_error;
  const auto byte_count = fs::file_size(path, size_error);
  constexpr std::uintmax_t kBytesPerPoint = 4 * sizeof(float);
  if (size_error || byte_count == 0 || byte_count % kBytesPerPoint != 0) {
    std::cerr << "Invalid KITTI point-cloud file: " << path << "\n";
    return false;
  }

  std::ifstream input(path, std::ios::binary);
  if (!input) return false;

  cloud->clear();
  cloud->reserve(static_cast<std::size_t>(byte_count / kBytesPerPoint));
  std::array<float, 4> values{};
  while (input.read(reinterpret_cast<char*>(values.data()),
                    static_cast<std::streamsize>(kBytesPerPoint))) {
    pcl::PointXYZI point;
    point.x = values[0];
    point.y = values[1];
    point.z = values[2];
    point.intensity = values[3];
    cloud->push_back(point);
  }
  if (!input.eof()) return false;
  cloud->width = static_cast<std::uint32_t>(cloud->size());
  cloud->height = 1;
  cloud->is_dense = false;
  return true;
}

// Sensor-level elevation correction applied to every loaded scan before
// downsampling (--input-vertical-angle-correction-deg). KITTI's HDL-64E needs
// +0.205 deg; upstream KISS-ICP and CT-ICP apply it in their KITTI loaders.
// Default 0 keeps every stored result unchanged.
double g_input_vertical_angle_correction_rad = 0.0;
// Shared loader range cap (--input-max-range-m). Upstream KISS-ICP keeps
// returns up to 100 m; the historical default here is 80 m.
double g_input_max_range_m = 80.0;
// Shared loader near-range cut applied to every loaded scan before any other
// correction (--input-min-range-m, sensor frame). NCLT scans show a person
// walking about 2.4 m behind the sensor; 0 keeps every stored result.
double g_input_min_range_m = 0.0;
// Per-point time from the azimuth for scans without a time field
// (--input-azimuth-time). KITTI .bin scans store points ring by ring, so the
// index fallback (j / N) follows the elevation, not the sweep; this uses the
// sweep angle as in KISS-ICP's KITTI loader, 0.5 * (1 - atan2(y, x) / pi).
bool g_input_azimuth_time = false;

void assignAzimuthTimes(LoadedScan* scan) {
  const double pi = std::acos(-1.0);
  scan->relative_times.clear();
  scan->relative_times.reserve(scan->points.size());
  for (const auto& p : scan->points) {
    scan->relative_times.push_back(0.5 * (1.0 - std::atan2(p.y(), p.x()) / pi));
  }
  scan->has_per_point_time = !scan->relative_times.empty();
}

template <typename PointT>
void applyInputSensorPose(pcl::PointCloud<PointT>* cloud) {
  if (!g_input_sensor_pose_set) return;
  const Eigen::Matrix3d Rt = g_input_sensor_pose.block<3, 3>(0, 0).transpose();
  const Eigen::Vector3d t = g_input_sensor_pose.block<3, 1>(0, 3);
  for (auto& point : cloud->points) {
    const Eigen::Vector3d q = Rt * (Eigen::Vector3d(point.x, point.y, point.z) - t);
    point.x = static_cast<float>(q.x());
    point.y = static_cast<float>(q.y());
    point.z = static_cast<float>(q.z());
  }
}

template <typename PointT>
void applyInputVerticalAngleCorrection(pcl::PointCloud<PointT>* cloud) {
  applyInputSensorPose(cloud);
  localization_zoo::preprocessing::filterMinRange(*cloud, g_input_min_range_m);
  const double angle = g_input_vertical_angle_correction_rad;
  if (angle == 0.0) return;
  const double sin_angle = std::sin(angle);
  const double cos_angle = std::cos(angle);
  for (auto& point : cloud->points) {
    const double horizontal = std::hypot(point.x, point.y);
    if (!(horizontal > 1e-12)) continue;
    const double corrected_horizontal =
        horizontal * cos_angle - point.z * sin_angle;
    const double scale = corrected_horizontal / horizontal;
    point.z = static_cast<float>(point.z * cos_angle + horizontal * sin_angle);
    point.x = static_cast<float>(point.x * scale);
    point.y = static_cast<float>(point.y * scale);
  }
}

std::vector<Eigen::Vector3d> loadPCD(const std::string& path, double leaf = 0.5) {
  const fs::path resolved_path = resolvePointCloudPath(path);
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
  if (resolved_path.extension() == ".bin") {
    pcl::PointCloud<pcl::PointXYZI> cloud_xyzi;
    if (!loadKittiBin(resolved_path, &cloud_xyzi)) return {};
    cloud->reserve(cloud_xyzi.size());
    for (const auto& point : cloud_xyzi) {
      cloud->push_back(pcl::PointXYZ(point.x, point.y, point.z));
    }
  } else if (pcl::io::loadPCDFile<pcl::PointXYZ>(
                 resolved_path.string(), *cloud) == -1) {
    return {};
  }
  applyInputVerticalAngleCorrection(cloud.get());

  if (!(leaf > 1e-9)) {
    std::vector<Eigen::Vector3d> points;
    points.reserve(cloud->size());
    for (auto& p : cloud->points) {
      double r = std::sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
      if (r > 1.0 && r < g_input_max_range_m) points.emplace_back(p.x, p.y, p.z);
    }
    return points;
  }

  // ダウンサンプリング
  pcl::VoxelGrid<pcl::PointXYZ> vg;
  vg.setInputCloud(cloud);
  vg.setLeafSize(leaf, leaf, leaf);
  pcl::PointCloud<pcl::PointXYZ> filtered;
  vg.filter(filtered);

  std::vector<Eigen::Vector3d> points;
  for (auto& p : filtered) {
    double r = std::sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
    if (r > 1.0 && r < g_input_max_range_m)
      points.emplace_back(p.x, p.y, p.z);
  }
  return points;
}

std::vector<Eigen::Vector3d> voxelDownsamplePoints(
    const std::vector<Eigen::Vector3d>& points, double leaf) {
  if (!(leaf > 1e-9) || points.empty()) return points;
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(
      new pcl::PointCloud<pcl::PointXYZ>);
  cloud->reserve(points.size());
  for (const auto& point : points) {
    cloud->push_back(pcl::PointXYZ(
        static_cast<float>(point.x()), static_cast<float>(point.y()),
        static_cast<float>(point.z())));
  }
  pcl::VoxelGrid<pcl::PointXYZ> voxel_grid;
  voxel_grid.setInputCloud(cloud);
  voxel_grid.setLeafSize(leaf, leaf, leaf);
  pcl::PointCloud<pcl::PointXYZ> filtered;
  voxel_grid.filter(filtered);

  std::vector<Eigen::Vector3d> downsampled;
  downsampled.reserve(filtered.size());
  for (const auto& point : filtered) {
    downsampled.emplace_back(point.x, point.y, point.z);
  }
  return downsampled;
}

std::vector<Eigen::Vector3d> filterPointRange(
    const std::vector<Eigen::Vector3d>& points, double min_range,
    double max_range) {
  std::vector<Eigen::Vector3d> filtered;
  filtered.reserve(points.size());
  for (const auto& point : points) {
    const double range = point.norm();
    if (range > min_range && range < max_range) {
      filtered.push_back(point);
    }
  }
  return filtered;
}

std::vector<Eigen::Vector3d> loadPLYMap(const std::string& path,
                                        double leaf = 0.5) {
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
  if (pcl::io::loadPLYFile<pcl::PointXYZ>(path, *cloud) == -1) return {};

  pcl::PointCloud<pcl::PointXYZ>::Ptr selected = cloud;
  pcl::PointCloud<pcl::PointXYZ> filtered;
  if (leaf > 1e-9) {
    pcl::VoxelGrid<pcl::PointXYZ> vg;
    vg.setInputCloud(cloud);
    vg.setLeafSize(leaf, leaf, leaf);
    vg.filter(filtered);
    selected.reset(new pcl::PointCloud<pcl::PointXYZ>(filtered));
  }

  std::vector<Eigen::Vector3d> points;
  points.reserve(selected->size());
  for (const auto& point : selected->points) {
    if (std::isfinite(point.x) && std::isfinite(point.y) &&
        std::isfinite(point.z)) {
      points.emplace_back(point.x, point.y, point.z);
    }
  }
  return points;
}

std::vector<Eigen::Vector3d> limitPoints(const std::vector<Eigen::Vector3d>& points,
                                         size_t max_points) {
  if (points.size() <= max_points) return points;
  std::vector<Eigen::Vector3d> limited;
  limited.reserve(max_points);
  double step = static_cast<double>(points.size()) / max_points;
  for (size_t i = 0; i < max_points; i++) {
    size_t idx = std::min(static_cast<size_t>(i * step), points.size() - 1);
    limited.push_back(points[idx]);
  }
  return limited;
}

std::vector<LoadedXYZI> loadPCDXYZI(const std::string& path, double leaf = 0.5) {
  const fs::path resolved_path = resolvePointCloudPath(path);
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZI>);
  if (resolved_path.extension() == ".bin") {
    if (!loadKittiBin(resolved_path, cloud.get())) return {};
  } else if (pcl::io::loadPCDFile<pcl::PointXYZI>(
                 resolved_path.string(), *cloud) == -1) {
    return {};
  }
  applyInputVerticalAngleCorrection(cloud.get());

  pcl::PointCloud<pcl::PointXYZI>::Ptr selected = cloud;
  pcl::PointCloud<pcl::PointXYZI> filtered;
  if (leaf > 1e-9) {
    pcl::VoxelGrid<pcl::PointXYZI> vg;
    vg.setInputCloud(cloud);
    vg.setLeafSize(leaf, leaf, leaf);
    vg.setDownsampleAllData(true);
    vg.filter(filtered);
    selected.reset(new pcl::PointCloud<pcl::PointXYZI>(filtered));
  }

  std::vector<LoadedXYZI> points;
  points.reserve(selected->size());
  for (const auto& p : selected->points) {
    if (!std::isfinite(p.x) || !std::isfinite(p.y) ||
        !std::isfinite(p.z) || !std::isfinite(p.intensity)) {
      continue;
    }
    const double r = std::sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
    if (r <= 1.0 || r >= g_input_max_range_m) continue;
    points.push_back({Eigen::Vector3d(p.x, p.y, p.z), p.intensity});
  }
  return points;
}

std::vector<LoadedXYZI> limitLoadedXYZI(const std::vector<LoadedXYZI>& points,
                                        size_t max_points) {
  if (points.size() <= max_points) return points;
  std::vector<LoadedXYZI> limited;
  limited.reserve(max_points);
  double step = static_cast<double>(points.size()) / max_points;
  for (size_t i = 0; i < max_points; i++) {
    size_t idx = std::min(static_cast<size_t>(i * step), points.size() - 1);
    limited.push_back(points[idx]);
  }
  return limited;
}

void normalizeRelativeTimes(std::vector<double>& relative_times) {
  if (relative_times.empty()) return;

  auto [min_it, max_it] =
      std::minmax_element(relative_times.begin(), relative_times.end());
  double min_time = *min_it;
  double max_time = *max_it;
  if (max_time <= min_time + 1e-9) {
    const size_t denom = relative_times.size() > 1 ? relative_times.size() - 1 : 1;
    for (size_t i = 0; i < relative_times.size(); i++) {
      relative_times[i] = static_cast<double>(i) / denom;
    }
    return;
  }

  for (double& t : relative_times) {
    t = (t - min_time) / (max_time - min_time);
  }
}

LoadedScan limitLoadedScan(const LoadedScan& scan, size_t max_points) {
  if (scan.points.size() <= max_points) return scan;

  LoadedScan limited;
  limited.has_per_point_time = scan.has_per_point_time;
  limited.points.reserve(max_points);
  if (scan.has_per_point_time) limited.relative_times.reserve(max_points);

  double step = static_cast<double>(scan.points.size()) / max_points;
  for (size_t i = 0; i < max_points; i++) {
    size_t idx = std::min(static_cast<size_t>(i * step), scan.points.size() - 1);
    limited.points.push_back(scan.points[idx]);
    if (scan.has_per_point_time) {
      limited.relative_times.push_back(scan.relative_times[idx]);
    }
  }
  return limited;
}

LoadedScan loadTimedPCD(const std::string& path, double leaf = 0.5,
                        bool filter_range = true) {
  LoadedScan scan;
  const fs::path resolved_path = resolvePointCloudPath(path);
  if (resolved_path.extension() == ".bin") {
    scan.points = loadPCD(resolved_path.string(), leaf);
    if (g_input_azimuth_time) assignAzimuthTimes(&scan);
    return scan;
  }

  pcl::PCLPointCloud2 raw_cloud;
  if (pcl::io::loadPCDFile(resolved_path.string(), raw_cloud) == -1) return scan;

  bool has_time_field = false;
  for (const auto& field : raw_cloud.fields) {
    if (field.name == "time") {
      has_time_field = true;
      break;
    }
  }
  if (!has_time_field) {
    scan.points = loadPCD(resolved_path.string(), leaf);
    if (g_input_azimuth_time) assignAzimuthTimes(&scan);
    return scan;
  }

  pcl::PointCloud<PointXYZITime>::Ptr cloud(new pcl::PointCloud<PointXYZITime>);
  pcl::fromPCLPointCloud2(raw_cloud, *cloud);
  applyInputVerticalAngleCorrection(cloud.get());

  pcl::PointCloud<PointXYZITime>::Ptr filtered = cloud;
  if (leaf > 1e-9) {
    filtered.reset(new pcl::PointCloud<PointXYZITime>);
    pcl::VoxelGrid<PointXYZITime> vg;
    vg.setInputCloud(cloud);
    vg.setLeafSize(leaf, leaf, leaf);
    vg.setDownsampleAllData(true);
    vg.filter(*filtered);
  }

  scan.points.reserve(filtered->size());
  scan.relative_times.reserve(filtered->size());
  for (const auto& p : filtered->points) {
    if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z) ||
        !std::isfinite(p.time)) {
      continue;
    }
    double r = std::sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
    if (filter_range && (r <= 1.0 || r >= g_input_max_range_m)) continue;

    scan.points.emplace_back(p.x, p.y, p.z);
    scan.relative_times.push_back(p.time);
  }

  scan.has_per_point_time = !scan.relative_times.empty();
  normalizeRelativeTimes(scan.relative_times);
  return scan;
}

pcl::PointCloud<pcl::PointXYZI>::Ptr toPclXYZICloud(
    const std::vector<Eigen::Vector3d>& points) {
  auto cloud = pcl::PointCloud<pcl::PointXYZI>::Ptr(
      new pcl::PointCloud<pcl::PointXYZI>);
  cloud->reserve(points.size());
  for (const auto& p : points) {
    pcl::PointXYZI pt;
    pt.x = static_cast<float>(p.x());
    pt.y = static_cast<float>(p.y());
    pt.z = static_cast<float>(p.z());
    pt.intensity = 0.0f;
    cloud->push_back(pt);
  }
  return cloud;
}

pcl::PointCloud<pcl::PointXYZI>::Ptr toPclXYZICloud(
    const std::vector<LoadedXYZI>& points) {
  auto cloud = pcl::PointCloud<pcl::PointXYZI>::Ptr(
      new pcl::PointCloud<pcl::PointXYZI>);
  cloud->reserve(points.size());
  for (const auto& p : points) {
    pcl::PointXYZI pt;
    pt.x = static_cast<float>(p.point.x());
    pt.y = static_cast<float>(p.point.y());
    pt.z = static_cast<float>(p.point.z());
    pt.intensity = p.intensity;
    cloud->push_back(pt);
  }
  return cloud;
}

bool parseNonNegativeIntegerBasename(const fs::path& path,
                                     unsigned long long* value) {
  const std::string name =
      path.extension() == ".bin" ? path.stem().string()
                                 : path.filename().string();
  if (name.empty()) return false;

  unsigned long long parsed = 0;
  for (unsigned char c : name) {
    if (!std::isdigit(c)) return false;
    const unsigned long long digit = static_cast<unsigned long long>(c - '0');
    if (parsed >
        (std::numeric_limits<unsigned long long>::max() - digit) / 10) {
      return false;
    }
    parsed = parsed * 10 + digit;
  }
  if (value) *value = parsed;
  return true;
}

std::vector<std::string> listPCDDirs(const std::string& dir) {
  std::vector<std::string> dirs;
  for (auto& entry : fs::directory_iterator(dir)) {
    if (entry.is_directory()) {
      auto pcd_path = entry.path() / "cloud.pcd";
      if (fs::exists(pcd_path)) dirs.push_back(entry.path().string());
    } else if (entry.is_regular_file() && entry.path().extension() == ".bin") {
      dirs.push_back(entry.path().string());
    }
  }
  bool all_numeric = !dirs.empty();
  for (const auto& pcd_dir : dirs) {
    all_numeric =
        all_numeric && parseNonNegativeIntegerBasename(fs::path(pcd_dir), nullptr);
  }
  if (all_numeric) {
    std::sort(dirs.begin(), dirs.end(),
              [](const std::string& lhs, const std::string& rhs) {
                unsigned long long lhs_frame = 0;
                unsigned long long rhs_frame = 0;
                parseNonNegativeIntegerBasename(fs::path(lhs), &lhs_frame);
                parseNonNegativeIntegerBasename(fs::path(rhs), &rhs_frame);
                if (lhs_frame != rhs_frame) return lhs_frame < rhs_frame;
                return lhs < rhs;
              });
  } else {
    std::sort(dirs.begin(), dirs.end());
  }
  return dirs;
}

std::vector<double> loadFrameTimestampsFromGraph(
    const std::vector<std::string>& pcd_dirs) {
  std::vector<double> timestamps;
  timestamps.reserve(pcd_dirs.size());

  for (const auto& dir : pcd_dirs) {
    fs::path trajectory_csv = fs::path(dir) / "trajectory.csv";
    if (!fs::exists(trajectory_csv)) {
      return {};
    }

    std::ifstream file(trajectory_csv);
    std::string line;
    if (!std::getline(file, line) || !std::getline(file, line)) {
      return {};
    }

    std::istringstream ss(line);
    std::vector<std::string> vals;
    std::string token;
    while (std::getline(ss, token, ',')) vals.push_back(trimCsvToken(token));
    if (vals.size() < 2) return {};
    timestamps.push_back(std::stod(vals[1]));
  }

  return timestamps;
}

std::vector<double> loadFrameTimestampsFromCsv(const std::string& dir,
                                               size_t expected_frames) {
  fs::path csv_path = fs::path(dir) / "frame_timestamps.csv";
  if (!fs::exists(csv_path)) return {};

  std::ifstream file(csv_path);
  std::string line;
  if (!std::getline(file, line)) return {};

  std::istringstream header_ss(line);
  std::string col;
  std::vector<std::string> cols;
  while (std::getline(header_ss, col, ',')) cols.push_back(trimCsvToken(col));

  int idx_timestamp = -1;
  for (size_t i = 0; i < cols.size(); i++) {
    if (cols[i] == "timestamp") {
      idx_timestamp = static_cast<int>(i);
      break;
    }
  }
  if (idx_timestamp < 0) idx_timestamp = cols.size() > 1 ? 1 : 0;

  std::vector<double> timestamps;
  timestamps.reserve(expected_frames);
  while (std::getline(file, line) && timestamps.size() < expected_frames) {
    std::istringstream ss(line);
    std::vector<std::string> vals;
    std::string token;
    while (std::getline(ss, token, ',')) vals.push_back(trimCsvToken(token));
    if (idx_timestamp >= static_cast<int>(vals.size())) continue;
    timestamps.push_back(std::stod(vals[idx_timestamp]));
  }

  if (timestamps.size() != expected_frames) return {};
  return timestamps;
}

std::string resolveKittiRawRgbPath(const std::string& rgb_root,
                                   const std::string& camera_subdir,
                                   int global_frame_index) {
  char name[32];
  std::snprintf(name, sizeof(name), "%010d.png", global_frame_index);
  return (fs::path(rgb_root) / camera_subdir / name).string();
}

FrameGapStats computeFrameGapStats(const std::vector<double>& frame_timestamps) {
  FrameGapStats stats;
  if (frame_timestamps.size() < 2) return stats;

  std::vector<double> gaps;
  gaps.reserve(frame_timestamps.size() - 1);
  for (size_t i = 1; i < frame_timestamps.size(); i++) {
    gaps.push_back(std::max(frame_timestamps[i] - frame_timestamps[i - 1], 0.0));
  }

  auto sorted_gaps = gaps;
  std::sort(sorted_gaps.begin(), sorted_gaps.end());

  stats.valid = true;
  stats.min_gap = *std::min_element(gaps.begin(), gaps.end());
  stats.max_gap = *std::max_element(gaps.begin(), gaps.end());
  double sum = 0.0;
  for (double gap : gaps) sum += gap;
  stats.mean_gap = sum / gaps.size();
  const size_t mid = sorted_gaps.size() / 2;
  if (sorted_gaps.size() % 2 == 0) {
    stats.median_gap = 0.5 * (sorted_gaps[mid - 1] + sorted_gaps[mid]);
  } else {
    stats.median_gap = sorted_gaps[mid];
  }
  return stats;
}

bool isNearInteger(double value) {
  return std::isfinite(value) && std::abs(value - std::round(value)) <= 1e-6;
}

bool allFiniteIntegers(const std::vector<double>& values) {
  if (values.empty()) return false;
  return std::all_of(values.begin(), values.end(), isNearInteger);
}

bool allGTTimestampsFiniteIntegers(const std::vector<GTPose>& gt_poses_raw) {
  if (gt_poses_raw.empty()) return false;
  return std::all_of(gt_poses_raw.begin(), gt_poses_raw.end(),
                     [](const GTPose& pose) {
                       return isNearInteger(pose.timestamp);
                     });
}

void requireStrictlyIncreasing(const std::vector<double>& values,
                               const std::string& label) {
  if (values.empty()) {
    throw std::runtime_error(label + " is empty");
  }
  for (size_t i = 0; i < values.size(); i++) {
    if (!std::isfinite(values[i])) {
      std::ostringstream msg;
      msg << label << " contains NaN/Inf at index " << i;
      throw std::runtime_error(msg.str());
    }
    if (i > 0 && values[i] <= values[i - 1]) {
      std::ostringstream msg;
      msg << label << " must be strictly increasing; index " << i - 1
          << "=" << values[i - 1] << ", index " << i << "=" << values[i];
      throw std::runtime_error(msg.str());
    }
  }
}

std::vector<double> gtTimestampVector(const std::vector<GTPose>& gt_poses_raw) {
  std::vector<double> gt_times;
  gt_times.reserve(gt_poses_raw.size());
  for (const auto& gp : gt_poses_raw) gt_times.push_back(gp.timestamp);
  return gt_times;
}

struct GTAssociation {
  std::vector<Eigen::Matrix4d> poses;
  std::string mode;
  std::vector<size_t> gt_indices;
};

std::vector<Eigen::Matrix4d> buildAssociatedGTMatrices(
    const std::vector<GTPose>& gt_poses_raw,
    const std::vector<size_t>& indices) {
  std::vector<Eigen::Matrix4d> gt;
  if (indices.empty()) return gt;
  const Eigen::Matrix4d T0_inv =
      gt_poses_raw[indices.front()].sensorMatrix().inverse();
  gt.reserve(indices.size());
  for (size_t idx : indices) {
    if (idx >= gt_poses_raw.size()) {
      throw std::runtime_error("GT association index out of range");
    }
    gt.push_back(T0_inv * gt_poses_raw[idx].sensorMatrix());
  }
  return gt;
}

GTAssociation associateByExactFrameId(
    const std::vector<double>& frame_timestamps,
    const std::vector<GTPose>& gt_poses_raw) {
  requireStrictlyIncreasing(frame_timestamps, "frame_timestamps");
  const auto gt_times = gtTimestampVector(gt_poses_raw);
  requireStrictlyIncreasing(gt_times, "GT timestamps");

  if (!allFiniteIntegers(frame_timestamps) ||
      !allGTTimestampsFiniteIntegers(gt_poses_raw)) {
    throw std::runtime_error(
        "exact frame-ID association requires integer frame IDs in both "
        "frame_timestamps and GT");
  }

  GTAssociation association;
  association.mode = "exact_frame_id";
  association.gt_indices.reserve(frame_timestamps.size());

  size_t gt_cursor = 0;
  for (size_t i = 0; i < frame_timestamps.size(); i++) {
    const long long frame_id = static_cast<long long>(std::llround(frame_timestamps[i]));
    while (gt_cursor < gt_poses_raw.size() &&
           static_cast<long long>(std::llround(gt_poses_raw[gt_cursor].timestamp)) <
               frame_id) {
      gt_cursor++;
    }
    if (gt_cursor >= gt_poses_raw.size() ||
        static_cast<long long>(std::llround(gt_poses_raw[gt_cursor].timestamp)) !=
            frame_id) {
      std::ostringstream msg;
      msg << "Missing GT pose for frame_id " << frame_id
          << " at processed frame " << i
          << "; refusing silent GT sampling fallback";
      throw std::runtime_error(msg.str());
    }
    association.gt_indices.push_back(gt_cursor);
  }

  association.poses = buildAssociatedGTMatrices(gt_poses_raw,
                                               association.gt_indices);
  return association;
}

GTAssociation associateByTimestamp(
    const std::vector<double>& frame_timestamps,
    const std::vector<GTPose>& gt_poses_raw,
    double max_dt) {
  if (!std::isfinite(max_dt) || max_dt < 0.0) {
    throw std::runtime_error("--association-max-dt must be finite and >= 0");
  }
  requireStrictlyIncreasing(frame_timestamps, "frame_timestamps");
  const auto gt_times = gtTimestampVector(gt_poses_raw);
  requireStrictlyIncreasing(gt_times, "GT timestamps");

  GTAssociation association;
  association.mode = "timestamp";
  association.gt_indices.reserve(frame_timestamps.size());

  for (size_t i = 0; i < frame_timestamps.size(); i++) {
    const double ts = frame_timestamps[i];
    auto it = std::lower_bound(gt_times.begin(), gt_times.end(), ts);
    size_t idx = 0;
    if (it == gt_times.end()) {
      idx = gt_times.size() - 1;
    } else if (it == gt_times.begin()) {
      idx = 0;
    } else {
      const size_t hi = static_cast<size_t>(it - gt_times.begin());
      const size_t lo = hi - 1;
      idx = std::abs(gt_times[hi] - ts) < std::abs(gt_times[lo] - ts) ? hi : lo;
    }
    const double dt = std::abs(gt_times[idx] - ts);
    if (dt > max_dt) {
      std::ostringstream msg;
      msg << "No GT timestamp within " << max_dt
          << " s for processed frame " << i
          << " (frame timestamp=" << ts
          << ", nearest GT timestamp=" << gt_times[idx]
          << ", dt=" << dt << ")";
      throw std::runtime_error(msg.str());
    }
    association.gt_indices.push_back(idx);
  }

  association.poses = buildAssociatedGTMatrices(gt_poses_raw,
                                               association.gt_indices);
  return association;
}

GTAssociation associateGTPoseMatrices(
    const std::vector<GTPose>& gt_poses_raw,
    const std::vector<double>& frame_timestamps,
    double max_dt) {
  if (gt_poses_raw.empty()) throw std::runtime_error("GT poses are empty");
  if (frame_timestamps.empty()) {
    throw std::runtime_error(
        "No frame timestamps available for strict GT association. Provide "
        "frame_timestamps.csv/graph timestamps, or explicitly use "
        "--association-mode legacy-auto for old sampled-GT behavior.");
  }

  const bool frame_ids = allFiniteIntegers(frame_timestamps);
  const bool gt_ids = allGTTimestampsFiniteIntegers(gt_poses_raw);
  if (frame_ids && gt_ids) {
    return associateByExactFrameId(frame_timestamps, gt_poses_raw);
  }
  return associateByTimestamp(frame_timestamps, gt_poses_raw, max_dt);
}

std::vector<double> sampleFrameTimestamps(const std::vector<GTPose>& gt_poses_raw,
                                          size_t num_frames,
                                          size_t total_pcd_frames);

std::vector<Eigen::Matrix4d> sampleGTPoseMatrices(
    const std::vector<GTPose>& gt_poses_raw,
    const std::vector<double>& frame_timestamps);

GTAssociation associateByLegacySampling(
    const std::vector<GTPose>& gt_poses_raw,
    size_t num_frames,
    size_t total_pcd_frames) {
  GTAssociation association;
  association.mode = "legacy_sampled_gt";
  const auto sampled_timestamps =
      sampleFrameTimestamps(gt_poses_raw, num_frames, total_pcd_frames);
  association.poses = sampleGTPoseMatrices(gt_poses_raw, sampled_timestamps);
  return association;
}

bool isGlobalDogfoodingGtArtifact(const std::string& gt_csv) {
  const fs::path path(gt_csv);
  return path.filename() == "gt.txt" &&
         path.parent_path().filename() == "dogfooding_results";
}

bool pathsEquivalentIfBothExist(const fs::path& lhs, const fs::path& rhs) {
  std::error_code ec;
  if (!fs::exists(lhs, ec) || ec) return false;
  if (!fs::exists(rhs, ec) || ec) return false;
  const bool equivalent = fs::equivalent(lhs, rhs, ec);
  return !ec && equivalent;
}

std::string frameTimestampSourceName(FrameTimestampSource source) {
  switch (source) {
    case FrameTimestampSource::kFrameTimestampCsv:
      return "frame_timestamps.csv";
    case FrameTimestampSource::kGraphTrajectory:
      return "graph/trajectory.csv";
    case FrameTimestampSource::kSampledGT:
      return "sampled GT timestamps";
  }
  return "unknown";
}

std::string jsonEscape(const std::string& input) {
  std::string escaped;
  escaped.reserve(input.size() + 8);
  for (char c : input) {
    switch (c) {
      case '\\':
        escaped += "\\\\";
        break;
      case '"':
        escaped += "\\\"";
        break;
      case '\n':
        escaped += "\\n";
        break;
      case '\r':
        escaped += "\\r";
        break;
      case '\t':
        escaped += "\\t";
        break;
      default:
        escaped += c;
        break;
    }
  }
  return escaped;
}

double computeATE(const std::vector<Eigen::Matrix4d>& est,
                  const std::vector<Eigen::Matrix4d>& gt) {
  int n = std::min(est.size(), gt.size());
  if (n == 0) return 0;
  double sum = 0;
  for (int i = 0; i < n; i++) {
    double e = (est[i].block<3, 1>(0, 3) - gt[i].block<3, 1>(0, 3)).norm();
    sum += e * e;
  }
  return std::sqrt(sum / n);
}

struct RPEMetrics {
  bool available = false;
  double trans_pct = 0.0;
  double rot_deg_per_m = 0.0;
};

// KITTI-style benchmarks use 100 m segments when the trajectory is long enough.
// For short public windows (e.g. MCD ~15 m), scale the segment length down so RPE
// is still defined without changing behavior on sequences >= 100 m.
double rpeSegmentLengthM(double trajectory_length_m) {
  if (trajectory_length_m <= 0.0) return 0.0;
  constexpr double kKitBench = 100.0;
  if (trajectory_length_m >= kKitBench) return kKitBench;
  const double half = 0.5 * trajectory_length_m;
  constexpr double kMinSeg = 3.0;
  double seg = std::max(half, kMinSeg);
  seg = std::min(seg, trajectory_length_m * 0.95);
  return seg;
}

RPEMetrics computeRPE(const std::vector<Eigen::Matrix4d>& est,
                      const std::vector<Eigen::Matrix4d>& gt,
                      double segment_length_m = 100.0) {
  const int n = std::min(est.size(), gt.size());
  if (n < 2 || segment_length_m <= 0.0) return {};

  std::vector<double> trans_errs;
  std::vector<double> rot_errs;
  for (int i = 0; i < n; i++) {
    double dist = 0.0;
    int j = i + 1;
    while (j < n) {
      dist += (gt[j].block<3, 1>(0, 3) - gt[j - 1].block<3, 1>(0, 3)).norm();
      if (dist >= segment_length_m) break;
      ++j;
    }
    if (j >= n || dist <= 1e-9) break;

    const Eigen::Matrix4d dT_est = est[i].inverse() * est[j];
    const Eigen::Matrix4d dT_gt = gt[i].inverse() * gt[j];
    const Eigen::Matrix4d T_err = dT_gt.inverse() * dT_est;

    const double t_err = T_err.block<3, 1>(0, 3).norm();
    const Eigen::Matrix3d R_err = T_err.block<3, 3>(0, 0);
    const double trace_term =
        std::clamp((R_err.trace() - 1.0) / 2.0, -1.0, 1.0);
    const double r_err_rad = std::acos(trace_term);

    trans_errs.push_back(t_err / dist * 100.0);
    rot_errs.push_back(r_err_rad / dist * 180.0 / M_PI);
  }

  if (trans_errs.empty()) return {};

  RPEMetrics metrics;
  metrics.available = true;
  for (double value : trans_errs) metrics.trans_pct += value;
  for (double value : rot_errs) metrics.rot_deg_per_m += value;
  metrics.trans_pct /= trans_errs.size();
  metrics.rot_deg_per_m /= rot_errs.size();
  return metrics;
}

struct KittiRTEMetrics {
  bool available = false;
  double trans_pct = 0.0;
  double rot_deg_per_100m = 0.0;
  int segments = 0;
};

// Official KITTI odometry metric (devkit evaluate_odometry.cpp): segments of
// 100..800 m starting every 10th frame, errors averaged over all segments.
// Unlike computeRPE this is comparable to paper-reported KITTI RTE.
KittiRTEMetrics computeKittiRTE(const std::vector<Eigen::Matrix4d>& est,
                                const std::vector<Eigen::Matrix4d>& gt) {
  const int n = std::min(est.size(), gt.size());
  if (n < 2) return {};
  std::vector<double> dist(n, 0.0);
  for (int i = 1; i < n; ++i) {
    dist[i] = dist[i - 1] +
              (gt[i].block<3, 1>(0, 3) - gt[i - 1].block<3, 1>(0, 3)).norm();
  }
  constexpr int kStepSize = 10;
  constexpr double kLengths[] = {100, 200, 300, 400, 500, 600, 700, 800};
  double trans_sum = 0.0;
  double rot_sum = 0.0;
  int count = 0;
  for (int first = 0; first < n; first += kStepSize) {
    for (double len : kLengths) {
      int last = first;
      while (last < n && dist[last] <= dist[first] + len) ++last;
      if (last >= n) continue;
      const Eigen::Matrix4d delta_gt = gt[first].inverse() * gt[last];
      const Eigen::Matrix4d delta_est = est[first].inverse() * est[last];
      const Eigen::Matrix4d err = delta_est.inverse() * delta_gt;
      const double d = std::clamp(0.5 * (err(0, 0) + err(1, 1) + err(2, 2) - 1.0), -1.0, 1.0);
      trans_sum += err.block<3, 1>(0, 3).norm() / len;
      rot_sum += std::acos(d) / len;
      ++count;
    }
  }
  if (count == 0) return {};
  KittiRTEMetrics metrics;
  metrics.available = true;
  metrics.segments = count;
  metrics.trans_pct = trans_sum / count * 100.0;
  metrics.rot_deg_per_100m = rot_sum / count * 180.0 / M_PI * 100.0;
  return metrics;
}

int frameToGTIndex(size_t frame_idx, size_t total_pcd_frames, size_t num_gt_poses) {
  if (num_gt_poses == 0) return 0;
  if (num_gt_poses == total_pcd_frames) {
    return std::min(static_cast<int>(frame_idx), static_cast<int>(num_gt_poses) - 1);
  }
  int gt_idx = static_cast<int>(
      static_cast<double>(frame_idx) / std::max<size_t>(total_pcd_frames, 1) * num_gt_poses);
  return std::min(gt_idx, static_cast<int>(num_gt_poses) - 1);
}

std::vector<double> sampleFrameTimestamps(const std::vector<GTPose>& gt_poses_raw,
                                          size_t num_frames,
                                          size_t total_pcd_frames) {
  std::vector<double> timestamps;
  timestamps.reserve(num_frames);
  if (gt_poses_raw.empty()) return timestamps;
  for (size_t i = 0; i < num_frames; i++) {
    int gt_idx = frameToGTIndex(i, total_pcd_frames, gt_poses_raw.size());
    timestamps.push_back(gt_poses_raw[gt_idx].timestamp);
  }
  return timestamps;
}

std::vector<Eigen::Matrix4d> sampleGTPoseMatrices(
    const std::vector<GTPose>& gt_poses_raw,
    const std::vector<double>& frame_timestamps) {
  std::vector<Eigen::Matrix4d> gt;
  if (gt_poses_raw.empty()) return gt;

  std::vector<double> gt_times;
  gt_times.reserve(gt_poses_raw.size());
  for (const auto& gp : gt_poses_raw) gt_times.push_back(gp.timestamp);

  Eigen::Matrix4d T0_inv = gt_poses_raw.front().sensorMatrix().inverse();
  gt.reserve(frame_timestamps.size());
  for (double ts : frame_timestamps) {
    auto it = std::lower_bound(gt_times.begin(), gt_times.end(), ts);
    size_t idx = 0;
    if (it == gt_times.end()) {
      idx = gt_times.size() - 1;
    } else if (it == gt_times.begin()) {
      idx = 0;
    } else {
      size_t hi = static_cast<size_t>(it - gt_times.begin());
      size_t lo = hi - 1;
      idx = std::abs(gt_times[hi] - ts) < std::abs(gt_times[lo] - ts) ? hi : lo;
    }
    gt.push_back(T0_inv * gt_poses_raw[idx].sensorMatrix());
  }
  return gt;
}

std::vector<localization_zoo::imu_preintegration::ImuSample> selectImuWindow(
    const std::vector<ImuSampleCsv>& imu_samples, double start_time, double end_time) {
  std::vector<localization_zoo::imu_preintegration::ImuSample> out;
  for (const auto& sample : imu_samples) {
    if (sample.timestamp < start_time) continue;
    if (sample.timestamp > end_time) break;

    localization_zoo::imu_preintegration::ImuSample imu;
    imu.timestamp = sample.timestamp;
    imu.gyro = sample.gyro;
    imu.accel = sample.accel;
    out.push_back(imu);
  }
  return out;
}

// ============================================================

struct MethodResult {
  std::string name;
  std::vector<Eigen::Matrix4d> poses;
  double time_ms = 0;
  double algorithm_time_ms = -1.0;
  double ate = 0;
  double rpe_trans_pct = 0;
  double rpe_rot_deg_per_m = 0;
  bool has_rpe = false;
  KittiRTEMetrics kitti_rte;
  bool skipped = false;
  std::string status = "ok";
  std::string note;
  // Fraction of GT-seeded frames whose registration was rejected by the
  // weak-update gate and rolled back to the seed pose. <0 means N/A (the
  // method ran without a per-frame GT seed). Quantifies GT dependence.
  double seed_fallback_rate_pct = -1.0;
};

MethodResult makeSkippedResult(const std::string& name, const std::string& note) {
  MethodResult res;
  res.name = name;
  res.skipped = true;
  res.status = "skipped";
  res.note = note;
  return res;
}

struct SeedPerturbation {
  double x = 0.0;
  double y = 0.0;
  double z = 0.0;
  double yaw_rad = 0.0;

  bool enabled() const {
    constexpr double kEps = 1e-12;
    return std::abs(x) > kEps || std::abs(y) > kEps ||
           std::abs(z) > kEps || std::abs(yaw_rad) > kEps;
  }
};

Eigen::Matrix4d seedPerturbationMatrix(const SeedPerturbation& perturb) {
  Eigen::Matrix4d delta = Eigen::Matrix4d::Identity();
  delta.block<3, 3>(0, 0) =
      Eigen::AngleAxisd(perturb.yaw_rad, Eigen::Vector3d::UnitZ())
          .toRotationMatrix();
  delta(0, 3) = perturb.x;
  delta(1, 3) = perturb.y;
  delta(2, 3) = perturb.z;
  return delta;
}

Eigen::Matrix4d applySeedPerturbation(const Eigen::Matrix4d& seed,
                                      const SeedPerturbation& perturb) {
  if (!perturb.enabled()) {
    return seed;
  }
  return seed * seedPerturbationMatrix(perturb);
}

bool isFiniteMatrix(const Eigen::Matrix4d& T) {
  for (int r = 0; r < T.rows(); ++r) {
    for (int c = 0; c < T.cols(); ++c) {
      if (!std::isfinite(T(r, c))) {
        return false;
      }
    }
  }
  return true;
}

std::string seedPerturbationNote(const SeedPerturbation& perturb) {
  if (!perturb.enabled()) {
    return "";
  }
  std::ostringstream ss;
  ss << " Seed perturbation applied in local seed frame: dx="
     << std::fixed << std::setprecision(3) << perturb.x
     << "m dy=" << perturb.y
     << "m dz=" << perturb.z
     << "m yaw=" << perturb.yaw_rad * 180.0 / M_PI << "deg.";
  return ss.str();
}

struct LiTAMIN2DogfoodingOptions {
  enum class LocalMapPolicy { RefreshOnly, Accumulate, Keyframe };

  double voxel_resolution = 2.0;
  int min_points_per_voxel = 1;
  int max_iterations = 6;
  bool use_cov_cost = true;
  bool optimize_covariance_cost = false;
  double covariance_gradient_weight = 1.0;
  bool enable_line_search = false;
  double line_search_min_step = 0.0625;
  bool scan_to_scan = false;
  std::vector<double> coarse_to_fine_voxel_resolutions;
  std::vector<int> coarse_to_fine_iterations;
  int num_threads =
      static_cast<int>(std::max(1u, std::thread::hardware_concurrency() / 2));
  size_t max_source_points = 2500;
  size_t map_max_points = 45000;
  size_t refresh_interval = 3;
  double map_radius = 45.0;
  LocalMapPolicy local_map_policy = LocalMapPolicy::RefreshOnly;
  double keyframe_translation = 1.0;
  double keyframe_rotation_rad = 0.15;
  double max_seed_translation_delta = 2.0;
  double max_seed_rotation_delta_rad = 0.25;
  double max_motion_translation_delta = -1.0;
  double max_motion_rotation_delta_rad = -1.0;
  double min_cov_eigenvalue = 1e-3;
  int correspondence_search_radius = 0;
  double max_correspondence_distance = 0.0;
  SeedPerturbation seed_perturbation;
  // --litamin2-paper-odometry: the paper's pipeline (raw scans, 3 m
  // distributions, voxel map of distributions, nearest-distribution pairing).
  bool paper_odometry = false;
  double paper_voxel_size = 3.0;
  int paper_min_points = 3;
  int paper_max_iterations = 30;
  double paper_map_radius = 100.0;
  std::string paper_map_mode = "aggregate";
};

std::string litamin2LocalMapPolicyName(
    LiTAMIN2DogfoodingOptions::LocalMapPolicy policy) {
  using Policy = LiTAMIN2DogfoodingOptions::LocalMapPolicy;
  switch (policy) {
    case Policy::RefreshOnly:
      return "refresh";
    case Policy::Accumulate:
      return "accumulate";
    case Policy::Keyframe:
      return "keyframe";
  }
  return "refresh";
}

bool parseLitamin2LocalMapPolicy(
    const std::string& value,
    LiTAMIN2DogfoodingOptions::LocalMapPolicy* policy) {
  using Policy = LiTAMIN2DogfoodingOptions::LocalMapPolicy;
  if (value == "refresh" || value == "refresh-only") {
    *policy = Policy::RefreshOnly;
    return true;
  }
  if (value == "accumulate" || value == "rolling") {
    *policy = Policy::Accumulate;
    return true;
  }
  if (value == "keyframe") {
    *policy = Policy::Keyframe;
    return true;
  }
  return false;
}

struct GICPDogfoodingOptions {
  double source_voxel_size = 1.0;
  size_t max_source_points = 2500;
  int k_neighbors = 8;
  double max_correspondence_distance = 2.5;
  int max_iterations = 8;
  size_t map_max_points = 40000;
  size_t refresh_interval = 4;
  double map_radius = 45.0;
  double max_seed_translation_delta = 2.0;
  double max_seed_rotation_delta_rad = 0.25;
  SeedPerturbation seed_perturbation;
};

struct SmallGICPDogfoodingOptions {
  double source_voxel_size = 1.0;
  size_t max_source_points = 2500;
  double voxel_resolution = 1.0;
  int k_neighbors = 12;
  double max_correspondence_distance = 4.0;
  int max_correspondences = 256;
  int max_iterations = 20;
  double covariance_regularization = 1e-3;
  double fitness_epsilon = 1e-6;
  double rotation_epsilon = 1e-4;
  double translation_epsilon = 1e-4;
  size_t map_max_points = 40000;
  size_t refresh_interval = 4;
  double map_radius = 45.0;
  double max_seed_translation_delta = 2.0;
  double max_seed_rotation_delta_rad = 0.25;
  SeedPerturbation seed_perturbation;
};

struct VoxelGICPDogfoodingOptions {
  double source_voxel_size = 1.0;
  size_t max_source_points = 2500;
  double voxel_resolution = 1.0;
  int min_points_per_voxel = 1;
  double max_correspondence_distance = 4.0;
  int max_iterations = 20;
  double covariance_regularization = 1e-3;
  double fitness_epsilon = 1e-6;
  double rotation_epsilon = 1e-4;
  double translation_epsilon = 1e-4;
  size_t map_max_points = 40000;
  size_t refresh_interval = 4;
  double map_radius = 45.0;
  double max_seed_translation_delta = 2.0;
  double max_seed_rotation_delta_rad = 0.25;
  SeedPerturbation seed_perturbation;
};

struct ALOAMDogfoodingOptions {
  int n_scans = 64;
  float scan_period = 0.1f;
  float minimum_range = 1.0f;
  float curvature_threshold = 0.1f;
  int max_corner_sharp = 2;
  int max_corner_less_sharp = 20;
  int max_surf_flat = 4;
  float less_flat_leaf_size = 0.2f;

  double odom_distance_sq_threshold = 25.0;
  double odom_nearby_scan = 2.5;
  int odom_outer_iters = 2;
  int odom_ceres_iters = 4;
  double odom_huber_loss_s = 0.1;

  double map_line_resolution = 0.4;
  double map_plane_resolution = 0.8;
  int map_outer_iters = 2;
  int map_ceres_iters = 4;
  double map_huber_loss_s = 0.1;
  int map_knn = 5;
  double map_knn_max_dist_sq = 1.0;
  double map_edge_eigenvalue_ratio = 3.0;
  double map_plane_threshold = 0.2;
};

struct FLOAMDogfoodingOptions {
  int n_scans = 64;
  float scan_period = 0.1f;
  float minimum_range = 1.0f;

  size_t input_point_stride = 2;
  int mapping_update_interval = 2;
  bool enable_mapping = true;

  float curvature_threshold = 0.08f;
  int max_corner_sharp = 1;
  int max_corner_less_sharp = 10;
  int max_surf_flat = 2;
  float less_flat_leaf_size = 0.3f;

  double odom_distance_sq_threshold = 16.0;
  int odom_outer_iters = 1;
  int odom_ceres_iters = 3;

  double map_line_resolution = 0.6;
  double map_plane_resolution = 1.0;
  int map_outer_iters = 1;
  int map_ceres_iters = 3;
  double map_knn_max_dist_sq = 4.0;
};

struct ILoamDogfoodingOptions {
  int n_scans = 64;
  float scan_period = 0.1f;
  float minimum_range = 1.0f;
  size_t input_point_stride = 2;

  float curvature_threshold = 0.08f;
  int max_corner_sharp = 1;
  int max_corner_less_sharp = 10;
  int max_surf_flat = 2;
  float less_flat_leaf_size = 0.3f;

  double odom_distance_sq_threshold = 16.0;
  double odom_nearby_scan = 2.5;
  int odom_outer_iters = 2;
  int odom_ceres_iters = 4;
  double odom_huber_loss_s = 0.1;

  bool enable_mapping = true;
  int mapping_update_interval = 1;
  double map_line_resolution = 0.4;
  double map_plane_resolution = 0.8;
  int map_outer_iters = 2;
  int map_ceres_iters = 4;
  double map_huber_loss_s = 0.1;
  int map_knn = 5;
  double map_knn_max_dist_sq = 1.0;
  double map_edge_eigenvalue_ratio = 3.0;
  double map_plane_threshold = 0.2;

  // I-LOAM 強度拡張
  bool use_intensity_weight = true;
  bool use_intensity_correspondence = true;
  double intensity_sigma = 0.15;
  double intensity_corr_weight = 1.0;
};

struct PlLoamDogfoodingOptions {
  size_t input_stride = 2;
  int max_point_features = 280;
  int max_line_features = 64;
  int patch_radius = 4;
  bool use_depth_prior = true;
  bool use_line_features = true;
  bool use_scale_correction = true;
  bool use_intensity_pseudo_image = true;
  int intensity_dilation_radius = 2;
  double depth_prior_weight = 1.0;
  int ceres_max_iterations = 12;
  /// KITTI Raw RGB root (drive_*_sync dir). Empty → pseudo-image.
  std::string rgb_image_root;
  std::string rgb_camera_subdir = "image_02/data";
  bool use_rgb = false;
  bool rgb_half_res = true;
};

struct InTenLoamDogfoodingOptions {
  bool paper_accelerated = false;
  size_t input_stride = 2;
  int cyl_width = 1024;
  int cyl_height = 64;
  bool use_intensity_registration = true;
  int max_edge_features = 200;
  int max_surface_features = 400;
  int max_reflector_features = 120;
  double intensity_weight = 1.0;
  bool enable_tvf = true;
  bool enable_dor = true;
  bool enable_mapping = true;
  double tvf_voxel_size = 1.0;
  int tvf_min_observations = 3;
  double dor_range_delta_thresh = 0.6;
  double map_voxel_size = 1.0;
  double local_map_radius = 80.0;
  int mapping_keyframe_interval = 2;
  // Paper pipeline (InTenLoamPaper).
  bool paper_odometry = false;
  bool paper_intensity = true;
  bool paper_mapping = true;
  bool paper_dor = true;
  int paper_s2m_interval = 1;
  std::string paper_trace_jsonl;  // opt-in passive observation, default off
  std::vector<std::string> trace_argv;
  std::vector<std::pair<std::string, double>> paper_overrides;
};

struct IcpscLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  int cyl_width = 1024;
  int cyl_height = 64;
  int num_rings = 20;
  int num_sectors = 60;
  double intensity_sigma = 0.15;
  double adaptive_alpha = 1.0;
  bool enable_intensity = true;
  double voxel_size = 1.0;
  int max_iterations = 15;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct VlomDogfoodingOptions {
  size_t input_point_stride = 2;
  size_t visual_input_stride = 2;
  int max_point_features = 280;
  int max_line_features = 64;
  bool enable_visual_bootstrap = false;
  bool enable_scale_correction = true;
  int scale_correction_interval = 5;
  double mad_outlier_k = 2.5;
  bool enable_mapping = true;
  bool use_intensity_pseudo_image = true;
  int intensity_dilation_radius = 2;

  int n_scans = 64;
  float scan_period = 0.1f;
  float minimum_range = 1.0f;
  float curvature_threshold = 0.1f;
  int max_corner_sharp = 2;
  int max_corner_less_sharp = 20;
  int max_surf_flat = 4;
  float less_flat_leaf_size = 0.2f;
  double odom_distance_sq_threshold = 25.0;
  double odom_nearby_scan = 2.5;
  int odom_outer_iters = 2;
  int odom_ceres_iters = 4;
  double odom_huber_loss_s = 0.1;
  double map_line_resolution = 0.4;
  double map_plane_resolution = 0.8;
  int map_outer_iters = 2;
  int map_ceres_iters = 4;
  double map_huber_loss_s = 0.1;
  int map_knn = 5;
  double map_knn_max_dist_sq = 1.0;
  double map_edge_eigenvalue_ratio = 3.0;
  double map_plane_threshold = 0.2;
  std::string rgb_image_root;
  std::string rgb_camera_subdir = "image_02/data";
  bool use_rgb = false;
  bool rgb_half_res = true;
};

struct McGicpLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double initial_threshold = 2.0;
  double max_correspondence_dist = 2.0;
  int max_iterations = 20;
  double intensity_scale = 2.0;
  double normal_epsilon = 1e-3;
  double intensity_epsilon = 0.05;
  bool enable_intensity = true;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct LeGOLOAMDogfoodingOptions {
  int n_scans = 64;
  int ground_scan_limit = 6;
  int num_subregions = 6;
  int neighbor_window = 5;
  float minimum_range = 1.0f;
  float maximum_range = 100.0f;
  float sensor_height = 1.8f;
  float ground_height_tolerance = 0.4f;
  float sensor_mount_angle_deg = 0.0f;
  float ground_angle_threshold_deg = 10.0f;
  float scan_period = 0.1f;
  float curvature_threshold = 0.1f;
  int max_corner_sharp = 2;
  int max_corner_less_sharp = 20;
  int max_surf_flat = 4;
  float less_flat_leaf_size = 0.2f;

  double odom_distance_sq_threshold = 25.0;
  double odom_nearby_scan = 2.5;
  int odom_outer_iters = 2;
  int odom_ceres_iters = 4;
  double odom_huber_loss_s = 0.1;

  double map_line_resolution = 0.4;
  double map_plane_resolution = 0.8;
  int map_outer_iters = 2;
  int map_ceres_iters = 4;
  double map_huber_loss_s = 0.1;
  int map_knn = 5;
  double map_knn_max_dist_sq = 1.0;
  double map_edge_eigenvalue_ratio = 3.0;
  double map_plane_threshold = 0.2;
};

struct MULLSDogfoodingOptions {
  int n_scans = 64;
  float scan_period = 0.1f;
  float minimum_range = 1.0f;
  float curvature_threshold = 0.1f;
  int max_corner_sharp = 2;
  int max_corner_less_sharp = 20;
  int max_surf_flat = 4;
  float less_flat_leaf_size = 0.2f;

  double odom_distance_sq_threshold = 25.0;
  double odom_nearby_scan = 2.5;
  int odom_outer_iters = 2;
  int odom_ceres_iters = 4;
  double odom_huber_loss_s = 0.1;

  double line_resolution = 0.4;
  double plane_resolution = 0.8;
  double point_resolution = 1.0;
  int mulls_map_iters = 2;
  int mulls_ceres_iters = 4;
  double mulls_huber_loss_s = 0.1;
  int mulls_knn = 5;
  double mulls_knn_max_dist_sq = 1.0;
  double mulls_edge_eigenvalue_ratio = 3.0;
  double mulls_plane_threshold = 0.2;
  double mulls_point_neighbor_max_dist_sq = 4.0;
  double mulls_line_weight = 1.0;
  double mulls_plane_weight = 1.0;
  double mulls_point_weight = 0.3;
  int mulls_full_downsample_rate = 5;
  int mulls_max_frames_in_map = 30;
  // --mulls-lo: MULLS-LO pipeline (papers/mulls/include/mulls/mulls_lo.h,
  // KITTI urban profile) instead of the A-LOAM-feature variant above.
  bool lo = false;
  // --mulls-lo-disable a,b: switch MULLS-LO mechanisms off for ablation
  // (vertex-promotion, source-pruning, ground-balance, distance-weight, huber,
  // intensity-weight, dynamic-removal, pillar-refresh, scan-to-map).
  std::string lo_disable;
  bool lo_highway = false;  // --mulls-lo-highway: the authors' KITTI highway profile
};

struct NDTDogfoodingOptions {
  double source_voxel_size = 0.75;
  size_t max_source_points = 2000;
  double resolution = 1.5;
  int max_iterations = 5;
  double step_size = 0.2;
  double convergence_threshold = 1e-4;
  int min_points_per_cell = 1;
  size_t map_max_points = 22000;
  size_t refresh_interval = 8;
  double map_radius = 35.0;
  double max_seed_translation_delta = 1.5;
  double max_seed_rotation_delta_rad = 0.2;
  SeedPerturbation seed_perturbation;
};

struct KISSICPDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  double initial_threshold = 1.5;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
  bool update_full_voxels = false;
  bool use_model_deviation_threshold = false;
  double model_deviation_correspondence_multiplier = 3.0;
  double vertical_angle_correction_deg = 0.0;
  bool deskew_mulran = false;
  bool enable_motion_guard = false;
  double max_step_translation_m = 2.0;
  double max_step_rotation_deg = 20.0;
  bool enable_adaptive_motion_guard = false;
  size_t adaptive_motion_guard_min_trusted_steps = 3;
  double adaptive_motion_guard_max_translation_multiplier = 2.0;
  double adaptive_motion_guard_translation_consistency_m = 0.75;
  double adaptive_motion_guard_rotation_consistency_deg = 5.0;
  // Appended last: KISSMultiHorizonDogfoodingOptions initializes positionally.
  // -1 = search all voxels within the correspondence distance (default);
  // 1 = upstream KISS-ICP 27-voxel neighborhood.
  int neighbor_voxel_radius = -1;
  double min_range = 3.0;
  double convergence_criterion = 0.001;
  // Upstream registers a 1.5 * voxel_size subsample; this port used 1.0.
  double registration_voxel_multiplier = 1.0;
  bool geman_mcclure_kernel = false;
  double map_min_point_distance = 0.0;
};

struct KISSMultiHorizonDogfoodingOptions {
  KISSICPDogfoodingOptions frontend = {
      0.75, 2500, 1.25, 1.75, 10, 20, 45.0, 2, false, false, 3.0, 0.0,
      false, false, 2.0, 20.0};
  int keyframe_stride = 10;
  std::vector<int> horizons = {10, 20};
  int submap_frames = 5;
  double matcher_voxel_size = 0.8;
  double matcher_max_correspondence_distance = 1.5;
  int matcher_max_iterations = 15;
  int matcher_min_correspondences = 120;
  double max_matcher_rmse = 0.7;
  double max_information_condition = 1e6;
  double max_correction_translation = 0.8;
  double max_correction_rotation_rad = 0.08;
  double max_consensus_translation = 0.25;
  double max_consensus_rotation_rad = 0.025;
  double correction_gain = 0.0;
};

struct LFGICPDogfoodingOptions {
  bool enable_mitigation = true;
  double covariance_regularization = 2.0;
  double field_regularization = 0.25;
};

struct GenZICPDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  double initial_threshold = 1.5;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double planarity_threshold = 0.55;
  int normal_min_neighbors = 5;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct AdaptiveICPDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  double initial_threshold = 1.5;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  int coarse_max_iterations = 8;
  double planarity_threshold = 0.5;
  int normal_min_neighbors = 5;
  double density_percentile = 5.0;
  double reliable_translation_tau = 1.5;
  double motion_decay = 1.5;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct RKOLIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  double initial_threshold = 1.5;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
  double gyro_bias_gain = 0.3;
};

struct FRLIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 0.5;
  double grid_size = 2.0;
  double lidar_range = 40.0;
  double map_lambda = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 20;
  double max_correspondence_dist = 1.5;
  int max_subframes = 4;
  double esks_gain = 0.5;
  int min_valid_matches = 30;
};

struct PGLIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int max_icp_iterations = 30;
  double max_correspondence_dist = 2.0;
  int range_image_width = 512;
  int range_image_height = 64;
  int max_patches = 48;
  double photometric_weight = 1.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct D2LIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double planarity_threshold = 0.5;
  double base_threshold = 1.0;
  double max_threshold = 3.0;
  double cauchy_scale = 1.0;
  double degeneracy_ratio = 0.05;
  double imu_prior_weight = 1.0;
  double gyro_bias_gain = 0.3;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct CTVoxelMapDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int voxel_min_points = 6;
  double planarity_ratio = 0.1;
  int max_icp_iterations = 30;
  double max_correspondence_dist = 2.0;
  double sigma_depth = 0.02;
  double sigma_bearing = 0.0015;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct RVoxelMapDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int voxel_min_points = 6;
  double planarity_ratio = 0.1;
  double inlier_dist = 0.1;
  int max_depth = 2;
  int max_icp_iterations = 30;
  double max_correspondence_dist = 2.0;
  double max_plane_weight = 10000.0;
  double icp_damping = 0.0;
  double huber_residual = 0.0;
  double max_iteration_translation = 0.0;
  double max_iteration_rotation = 0.0;
  double min_map_matched_ratio = 0.0;
  double max_registration_translation = 3.0;
  double max_registration_rotation = 0.5;
  double max_map_fallback_translation_delta = 0.0;
  double max_map_fallback_rotation_delta = 0.0;
  bool enable_scan_to_scan_fallback = false;
  double fallback_max_correspondence_dist = 1.5;
  double min_fallback_matched_ratio = 0.05;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct DammLoamDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_icp_iterations = 30;
  double initial_threshold = 2.0;
  double vertical_cos = 0.966;
  double horizontal_cos = 0.34;
  double ground_z = 0.0;
  double edge_weight = 0.5;
  double degeneracy_ratio = 0.05;
  double degeneracy_boost = 4.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct LodestarDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_icp_iterations = 30;
  double initial_threshold = 2.0;
  double t_chi = 3.0;          // raw Hessian 向けに論文値 1.5 から緩める
  double anchor_strength = 1.0;
  int active_window = 2;
  bool enable_data_exploitation = true;
  double t_loc = 0.819;        // cos(35°)
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct TerrainRbfDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_icp_iterations = 30;
  double initial_threshold = 2.0;
  double terrain_cell_size = 2.0;
  double terrain_sigma = 3.0;
  double terrain_ground_band = 1.0;
  double terrain_weight = 5.0;  // z-drift 抑制 soft 拘束 (opt-in、dogfooding は有効)
  int terrain_warmup = 10;
  double sensor_height_alpha = 0.05;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct LidarIbaDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_icp_iterations = 30;
  double initial_threshold = 2.0;
  bool enable_ba = true;
  int keyframe_interval = 2;
  int window_size = 5;
  int ba_iterations = 4;
  double plane_voxel = 2.0;
  int max_landmarks = 150;
  double lidar_sigma = 0.05;
  double pose_prior_weight = 20.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct DaliSlamDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_icp_iterations = 30;
  double initial_threshold = 2.0;
  // KITTI(IMU無)既定: deskew は off。azimuth ベースの per-point 時刻復元はこの
  // harness のデータと不整合で、CV deskew が距離誤差を増幅し長系列(seq00)で発散
  // する。退化対応 remap (DALI の主寄与) は維持。--dali-slam-... で deskew を有効化可。
  bool enable_deskew = false;
  bool spline_quadratic = false;
  double degeneracy_ratio = 0.02;
  bool enable_degeneracy = true;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct IntensityFlowDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_icp_iterations = 30;
  double initial_threshold = 2.0;
  bool enable_gradient_flow = true;
  double gf_radius = 1.0;
  int gf_num_bins = 10;
  double gf_keep_ratio = 0.5;
  bool enable_intensity = true;
  double intensity_sigma = 0.2;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct SvnIcpDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double initial_threshold = 2.0;
  int num_particles = 12;
  int svn_iterations = 4;
  double step_size = 1.0;
  double lidar_sigma = 0.1;
  double prior_precision = 1.0;
  double init_spread_rot = 0.01;
  double init_spread_trans = 0.05;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct PcrDatDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double initial_threshold = 2.0;
  int max_iterations = 20;
  int distribution_min_points = 8;
  double distribution_planarity = 0.1;
  double distance_planarity = 0.4;
  double distance_sigma = 0.1;
  double distribution_regularization = 0.01;
  double distance_weight = 1.0;
  double distribution_weight = 1.0;
  double robust_scale = 1.0;
  double prior_precision = 0.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct SmallMightyDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double initial_threshold = 2.0;
  int max_iterations = 20;
  double planar_min = 0.4;
  double edge_min = 0.5;
  double contribution_gain = 1.0;
  double contribution_cap = 3.0;
  double plane_weight = 1.0;
  double edge_weight = 0.5;
  double robust_scale = 1.0;
  double prior_precision = 0.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct MGcloDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double initial_threshold = 2.0;
  int max_iterations = 20;
  double ground_normal_threshold = 0.85;
  double ground_height_offset = -0.5;
  bool ground_constraints = true;
  double ground_weight = 2.0;
  double nonground_weight = 1.0;
  double ground_planarity = 0.3;
  double distribution_regularization = 0.01;
  double uncertainty_range_ref = 40.0;
  double robust_scale = 1.0;
  double prior_precision = 0.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct QuadricLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int plane_min_neighbors = 5;
  double initial_threshold = 2.0;
  int max_iterations = 20;
  int quadric_min_neighbors = 14;
  double planarity_threshold = 0.4;
  bool allow_plane_fallback = true;
  double quadric_weight = 1.0;
  double min_grad_norm = 1e-3;
  double robust_scale = 1.0;
  double prior_precision = 0.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct DiloDogfoodingOptions {
  // SRI は密な点群から構築するため既定で間引かない (0=全点)。GN ソースは DiLO 内部で
  // 別途間引く (gn_voxel_size)。
  double source_voxel_size = 0.0;
  size_t max_source_points = 200000;
  double gn_voxel_size = 0.5;
  int sri_height = 64;
  int sri_width = 1024;
  double fov_up_deg = 2.0;
  double fov_down_deg = -24.8;
  int lookup_radius = 1;
  double max_lookup_point_distance = 1.5;
  int max_iterations = 30;
  double initial_threshold = 1.0;
  double robust_scale = 0.5;
  double keyframe_translation = 2.0;
  double keyframe_rotation_deg = 10.0;
  // --dilo-paper-odometry (see papers/dilo/include/dilo/dilo_paper.h).
  bool paper_odometry = false;
  int paper_window = 10;
  int paper_update_iterations = 5;
  int paper_keypoints_per_list = 100;
  bool paper_causal_output = false;
  bool paper_edges = false;
  int paper_edge_detector = 0;
  bool paper_edge_subpixel = false;
  int paper_edge_dofs = 6;
  double paper_edge_sum_weight = 0.0;  // > 0: summed normal equations
  double paper_min_planarity = -1.0;   // < 0: library default
  int paper_keypoint_cell = -1;
  double paper_fill_slope = -1.0;
  int paper_max_fill_gap = -1;  // rows; HDL-32E beams are ~8 rows apart
  double paper_degenerate_ratio = -1.0;
  double paper_top_elevation_deg = 1e9;  // >= 1e9: library default
  int paper_height = -1;
};

struct NhcLioDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double initial_threshold = 2.0;
  int max_iterations = 20;
  bool enable_nhc = true;
  double nhc_weight = 5.0;
  double nhc_yaw_ref = 0.03;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct StudentTLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double initial_threshold = 2.0;
  int max_iterations = 20;
  bool enable_student_t = true;
  double student_t_dof = 5.0;
  double scale_init = 0.5;
  bool estimate_scale = true;
  double scale_floor = 0.05;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct SpectralLoDogfoodingOptions {
  double source_voxel_size = 0.0;  // full cloud (BEV ラスタに密度が要る)
  size_t max_source_points = 200000;
  int bev_size = 256;
  double bev_range = 40.0;
  double max_range = 80.0;
  double z_min = -3.0;
  double z_max = 3.0;
  int logpolar_angles = 256;
  int logpolar_radii = 256;
  double max_yaw_deg = 30.0;
  double keyframe_translation = 0.0;
  int translation_refinement_iterations = 0;
  double max_translation_refinement_m = 1.5;
};

struct GmmLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  int max_iterations = 20;
  double sigma_init = 1.2;
  double sigma_final = 0.25;
  double outlier_weight = 0.1;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct GncLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double max_correspondence_dist = 2.0;
  int max_iterations = 20;
  double gnc_truncation = 0.3;
  double gnc_factor = 1.4;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct MccLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double max_correspondence_dist = 2.0;
  int max_iterations = 20;
  double mcc_sigma = 0.3;
  bool mcc_adaptive_sigma = true;
  double mcc_sigma_floor = 0.3;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct ImlsSlamDogfoodingOptions {
  bool paper_accelerated = false;
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double normal_radius = 0.0;
  double imls_h = 0.5;
  double imls_support_radius = 0.0;
  double max_correspondence_dist = 1.0;
  int max_iterations = 20;
  int samples_per_axis = 100;
  bool use_observability_sampling = true;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
  // --imls-slam-paper-odometry: the paper's pipeline (raw scans, sliding
  // window of raw scans, h = 0.06 / r = 0.20, nine-list sampling).
  bool paper_odometry = false;
  int paper_window_scans = 100;
  int paper_samples_per_list = 100;
  int paper_iterations = 20;
  double paper_h = 0.06;
  double paper_r = 0.20;
  double paper_scan_normal_radius = 0.5;
  int paper_coarse_frames = 0;  // registrations with a coarse stage first (not in the paper)
  double paper_coarse_r = 1.0;
  double paper_coarse_h = 0.3;
};

struct MeshLoamDogfoodingOptions {
  double source_voxel_size = 0.25;
  size_t max_source_points = 8000;
  double voxel_size = 0.1;
  double imls_h = 0.05;
  double lambda_n = 0.2;
  double curvature_threshold = 0.1;
  double cos_gate = 0.98;
  double search_radius = 0.2;
  double max_correspondence_dist = 0.5;
  int max_iterations = 30;
  int mesh_update_interval = 5;
  double local_map_radius = 80.0;
  bool nearest_facet = false;
  bool keep_mesh = false;
  int normal_neighbors = 8;
  double normal_search_radius = 1.0;
  double max_range = 80.0;
  bool paper_odometry = false;
  bool marching_cubes = false;
  bool dirty_cells = true;
  double freeze_radius = 0.0;
};

struct EloDogfoodingOptions {
  double source_voxel_size = 0.2;
  size_t max_source_points = 50000;
  int sri_width = 1024;
  int sri_height = 80;
  double bev_resolution = 0.25;
  double sensor_height = 1.73;
  int max_iterations = 18;
  double max_sri_correspondence_dist = 1.0;
  double max_ground_correspondence_dist = 1.0;
  double ground_weight = 5.0;
  double non_ground_weight = 1.0;
  int max_alignment_points = 12000;
  int model_window_frames = 100;
  // --elo-paper-profile (paper mechanics, see papers/elo/README.md).
  int fusion_mode = 0;
  bool ground_requires_both_sides = false;
  bool normal_patch_full_size = false;
  bool bev_keep_closest = false;
  bool sri_fuse_same_surface = false;
  double sri_fov_up_deg = 1e9;    // >= 1e9: library default
  double sri_fov_down_deg = 1e9;
  bool ground_constrains_forward = true;
  double curvature_threshold = -1.0;  // < 0: library default
  double robust_scale = 0.5;
  int sri_search_radius_px = 1;
  bool paper_profile = false;
};

struct TcLvgfDogfoodingOptions {
  double source_voxel_size = 0.45;
  size_t max_source_points = 5500;
  double voxel_size = 1.0;
  double registration_voxel_size = 0.9;
  int max_registration_points = 4200;
  int image_width = 1024;
  int image_height = 64;
  int max_icp_iterations = 24;
  double max_correspondence_dist = 2.0;
  int min_visual_lines = 8;
  int max_lidar_lines = 180;
  int max_visual_lines = 120;
  double line_weight = 0.2;
  double direction_weight = 0.05;
  double fusion_pixel_gate = 8.0;
  double local_map_radius = 70.0;
  int map_cleanup_interval = 4;
};

struct OplLvioDogfoodingOptions {
  double source_voxel_size = 0.45;
  size_t max_source_points = 5500;
  double voxel_size = 1.0;
  double registration_voxel_size = 0.9;
  int max_registration_points = 4200;
  int image_width = 1024;
  int image_height = 64;
  int max_icp_iterations = 24;
  double max_correspondence_dist = 2.0;
  int min_visual_points = 20;
  int max_visual_points = 320;
  int min_visual_lines = 8;
  int max_lidar_lines = 180;
  int max_visual_lines = 120;
  double visual_point_weight = 0.08;
  double line_weight = 0.0;
  double direction_weight = 0.0;
  double helmert_min_scale = 0.25;
  double helmert_max_scale = 4.0;
  double fusion_pixel_gate = 8.0;
  double local_map_radius = 70.0;
  int map_cleanup_interval = 4;
};

struct VisualLidarAdapterDogfoodingOptions {
  double source_voxel_size = 0.45;
  size_t max_source_points = 5500;
  double voxel_size = 1.0;
  double registration_voxel_size = 0.9;
  int max_registration_points = 4200;
  int image_width = 1024;
  int image_height = 64;
  int max_icp_iterations = 24;
  double max_correspondence_dist = 2.0;
  int min_visual_points = 12;
  int max_visual_points = 300;
  int min_visual_lines = 4;
  int max_lidar_lines = 180;
  int max_visual_lines = 120;
  double local_map_radius = 70.0;
  int map_cleanup_interval = 4;
};

bool applyVisualLidarAdapterProfileArg(
    const std::string& arg, const std::string& flag_prefix,
    VisualLidarAdapterDogfoodingOptions* options) {
  if (arg == "--" + flag_prefix + "-fast-profile") {
    options->source_voxel_size = 0.55;
    options->max_source_points = 3500;
    options->voxel_size = 1.1;
    options->registration_voxel_size = 1.0;
    options->max_registration_points = 2800;
    options->image_width = 768;
    options->image_height = 64;
    options->max_icp_iterations = 18;
    options->max_lidar_lines = 120;
    options->max_visual_lines = 80;
    options->local_map_radius = 55.0;
    options->map_cleanup_interval = 3;
    return true;
  }
  if (arg == "--" + flag_prefix + "-dense-profile") {
    options->source_voxel_size = 0.35;
    options->max_source_points = 7000;
    options->voxel_size = 0.8;
    options->registration_voxel_size = 0.7;
    options->max_registration_points = 5500;
    options->image_width = 1024;
    options->image_height = 80;
    options->max_icp_iterations = 32;
    options->max_visual_points = 420;
    options->max_lidar_lines = 220;
    options->max_visual_lines = 160;
    options->local_map_radius = 80.0;
    options->map_cleanup_interval = 5;
    return true;
  }
  return false;
}

struct TricpLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int normal_min_neighbors = 5;
  double planarity_threshold = 0.5;
  double max_correspondence_dist = 2.0;
  int max_iterations = 20;
  bool auto_overlap = true;
  double overlap_ratio = 0.9;
  double min_overlap = 0.8;
  double frmsd_lambda = 1.5;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct KcLoDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 20;
  int max_iterations = 20;
  double kc_sigma = 0.5;
  double kc_sigma_init = 2.0;
  double kc_anneal = 0.7;
  double kc_radius_factor = 3.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct DegenSenseDogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double planarity_threshold = 0.5;
  double initial_threshold = 1.5;
  int warmup_frames = 10;
  double mad_k = 3.0;
  double gyro_bias_gain = 0.3;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct VibrationLIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double planarity_threshold = 0.5;
  double max_correspondence_dist = 2.0;
  double sigma_depth = 0.02;
  double sigma_bearing = 0.0015;
  double gamma = 0.1;
  double scan_period = 0.1;
  double gyro_bias_gain = 0.3;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct IDLIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double max_correspondence_dist = 2.0;
  int range_image_width = 1024;
  int range_image_height = 64;
  double new_object_margin = 1.0;
  double disappearance_margin = 1.0;
  double dynamic_weight = 0.15;
  int delayed_removal_frames = 3;
  double gyro_bias_gain = 0.2;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct RFLIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double max_correspondence_dist = 2.0;
  int range_image_width = 1024;
  int range_image_height = 64;
  double new_object_margin = 1.0;
  double disappearance_margin = 1.0;
  double dynamic_weight = 0.10;
  int delayed_removal_frames = 1;
  double foreground_margin = 0.9;
  double max_removal_fraction = 0.30;
  int min_keep_points = 1000;
  double gyro_bias_gain = 0.2;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct BievrLIODogfoodingOptions {
  double source_voxel_size = 0.4;
  size_t max_source_points = 6000;
  double voxel_size = 1.0;
  int voxel_min_points = 8;
  double planarity_ratio = 0.15;
  double pixel_res = 0.25;
  int max_icp_iterations = 30;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct UALIODogfoodingOptions {
  double source_voxel_size = 0.5;
  size_t max_source_points = 4500;
  double voxel_size = 1.0;
  int voxel_min_points = 6;
  int max_icp_iterations = 30;
  double max_correspondence_dist = 2.0;
  bool ground_constraint = true;
  double ground_weight = 0.5;
  double gyro_bias_gain = 0.3;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct CubeLIODogfoodingOptions {
  double input_voxel_size = 0.4;
  size_t max_input_points = 60000;
  double voxel_size = 1.0;
  int max_points_per_voxel = 12;
  int max_icp_iterations = 30;
  double planarity_threshold = 0.5;
  double initial_threshold = 1.5;
  int cubemap_size = 256;
  double gaussian_sigma = 1.0;
  double semi_dense_quantile = 0.6;
  double intensity_sigma = 30.0;
  double local_map_radius = 60.0;
  int map_cleanup_interval = 4;
};

struct CTICPDogfoodingOptions {
  // Reproduction-oriented default. This matches the robust KITTI tune recorded
  // in docs/reproduction_status.md and avoids the older lightweight profile's
  // paper-comparable RPE regression.
  double source_voxel_size = 0.6;
  size_t max_source_points = 700;
  double voxel_resolution = 1.2;
  int max_iterations = 10;
  int ceres_max_iterations = 6;
  double planarity_threshold = 0.06;
  double keypoint_voxel_size = 1.0;
  int max_frames_in_map = 20;
  // <=0 leaves the algorithm-level default of 100 m^2 unchanged. Override via
  // --ct-icp-max-correspondence-distance for paper-style tighter outlier
  // rejection (paper uses 1-2 m^2, i.e. 1-1.4 m linear).
  double max_correspondence_dist = -1.0;
  int knn = -1;  // <=0 keeps algorithm default (5).
  // Architecture-level extensions enabled by --ct-icp-paper-arch.
  bool multi_scale_correspondences = true;
  bool use_normal_cholesky_solver = true;
  // LiTAMIN2/X-ICP 風の "refinement-acceptance gate" + velocity-model bootstrap。
  // CT-ICP は素朴な constant-velocity 外挿だと急カーブで発散するため、結果が
  // 大きく seed から逸れた場合は予測値にロールバックして発散を抑える。
  bool refinement_gate = false;
  double max_seed_translation_delta = 2.0;
  double max_seed_rotation_delta_rad = 0.25;
  // Seed source for the gate: when false (default), body-frame constant velocity
  // from (T_prev_prev_world, T_prev_world); when true, CT-ICP's own (begin_pose,
  // end_pose) intra-scan delta is extrapolated one scan period forward.
  bool native_ct_icp_seed = false;

  // Paper weight scheme (Gap B+D+E+F bundle).
  // 個別フラグで isolation ablation 可能。
  double power_planarity = 1.0;
  double weight_alpha = 1.0;
  double weight_neighborhood = 0.0;
  double min_planarity_floor = 0.0;
  bool flat_regularizer_weight = false;
  // 既定 -1 で CTICPParams::cauchy_loss_param=0.5 を維持。
  // paper 既定は 0.1。
  double cauchy_loss_param = -1.0;
  // <=0 で N_corr 全数 (現状)。正値で sqrt(min(N_corr, cap) * β)。
  int regularizer_n_cap = 0;
  bool auto_regularizer_cap = false;
  int auto_regularizer_low_cap = 30;
  int auto_regularizer_warmup_frames = 20;
  double auto_regularizer_max_step = 0.8;
  double auto_regularizer_min_rot_per_meter = 0.05;

  // Pick 2 / Gap A: closest-neighbor reference + larger PCA neighborhood.
  bool use_closest_neighbor_reference = false;
  int pca_neighbor_count = 0;  // 0 で knn と同じ。paper は 20。
  // Pick 2 / Gap C: min-distance voxel insertion. 単位 m。0 で無効。paper は 0.1。
  double min_distance_between_points = 0.0;

  // Coarse-to-fine 2-phase schedule.
  bool coarse_to_fine = false;
  int coarse_iterations = 3;
  int coarse_search_radius = 2;
  double coarse_planarity_threshold = 0.05;
  double coarse_cauchy_sigma_mult = 2.0;

  // Continuous-time trajectory regularization weights. <0 leaves the
  // algorithm-level defaults (all 0.001) unchanged. These tie the current
  // frame's begin pose to the previous end pose (location/orientation) and
  // enforce constant velocity across the scan, so they trade local
  // registration freedom for trajectory smoothness (drift control).
  double location_consistency_weight = -1.0;
  double orientation_consistency_weight = -1.0;
  double constant_velocity_weight = -1.0;
  // --ct-icp-upstream-mechanics: run the dedicated pipeline that follows
  // upstream jedeschaud/ct_icp with config/odometry/driving_config.yaml
  // (runCTICPUpstream). The other CT-ICP options are ignored in that mode.
  bool upstream_mechanics = false;
  // Comma-separated mechanisms to switch off in that mode, for ablation
  // (--ct-icp-upstream-disable): startup, cv-init, rigid-start, radius,
  // farthest-ref, std-a2d, nb-weight, residual-cap, stop, prune,
  // insert-gate, mid-pose, azimuth-time, persistent-map.
  std::string upstream_disable;
};

struct CTICPNDTHybridOptions {
  int keyframe_interval = 5;
  double max_correction_translation_delta = 0.5;
  double max_correction_rotation_delta_rad = 0.35;
  // <=0 disables score gating because NDT score scale is dataset/profile
  // dependent in this dogfooding implementation.
  double max_ndt_score = -1.0;
};

struct FixedMapNDTOptions {
  int map_stride = 1;
  std::string map_ply_path;
  std::string seed_source = "gt";  // gt, velocity, ct_icp, scan_context
  double scan_context_distance_threshold = 0.18;
  int scan_context_top_k = 1;
  std::string trace_json_path;
  int publish_min_stable_frames = 5;
  int publish_max_hold_frames = 3;
  int scan_context_relock_min_confirmations = 2;
  double scan_context_relock_max_distance = 0.05;
  double scan_context_relock_max_ndt_score = 1.2;
  double scan_context_relock_max_score_delta = 0.25;
};

struct FixedMapNDTTraceFrame {
  size_t frame_index = 0;
  std::string decision = "unprocessed";
  std::string seed_source;
  bool accepted = false;
  bool seed_fallback = false;
  bool scan_context_hit = false;
  int scan_context_candidate_count = 0;
  int scan_context_candidates_evaluated = 0;
  int selected_candidate_index = -1;
  double scan_context_front_distance = std::numeric_limits<double>::quiet_NaN();
  double selected_candidate_distance = std::numeric_limits<double>::quiet_NaN();
  double selected_candidate_yaw_offset_rad = std::numeric_limits<double>::quiet_NaN();
  double ndt_score = std::numeric_limits<double>::quiet_NaN();
  int ndt_iterations = 0;
  bool ndt_converged = false;
  double seed_translation_error_m = std::numeric_limits<double>::quiet_NaN();
  double seed_rotation_error_rad = std::numeric_limits<double>::quiet_NaN();
  double refined_translation_error_m = std::numeric_limits<double>::quiet_NaN();
  double refined_rotation_error_rad = std::numeric_limits<double>::quiet_NaN();
  double final_translation_error_m = std::numeric_limits<double>::quiet_NaN();
  double final_rotation_error_rad = std::numeric_limits<double>::quiet_NaN();
  double correction_translation_delta_m = std::numeric_limits<double>::quiet_NaN();
  double correction_rotation_delta_rad = std::numeric_limits<double>::quiet_NaN();
  double final_step_m = std::numeric_limits<double>::quiet_NaN();
  double gt_step_m = std::numeric_limits<double>::quiet_NaN();
  std::string publish_action = "not_evaluated";
  std::string publish_state = "not_evaluated";
  std::string publish_gate_reason;
  std::string gt_safety_state = "not_evaluated";
  bool allow_pose_publish = false;
  bool has_pose_output = false;
  bool runtime_refinement_candidate = false;
  bool relock_candidate = false;
  bool relock_sequence_compatible = false;
  bool gt_wrong_pose = false;
  bool gt_recovery_transition = false;
  bool gt_unsafe_transition = false;
  int runtime_refinement_streak = 0;
  int relock_streak = 0;
  int relock_candidate_index_delta = 0;
  int relock_frame_gap = 0;
  int publish_hold_age_frames = 0;
  double published_translation_error_m = std::numeric_limits<double>::quiet_NaN();
  std::string relock_rejected_reason;
  Eigen::Matrix4d seed_pose = Eigen::Matrix4d::Identity();
  Eigen::Matrix4d refined_pose = Eigen::Matrix4d::Identity();
  Eigen::Matrix4d final_pose = Eigen::Matrix4d::Identity();
  Eigen::Matrix4d gt_pose = Eigen::Matrix4d::Identity();
  Eigen::Matrix4d published_pose = Eigen::Matrix4d::Identity();
};

struct FixedMapNDTPublishPolicyState {
  int runtime_refinement_streak = 0;
  int hold_streak = 0;
  bool has_last_published_pose = false;
  size_t last_published_frame = 0;
  Eigen::Matrix4d last_published_pose = Eigen::Matrix4d::Identity();
  int scan_context_relock_streak = 0;
  bool has_last_scan_context_relock = false;
  size_t last_scan_context_relock_frame = 0;
  int last_scan_context_relock_candidate_index = -1;
  double last_scan_context_relock_score =
      std::numeric_limits<double>::quiet_NaN();
};

MethodResult runCTICP(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const CTICPDogfoodingOptions& options,
                      bool gt_seed);

struct DLODofeedingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  double registration_voxel_size = 0.5;
  double map_voxel_size = 0.8;
  double keyframe_translation_threshold = 0.6;
  double keyframe_rotation_threshold_rad = 8.0 * 3.14159265358979323846 / 180.0;
  int max_keyframes_in_map = 30;
  int gicp_k_neighbors = 15;
  double gicp_max_correspondence_distance = 4.0;
  int gicp_max_iterations = 25;
  double gicp_rotation_epsilon = 1e-4;
  double gicp_translation_epsilon = 1e-4;
  double gicp_covariance_regularization = 1e-3;
  double gicp_fitness_epsilon = 1e-6;
};

struct DLIODogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  double registration_voxel_size = 0.5;
  double map_voxel_size = 0.8;
  double keyframe_translation_threshold = 0.6;
  double keyframe_rotation_threshold_rad = 8.0 * 3.14159265358979323846 / 180.0;
  int max_keyframes_in_map = 30;
  int gicp_k_neighbors = 15;
  double gicp_max_correspondence_distance = 4.0;
  int gicp_max_iterations = 25;
  double gicp_rotation_epsilon = 1e-4;
  double gicp_translation_epsilon = 1e-4;
  double gicp_covariance_regularization = 1e-3;
  double gicp_fitness_epsilon = 1e-6;
  double imu_rotation_fusion_weight = 0.15;
  double imu_translation_fusion_weight = 0.2;
  double imu_velocity_fusion_weight = 0.2;
  double lidar_confidence_correspondence_scale = 100.0;
};

struct XICPDogfoodingOptions {
  double source_voxel_size = 1.0;
  size_t max_source_points = 2500;
  int max_iterations = 30;
  double convergence_threshold = 1e-5;
  double kappa_f = 0.1736;
  double kappa_s = 0.707;
  int k_neighbors = 10;
  double max_correspondence_distance = 3.0;
  size_t map_max_points = 40000;
  size_t refresh_interval = 4;
  double map_radius = 45.0;
  double max_seed_translation_delta = 2.0;
  double max_seed_rotation_delta_rad = 0.25;
};

struct FastLio2DogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  int max_iterations = 8;
  int ceres_max_iterations = 6;
  double voxel_resolution = 1.0;
  double keypoint_voxel_size = 0.5;
  int knn = 5;
  double max_correspondence_distance = 3.0;
  double planarity_threshold = 0.1;
  int max_frames_in_map = 30;
};

struct HdlGraphSlamDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  double registration_voxel_size = 0.7;
  double map_voxel_size = 1.0;
  int keyframe_stride = 1;
  int max_keyframes_in_submap = 30;
  size_t loop_stride = 3;
  bool enable_loop_closure = true;
  bool enable_floor_constraint = true;
};

struct VgicpSlamDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  double registration_voxel_size = 0.4;
  double map_voxel_size = 0.6;
  int keyframe_stride = 1;
  int max_keyframes_in_submap = 30;
  size_t loop_stride = 3;
  bool enable_loop_closure = true;
};

struct SuMaDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 80.0;
  double surfel_resolution = 0.4;
  int surfel_stride = 1;
  int max_iterations = 4;
  int max_frames_in_map = 20;
  int n_scans = 16;
  // Paper pipeline (SuMaPaper): raw scans, official default.xml values.
  bool paper = false;
  std::vector<std::pair<std::string, double>> paper_overrides;
};

struct Balm2DogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double corner_resolution = 0.3;
  double surface_resolution = 0.6;
  int corner_stride = 2;
  int surface_stride = 3;
  int window_size = 5;
  int num_outer_iterations = 2;
  int ceres_max_iterations = 6;
};

struct IscLoamDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  int keyframe_stride = 1;
  size_t loop_stride = 3;
  bool enable_loop_closure = true;
};

struct LoamLivoxDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  float less_flat_leaf_size = 0.2f;
  int odom_outer_iters = 2;
  int map_outer_iters = 2;
  double map_line_resolution = 0.4;
  double map_plane_resolution = 0.8;
};

struct LioSamDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  int keyframe_stride = 1;
  bool enable_loop_closure = true;
  bool enable_imu_rotation_prior = true;
};

struct LINSDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  double registration_voxel_size = 0.5;
  double map_voxel_size = 0.8;
  int max_correspondences = 200;
  int max_keyframes_in_map = 30;
};

struct FastLioSlamDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  int max_iterations = 8;
  int ceres_max_iterations = 6;
  double voxel_resolution = 1.0;
  double keypoint_voxel_size = 0.5;
  int max_frames_in_map = 30;
  int keyframe_stride = 1;
  size_t loop_stride = 4;
  bool enable_loop_closure = true;
};

struct PointLioDogfoodingOptions {
  double input_voxel_size = 0.5;
  size_t max_input_points = 6000;
  double min_range = 1.0;
  double max_range = 100.0;
  double registration_voxel_size = 0.4;
  double map_voxel_size = 0.7;
  int max_correspondences = 250;
  int max_keyframes_in_map = 30;
};

struct CLINSDogfoodingOptions {
  double source_voxel_size = 0.75;
  size_t max_source_points = 500;
};

/// ワールド座標に変換
std::vector<Eigen::Vector3d> transformPoints(
    const std::vector<Eigen::Vector3d>& pts, const Eigen::Matrix4d& T) {
  Eigen::Matrix3d R = T.block<3, 3>(0, 0);
  Eigen::Vector3d t = T.block<3, 1>(0, 3);
  std::vector<Eigen::Vector3d> out;
  out.reserve(pts.size());
  for (auto& p : pts) out.push_back(R * p + t);
  return out;
}

void compactPointMap(std::vector<Eigen::Vector3d>& map_points,
                     size_t max_points) {
  if (map_points.size() <= max_points) return;
  const size_t tail_keep = std::min(map_points.size(), max_points * 3 / 4);
  const size_t head_keep = max_points - tail_keep;

  std::vector<Eigen::Vector3d> compacted;
  compacted.reserve(max_points);
  if (head_keep > 0) {
    const size_t head_size = map_points.size() - tail_keep;
    if (head_size > 0) {
      const double step = static_cast<double>(head_size) / head_keep;
      for (size_t i = 0; i < head_keep; i++) {
        size_t idx = std::min(static_cast<size_t>(i * step), head_size - 1);
        compacted.push_back(map_points[idx]);
      }
    }
  }
  compacted.insert(compacted.end(), map_points.end() - tail_keep, map_points.end());
  map_points.swap(compacted);
}

void prunePointMapByRadius(std::vector<Eigen::Vector3d>& map_points,
                           const Eigen::Vector3d& center,
                           double radius) {
  if (radius <= 0.0 || map_points.empty()) return;

  const double radius_sq = radius * radius;
  std::vector<Eigen::Vector3d> filtered;
  filtered.reserve(map_points.size());
  for (const auto& point : map_points) {
    if ((point - center).squaredNorm() <= radius_sq) {
      filtered.push_back(point);
    }
  }
  map_points.swap(filtered);
}

void addPointsToMap(std::vector<Eigen::Vector3d>& map_points,
                    const std::vector<Eigen::Vector3d>& local_points,
                    const Eigen::Matrix4d& pose,
                    size_t max_points,
                    double local_map_radius = 0.0) {
  auto points_world = transformPoints(local_points, pose);
  map_points.insert(map_points.end(), points_world.begin(), points_world.end());
  prunePointMapByRadius(map_points, pose.block<3, 1>(0, 3), local_map_radius);
  compactPointMap(map_points, max_points);
}

Eigen::Matrix4d anchorRelativePose(const Eigen::Matrix4d& anchor_pose,
                                   const Eigen::Matrix4d& relative_pose) {
  return anchor_pose * relative_pose;
}

bool shouldRefreshTargetMap(size_t frame_index, size_t refresh_interval) {
  return frame_index <= 1 || refresh_interval <= 1 ||
         (frame_index % refresh_interval) == 0;
}

double poseTranslationDelta(const Eigen::Matrix4d& lhs,
                            const Eigen::Matrix4d& rhs) {
  return (lhs.block<3, 1>(0, 3) - rhs.block<3, 1>(0, 3)).norm();
}

double poseRotationDelta(const Eigen::Matrix4d& lhs,
                         const Eigen::Matrix4d& rhs) {
  const Eigen::Matrix3d dR =
      lhs.block<3, 3>(0, 0).transpose() * rhs.block<3, 3>(0, 0);
  Eigen::AngleAxisd aa(dR);
  if (!std::isfinite(aa.angle())) {
    return std::numeric_limits<double>::infinity();
  }
  return std::abs(aa.angle());
}

Eigen::Matrix4d interpolateTransform(const Eigen::Matrix4d& lhs,
                                     const Eigen::Matrix4d& rhs,
                                     double alpha) {
  alpha = std::clamp(alpha, 0.0, 1.0);
  const Eigen::Matrix4d relative = lhs.inverse() * rhs;
  Eigen::Quaterniond relative_rotation(relative.block<3, 3>(0, 0));
  relative_rotation.normalize();
  Eigen::Matrix4d scaled = Eigen::Matrix4d::Identity();
  scaled.block<3, 3>(0, 0) =
      Eigen::Quaterniond::Identity().slerp(alpha, relative_rotation).toRotationMatrix();
  scaled.block<3, 1>(0, 3) = alpha * relative.block<3, 1>(0, 3);
  return lhs * scaled;
}

bool isReasonableRefinement(const Eigen::Matrix4d& refined_pose,
                            const Eigen::Matrix4d& seed_pose,
                            double max_translation_delta,
                            double max_rotation_delta_rad) {
  return poseTranslationDelta(refined_pose, seed_pose) <= max_translation_delta &&
         poseRotationDelta(refined_pose, seed_pose) <= max_rotation_delta_rad;
}

double poseTranslationErrorToGT(const Eigen::Matrix4d& pose,
                                const std::vector<Eigen::Matrix4d>& gt,
                                size_t frame_index) {
  if (frame_index >= gt.size() || !isFiniteMatrix(pose)) {
    return std::numeric_limits<double>::quiet_NaN();
  }
  return poseTranslationDelta(pose, gt[frame_index]);
}

double poseRotationErrorToGT(const Eigen::Matrix4d& pose,
                             const std::vector<Eigen::Matrix4d>& gt,
                             size_t frame_index) {
  if (frame_index >= gt.size() || !isFiniteMatrix(pose)) {
    return std::numeric_limits<double>::quiet_NaN();
  }
  return poseRotationDelta(pose, gt[frame_index]);
}

void finalizeFixedMapNDTTraceFrame(FixedMapNDTTraceFrame& frame,
                                   const std::vector<Eigen::Matrix4d>& gt,
                                   const Eigen::Matrix4d* previous_final_pose) {
  const size_t i = frame.frame_index;
  if (i < gt.size()) {
    frame.gt_pose = gt[i];
  }
  frame.seed_translation_error_m =
      poseTranslationErrorToGT(frame.seed_pose, gt, i);
  frame.seed_rotation_error_rad = poseRotationErrorToGT(frame.seed_pose, gt, i);
  frame.refined_translation_error_m =
      poseTranslationErrorToGT(frame.refined_pose, gt, i);
  frame.refined_rotation_error_rad =
      poseRotationErrorToGT(frame.refined_pose, gt, i);
  frame.final_translation_error_m =
      poseTranslationErrorToGT(frame.final_pose, gt, i);
  frame.final_rotation_error_rad =
      poseRotationErrorToGT(frame.final_pose, gt, i);
  frame.correction_translation_delta_m =
      poseTranslationDelta(frame.final_pose, frame.seed_pose);
  frame.correction_rotation_delta_rad =
      poseRotationDelta(frame.final_pose, frame.seed_pose);
  if (previous_final_pose != nullptr) {
    frame.final_step_m = poseTranslationDelta(frame.final_pose, *previous_final_pose);
  }
  if (i > 0 && i < gt.size()) {
    frame.gt_step_m = poseTranslationDelta(gt[i], gt[i - 1]);
  }
}

bool fixedMapNDTTraceHasWrongPose(const FixedMapNDTTraceFrame& frame) {
  return !std::isfinite(frame.final_translation_error_m) ||
         frame.final_translation_error_m > 1.0;
}

double finiteRatio(double numerator, double denominator) {
  if (!std::isfinite(numerator) || !std::isfinite(denominator) ||
      denominator <= 1e-9) {
    return std::numeric_limits<double>::quiet_NaN();
  }
  return numerator / denominator;
}

void annotateFixedMapNDTGTSafety(FixedMapNDTTraceFrame& frame,
                                 const FixedMapNDTTraceFrame* previous_frame) {
  frame.gt_wrong_pose = fixedMapNDTTraceHasWrongPose(frame);
  const double step_ratio = finiteRatio(frame.final_step_m, frame.gt_step_m);
  const double previous_error =
      previous_frame ? previous_frame->final_translation_error_m
                     : std::numeric_limits<double>::quiet_NaN();
  const double transition_error_delta =
      (std::isfinite(previous_error) &&
       std::isfinite(frame.final_translation_error_m))
          ? previous_error - frame.final_translation_error_m
          : std::numeric_limits<double>::quiet_NaN();
  const bool is_jump = std::isfinite(step_ratio) && step_ratio > 3.0;
  frame.gt_recovery_transition =
      is_jump && std::isfinite(transition_error_delta) &&
      transition_error_delta >= 1.0 &&
      std::isfinite(frame.final_translation_error_m) &&
      frame.final_translation_error_m <= 1.0;
  frame.gt_unsafe_transition =
      is_jump && !frame.gt_recovery_transition &&
      (!std::isfinite(frame.final_translation_error_m) ||
       frame.final_translation_error_m > 1.0 ||
       (std::isfinite(transition_error_delta) &&
        transition_error_delta < 0.0));

  if (frame.gt_unsafe_transition) {
    frame.gt_safety_state = "unsafe_transition";
  } else if (frame.gt_recovery_transition) {
    frame.gt_safety_state = "recovery_transition";
  } else if (frame.gt_wrong_pose) {
    frame.gt_safety_state = "wrong_pose";
  } else {
    frame.gt_safety_state = "inside_publish_envelope";
  }
}

bool fixedMapNDTRuntimeRefinementCandidate(const FixedMapNDTTraceFrame& frame) {
  return frame.accepted && !frame.seed_fallback &&
         isFiniteMatrix(frame.final_pose) && std::isfinite(frame.ndt_score) &&
         (frame.ndt_converged || frame.ndt_iterations >= 2);
}

bool fixedMapNDTScanContextRelockCandidate(
    FixedMapNDTTraceFrame& frame,
    const FixedMapNDTOptions& options) {
  frame.relock_candidate = false;
  if (options.seed_source != "scan_context") {
    frame.relock_rejected_reason = "not_scan_context_seed";
    return false;
  }
  if (!frame.runtime_refinement_candidate) {
    frame.relock_rejected_reason = "not_runtime_refinement_candidate";
    return false;
  }
  if (frame.selected_candidate_index < 0) {
    frame.relock_rejected_reason = "missing_selected_global_candidate";
    return false;
  }
  if (!std::isfinite(frame.selected_candidate_distance) ||
      frame.selected_candidate_distance >
          options.scan_context_relock_max_distance) {
    frame.relock_rejected_reason = "scan_context_distance_too_large";
    return false;
  }
  if (!std::isfinite(frame.ndt_score) ||
      frame.ndt_score > options.scan_context_relock_max_ndt_score) {
    frame.relock_rejected_reason = "ndt_score_too_large_for_relock";
    return false;
  }
  frame.relock_candidate = true;
  frame.relock_rejected_reason.clear();
  return true;
}

void updateFixedMapNDTScanContextRelockState(
    FixedMapNDTTraceFrame& frame,
    const FixedMapNDTOptions& options,
    FixedMapNDTPublishPolicyState& state) {
  if (!fixedMapNDTScanContextRelockCandidate(frame, options)) {
    frame.relock_streak = state.scan_context_relock_streak;
    return;
  }

  bool compatible = true;
  if (state.has_last_scan_context_relock) {
    const int index_delta =
        frame.selected_candidate_index -
        state.last_scan_context_relock_candidate_index;
    const int frame_gap =
        static_cast<int>(frame.frame_index -
                         state.last_scan_context_relock_frame);
    const int expected_frame_gap =
        index_delta * std::max(1, options.map_stride);
    const int tolerance = std::max(1, std::max(1, options.map_stride) / 2);
    const double score_delta =
        std::isfinite(state.last_scan_context_relock_score)
            ? std::abs(frame.ndt_score - state.last_scan_context_relock_score)
            : 0.0;
    frame.relock_candidate_index_delta = index_delta;
    frame.relock_frame_gap = frame_gap;
    compatible =
        index_delta > 0 &&
        std::abs(frame_gap - expected_frame_gap) <= tolerance &&
        score_delta <= options.scan_context_relock_max_score_delta;
  }

  frame.relock_sequence_compatible = compatible;
  if (compatible) {
    state.scan_context_relock_streak =
        state.has_last_scan_context_relock
            ? state.scan_context_relock_streak + 1
            : 1;
  } else {
    state.scan_context_relock_streak = 1;
    frame.relock_rejected_reason = "relock_sequence_incompatible_reset";
  }
  state.has_last_scan_context_relock = true;
  state.last_scan_context_relock_frame = frame.frame_index;
  state.last_scan_context_relock_candidate_index =
      frame.selected_candidate_index;
  state.last_scan_context_relock_score = frame.ndt_score;
  frame.relock_streak = state.scan_context_relock_streak;
}

void returnUnknownFixedMapNDTPublish(FixedMapNDTTraceFrame& frame,
                                     FixedMapNDTPublishPolicyState& state,
                                     const std::string& publish_state,
                                     const std::string& reason) {
  frame.publish_action = "return_unknown";
  frame.publish_state = publish_state;
  frame.publish_gate_reason = reason;
  frame.allow_pose_publish = false;
  frame.has_pose_output = false;
  frame.publish_hold_age_frames = 0;
  state.hold_streak = 0;
}

void annotateFixedMapNDTPublishPolicy(
    FixedMapNDTTraceFrame& frame,
    const FixedMapNDTOptions& options,
    FixedMapNDTPublishPolicyState& state,
    const FixedMapNDTTraceFrame* previous_frame) {
  annotateFixedMapNDTGTSafety(frame, previous_frame);
  frame.runtime_refinement_candidate =
      fixedMapNDTRuntimeRefinementCandidate(frame);

  if (frame.decision == "anchor") {
    state.runtime_refinement_streak = 0;
    returnUnknownFixedMapNDTPublish(
        frame, state, "anchor_frame",
        "initial anchor is not a runtime publish proof");
    return;
  }

  if (options.seed_source == "gt") {
    state.runtime_refinement_streak = 0;
    returnUnknownFixedMapNDTPublish(
        frame, state, "lab_only_oracle_seed",
        "GT seed validates the localizer but is not deployable");
    return;
  }

  if (!frame.runtime_refinement_candidate) {
    state.runtime_refinement_streak = 0;
    const std::string publish_state =
        frame.seed_fallback ? "seed_fallback_unknown"
                            : "refinement_rejected_unknown";
    const std::string reason =
        frame.seed_fallback
            ? "seed fallback has no fixed-map verification"
            : "NDT refinement was not accepted by runtime gates";
    if (options.seed_source != "scan_context" &&
        state.has_last_published_pose &&
        state.hold_streak < std::max(0, options.publish_max_hold_frames)) {
      ++state.hold_streak;
      frame.publish_action = "hold_last_pose";
      frame.publish_state = publish_state;
      frame.publish_gate_reason = reason;
      frame.allow_pose_publish = true;
      frame.has_pose_output = true;
      frame.publish_hold_age_frames =
          static_cast<int>(frame.frame_index - state.last_published_frame);
      frame.published_pose = state.last_published_pose;
      frame.published_translation_error_m =
          poseTranslationDelta(frame.published_pose, frame.gt_pose);
    } else {
      returnUnknownFixedMapNDTPublish(frame, state, publish_state, reason);
    }
    return;
  }

  ++state.runtime_refinement_streak;
  frame.runtime_refinement_streak = state.runtime_refinement_streak;
  if (options.seed_source == "scan_context") {
    updateFixedMapNDTScanContextRelockState(frame, options, state);
    if (!frame.relock_candidate) {
      returnUnknownFixedMapNDTPublish(
          frame, state, "relock_candidate_rejected",
          frame.relock_rejected_reason.empty()
              ? "Scan Context candidate failed relock gates"
              : frame.relock_rejected_reason);
      return;
    }
    if (!frame.relock_sequence_compatible ||
        frame.relock_streak <
            std::max(1, options.scan_context_relock_min_confirmations)) {
      returnUnknownFixedMapNDTPublish(
          frame, state, "warming_up_relock_sequence",
          "Scan Context relock needs another sequence-compatible confirmation");
      return;
    }

    state.hold_streak = 0;
    state.has_last_published_pose = true;
    state.last_published_frame = frame.frame_index;
    state.last_published_pose = frame.final_pose;
    frame.publish_action = "publish_pose";
    frame.publish_state = "scan_context_relock_verified";
    frame.publish_gate_reason =
        "Scan Context descriptor, NDT score, and relock sequence are consistent";
    frame.allow_pose_publish = true;
    frame.has_pose_output = true;
    frame.publish_hold_age_frames = 0;
    frame.published_pose = frame.final_pose;
    frame.published_translation_error_m = frame.final_translation_error_m;
    return;
  }

  if (state.runtime_refinement_streak <
      std::max(1, options.publish_min_stable_frames)) {
    returnUnknownFixedMapNDTPublish(
        frame, state, "warming_up_stable_refinement",
        "runtime refinement streak is shorter than the publish threshold");
    return;
  }

  state.hold_streak = 0;
  state.has_last_published_pose = true;
  state.last_published_frame = frame.frame_index;
  state.last_published_pose = frame.final_pose;
  frame.publish_action = "publish_pose";
  frame.publish_state = "runtime_stable_refinement";
  frame.publish_gate_reason =
      "accepted runtime refinement passed the stable publish threshold";
  frame.allow_pose_publish = true;
  frame.has_pose_output = true;
  frame.publish_hold_age_frames = 0;
  frame.published_pose = frame.final_pose;
  frame.published_translation_error_m = frame.final_translation_error_m;
}

void writeFixedMapNDTTraceJson(const std::string& path,
                               const FixedMapNDTOptions& options,
                               size_t num_frames,
                               size_t map_points,
                               const std::vector<FixedMapNDTTraceFrame>& frames) {
  if (path.empty()) return;
  const fs::path out_path(path);
  if (!out_path.parent_path().empty()) {
    fs::create_directories(out_path.parent_path());
  }

  auto write_number = [](std::ostream& out, double value) {
    if (std::isfinite(value)) {
      out << std::fixed << std::setprecision(9) << value;
    } else {
      out << "null";
    }
  };
  auto write_bool = [](std::ostream& out, bool value) {
    out << (value ? "true" : "false");
  };
  auto write_pose = [&write_number](std::ostream& out,
                                    const Eigen::Matrix4d& pose) {
    out << "[";
    for (int r = 0; r < 4; r++) {
      for (int c = 0; c < 4; c++) {
        if (r != 0 || c != 0) out << ", ";
        write_number(out, pose(r, c));
      }
    }
    out << "]";
  };

  std::ofstream out(path);
  out << "{\n";
  out << "  \"trace_version\": \"fixed_map_ndt_trace_v2\",\n";
  out << "  \"map_ply\": \"" << jsonEscape(options.map_ply_path) << "\",\n";
  out << "  \"seed_source\": \"" << jsonEscape(options.seed_source) << "\",\n";
  out << "  \"map_stride\": " << std::max(1, options.map_stride) << ",\n";
  out << "  \"scan_context_distance_threshold\": ";
  write_number(out, options.scan_context_distance_threshold);
  out << ",\n";
  out << "  \"scan_context_top_k\": "
      << std::max(1, options.scan_context_top_k) << ",\n";
  out << "  \"publish_policy\": {\n";
  out << "    \"policy_version\": \"fixed_map_ndt_runtime_publish_policy_v1\",\n";
  out << "    \"gt_safety_label_version\": \"fixed_map_ndt_trace_gt_safety_v1\",\n";
  out << "    \"publish_error_m\": 1.000000000,\n";
  out << "    \"jump_step_ratio\": 3.000000000,\n";
  out << "    \"recovery_error_drop_m\": 1.000000000,\n";
  out << "    \"min_stable_frames\": "
      << std::max(1, options.publish_min_stable_frames) << ",\n";
  out << "    \"max_hold_frames\": "
      << std::max(0, options.publish_max_hold_frames) << ",\n";
  out << "    \"scan_context_relock_min_confirmations\": "
      << std::max(1, options.scan_context_relock_min_confirmations) << ",\n";
  out << "    \"scan_context_relock_max_distance\": ";
  write_number(out, options.scan_context_relock_max_distance);
  out << ",\n";
  out << "    \"scan_context_relock_max_ndt_score\": ";
  write_number(out, options.scan_context_relock_max_ndt_score);
  out << ",\n";
  out << "    \"scan_context_relock_max_score_delta\": ";
  write_number(out, options.scan_context_relock_max_score_delta);
  out << ",\n";
  out << "    \"scan_context_publish_requires_relock_sequence_verifier\": true\n";
  out << "  },\n";
  out << "  \"num_frames\": " << num_frames << ",\n";
  out << "  \"map_points\": " << map_points << ",\n";
  out << "  \"frames\": [\n";
  for (size_t i = 0; i < frames.size(); i++) {
    const auto& frame = frames[i];
    out << "    {\n";
    out << "      \"frame_index\": " << frame.frame_index << ",\n";
    out << "      \"decision\": \"" << jsonEscape(frame.decision) << "\",\n";
    out << "      \"seed_source\": \"" << jsonEscape(frame.seed_source) << "\",\n";
    out << "      \"accepted\": ";
    write_bool(out, frame.accepted);
    out << ",\n";
    out << "      \"seed_fallback\": ";
    write_bool(out, frame.seed_fallback);
    out << ",\n";
    out << "      \"scan_context_hit\": ";
    write_bool(out, frame.scan_context_hit);
    out << ",\n";
    out << "      \"scan_context_candidate_count\": "
        << frame.scan_context_candidate_count << ",\n";
    out << "      \"scan_context_candidates_evaluated\": "
        << frame.scan_context_candidates_evaluated << ",\n";
    out << "      \"selected_candidate_index\": "
        << frame.selected_candidate_index << ",\n";
    out << "      \"scan_context_front_distance\": ";
    write_number(out, frame.scan_context_front_distance);
    out << ",\n";
    out << "      \"selected_candidate_distance\": ";
    write_number(out, frame.selected_candidate_distance);
    out << ",\n";
    out << "      \"selected_candidate_yaw_offset_rad\": ";
    write_number(out, frame.selected_candidate_yaw_offset_rad);
    out << ",\n";
    out << "      \"ndt_score\": ";
    write_number(out, frame.ndt_score);
    out << ",\n";
    out << "      \"ndt_iterations\": " << frame.ndt_iterations << ",\n";
    out << "      \"ndt_converged\": ";
    write_bool(out, frame.ndt_converged);
    out << ",\n";
    out << "      \"publish_action\": \""
        << jsonEscape(frame.publish_action) << "\",\n";
    out << "      \"publish_state\": \""
        << jsonEscape(frame.publish_state) << "\",\n";
    out << "      \"publish_gate_reason\": \""
        << jsonEscape(frame.publish_gate_reason) << "\",\n";
    out << "      \"allow_pose_publish\": ";
    write_bool(out, frame.allow_pose_publish);
    out << ",\n";
    out << "      \"has_pose_output\": ";
    write_bool(out, frame.has_pose_output);
    out << ",\n";
    out << "      \"runtime_refinement_candidate\": ";
    write_bool(out, frame.runtime_refinement_candidate);
    out << ",\n";
    out << "      \"relock_candidate\": ";
    write_bool(out, frame.relock_candidate);
    out << ",\n";
    out << "      \"relock_sequence_compatible\": ";
    write_bool(out, frame.relock_sequence_compatible);
    out << ",\n";
    out << "      \"runtime_refinement_streak\": "
        << frame.runtime_refinement_streak << ",\n";
    out << "      \"relock_streak\": "
        << frame.relock_streak << ",\n";
    out << "      \"relock_candidate_index_delta\": "
        << frame.relock_candidate_index_delta << ",\n";
    out << "      \"relock_frame_gap\": "
        << frame.relock_frame_gap << ",\n";
    out << "      \"relock_rejected_reason\": \""
        << jsonEscape(frame.relock_rejected_reason) << "\",\n";
    out << "      \"publish_hold_age_frames\": "
        << frame.publish_hold_age_frames << ",\n";
    out << "      \"gt_safety_state\": \""
        << jsonEscape(frame.gt_safety_state) << "\",\n";
    out << "      \"gt_wrong_pose\": ";
    write_bool(out, frame.gt_wrong_pose);
    out << ",\n";
    out << "      \"gt_recovery_transition\": ";
    write_bool(out, frame.gt_recovery_transition);
    out << ",\n";
    out << "      \"gt_unsafe_transition\": ";
    write_bool(out, frame.gt_unsafe_transition);
    out << ",\n";
    out << "      \"published_translation_error_m\": ";
    write_number(out, frame.published_translation_error_m);
    out << ",\n";
    out << "      \"seed_translation_error_m\": ";
    write_number(out, frame.seed_translation_error_m);
    out << ",\n";
    out << "      \"seed_rotation_error_rad\": ";
    write_number(out, frame.seed_rotation_error_rad);
    out << ",\n";
    out << "      \"refined_translation_error_m\": ";
    write_number(out, frame.refined_translation_error_m);
    out << ",\n";
    out << "      \"refined_rotation_error_rad\": ";
    write_number(out, frame.refined_rotation_error_rad);
    out << ",\n";
    out << "      \"final_translation_error_m\": ";
    write_number(out, frame.final_translation_error_m);
    out << ",\n";
    out << "      \"final_rotation_error_rad\": ";
    write_number(out, frame.final_rotation_error_rad);
    out << ",\n";
    out << "      \"correction_translation_delta_m\": ";
    write_number(out, frame.correction_translation_delta_m);
    out << ",\n";
    out << "      \"correction_rotation_delta_rad\": ";
    write_number(out, frame.correction_rotation_delta_rad);
    out << ",\n";
    out << "      \"final_step_m\": ";
    write_number(out, frame.final_step_m);
    out << ",\n";
    out << "      \"gt_step_m\": ";
    write_number(out, frame.gt_step_m);
    out << ",\n";
    out << "      \"seed_pose\": ";
    write_pose(out, frame.seed_pose);
    out << ",\n";
    out << "      \"refined_pose\": ";
    write_pose(out, frame.refined_pose);
    out << ",\n";
    out << "      \"final_pose\": ";
    write_pose(out, frame.final_pose);
    out << ",\n";
    out << "      \"published_pose\": ";
    if (frame.has_pose_output) {
      write_pose(out, frame.published_pose);
    } else {
      out << "null";
    }
    out << ",\n";
    out << "      \"gt_pose\": ";
    write_pose(out, frame.gt_pose);
    out << "\n";
    out << "    }" << (i + 1 == frames.size() ? "\n" : ",\n");
  }
  out << "  ]\n";
  out << "}\n";
}

// Constant-velocity prediction in the body frame: T_pred = T_prev * (T_prev_prev^-1 * T_prev).
// Equivalent to applying the previous inter-frame body-frame motion once more.
Eigen::Matrix4d velocityModelPrediction(const Eigen::Matrix4d& T_prev,
                                        const Eigen::Matrix4d& T_prev_prev) {
  const Eigen::Matrix4d delta_body = T_prev_prev.inverse() * T_prev;
  return T_prev * delta_body;
}

MethodResult runLiTAMIN2PaperOdometry(const std::vector<std::string>& pcd_dirs,
                                      const std::vector<Eigen::Matrix4d>& gt,
                                      const LiTAMIN2DogfoodingOptions& options) {
  using namespace localization_zoo::litamin2;
  MethodResult res;
  res.name = options.use_cov_cost ? "LiTAMIN2" : "LiTAMIN2-ICP";
  LiTAMIN2OdometryParams params;
  params.voxel_size = options.paper_voxel_size;
  params.map_voxel_size = options.paper_voxel_size;
  params.min_points_per_voxel = options.paper_min_points;
  params.max_iterations = options.paper_max_iterations;
  params.map_radius = options.paper_map_radius;
  params.use_cov_cost = options.use_cov_cost;
  params.min_cov_eigenvalue = options.min_cov_eigenvalue;
  if (options.paper_map_mode == "first") {
    params.map_mode = LiTAMIN2OdometryParams::MapMode::kFirst;
  } else if (options.paper_map_mode == "latest") {
    params.map_mode = LiTAMIN2OdometryParams::MapMode::kLatest;
  } else {
    params.map_mode = LiTAMIN2OdometryParams::MapMode::kAggregate;
  }
  LiTAMIN2Odometry odometry(params);
  double distributions = 0.0, iterations = 0.0;
  size_t registered = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    const auto points = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0);
    const auto r = odometry.process(points);
    res.poses.push_back(gt[0] * r.pose);
    distributions += r.source_distributions;
    if (i > 0) {
      iterations += r.iterations;
      ++registered;
    }
    if (i % 100 == 0) std::cerr << "\r  [LiTAMIN2 paper] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream note;
  note << std::fixed << std::setprecision(1)
       << "LiTAMIN2 paper odometry (raw scans, " << params.voxel_size
       << " m distributions, map " << options.paper_map_mode << ", nearest-distribution pairing, "
       << (params.use_cov_cost ? "ICP+Cov" : "ICP") << "); no GT seed. mean distributions/scan "
       << distributions / std::max<size_t>(1, pcd_dirs.size()) << ", mean iterations "
       << iterations / std::max<size_t>(1, registered);
  res.note = note.str();
  return res;
}

MethodResult runLiTAMIN2(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const LiTAMIN2DogfoodingOptions& options,
                         bool no_gt_seed = false) {
  using namespace localization_zoo::litamin2;
  if (options.paper_odometry) return runLiTAMIN2PaperOdometry(pcd_dirs, gt, options);
  MethodResult res;
  res.name = options.use_cov_cost ? "LiTAMIN2" : "LiTAMIN2-ICP";

  auto stageIterations = [&](size_t stage_index) {
    if (options.coarse_to_fine_iterations.empty()) {
      return options.max_iterations;
    }
    if (stage_index < options.coarse_to_fine_iterations.size()) {
      return options.coarse_to_fine_iterations[stage_index];
    }
    return options.coarse_to_fine_iterations.back();
  };
  auto makeParams = [&](double voxel_resolution, size_t stage_index) {
    LiTAMIN2Params params;
    params.voxel_resolution = voxel_resolution;
    params.min_points_per_voxel = options.min_points_per_voxel;
    params.max_iterations = stageIterations(stage_index);
    params.use_cov_cost = options.use_cov_cost;
    params.optimize_covariance_cost = options.optimize_covariance_cost;
    params.covariance_gradient_weight = options.covariance_gradient_weight;
    params.enable_line_search = options.enable_line_search;
    params.line_search_min_step = options.line_search_min_step;
    params.num_threads = options.num_threads;
    params.min_cov_eigenvalue = options.min_cov_eigenvalue;
    params.correspondence_search_radius = options.correspondence_search_radius;
    params.max_correspondence_distance = options.max_correspondence_distance;
    return params;
  };
  auto isAcceptableResult = [&](const RegistrationResult& result,
                                const Eigen::Matrix4d& seed) {
    return (result.converged || result.num_iterations >= 3) &&
           isReasonableRefinement(result.transformation, seed,
                                  options.max_seed_translation_delta,
                                  options.max_seed_rotation_delta_rad);
  };
  auto isMotionConsistent = [&](const Eigen::Matrix4d& candidate_pose,
                                const Eigen::Matrix4d& anchor_pose,
                                const Eigen::Matrix4d& expected_relative) {
    if (options.max_motion_translation_delta < 0.0 &&
        options.max_motion_rotation_delta_rad < 0.0) {
      return true;
    }
    const Eigen::Matrix4d candidate_relative =
        anchor_pose.inverse() * candidate_pose;
    if (options.max_motion_translation_delta >= 0.0 &&
        poseTranslationDelta(candidate_relative, expected_relative) >
            options.max_motion_translation_delta) {
      return false;
    }
    if (options.max_motion_rotation_delta_rad >= 0.0 &&
        poseRotationDelta(candidate_relative, expected_relative) >
            options.max_motion_rotation_delta_rad) {
      return false;
    }
    return true;
  };

  std::vector<double> voxel_schedule = options.coarse_to_fine_voxel_resolutions;
  if (voxel_schedule.empty()) {
    voxel_schedule.push_back(options.voxel_resolution);
  }

  if (options.scan_to_scan) {
    Eigen::Matrix4d T_est = gt[0];
    Eigen::Matrix4d last_relative = Eigen::Matrix4d::Identity();
    std::vector<Eigen::Vector3d> previous_scan;
    res.poses.push_back(T_est);

    auto t0 = Clock::now();
    for (size_t i = 0; i < pcd_dirs.size(); i++) {
      auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.5),
                                   options.max_source_points);
      if (pts_local.empty()) continue;

      if (i == 0) {
        previous_scan = pts_local;
        continue;
      }

      std::vector<std::unique_ptr<LiTAMIN2Registration>> registrations;
      registrations.reserve(voxel_schedule.size());
      for (size_t stage_index = 0; stage_index < voxel_schedule.size();
           stage_index++) {
        auto reg = std::make_unique<LiTAMIN2Registration>(
            makeParams(voxel_schedule[stage_index], stage_index));
        reg->setTarget(previous_scan);
        registrations.push_back(std::move(reg));
      }

      const Eigen::Matrix4d T_prev_est = T_est;
      const Eigen::Matrix4d T_relative_seed =
          no_gt_seed ? last_relative
                     : applySeedPerturbation(gt[i - 1].inverse() * gt[i],
                                             options.seed_perturbation);
      Eigen::Matrix4d T_stage_seed = T_relative_seed;
      RegistrationResult final_result;
      for (auto& reg : registrations) {
        const auto stage_result = reg->align(pts_local, T_stage_seed);
        final_result = stage_result;
        if (isAcceptableResult(stage_result, T_stage_seed)) {
          T_stage_seed = stage_result.transformation;
        }
      }

      Eigen::Matrix4d T_relative = T_relative_seed;
      if (isAcceptableResult(final_result, T_relative_seed) &&
          isMotionConsistent(final_result.transformation,
                             Eigen::Matrix4d::Identity(), T_relative_seed)) {
        T_relative = final_result.transformation;
      }
      T_est = T_prev_est * T_relative;
      last_relative = T_relative;
      previous_scan = pts_local;
      res.poses.push_back(T_est);

      if (i % 10 == 0)
        std::cerr << "\r  [LiTAMIN2 scan-to-scan] " << i << "/"
                  << pcd_dirs.size();
    }
    std::cerr << std::endl;
    res.time_ms =
        std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
    res.note =
        no_gt_seed
            ? "Uses scan-to-scan LiTAMIN2 with previous relative transform as initial guess."
            : "Uses scan-to-scan LiTAMIN2 with GT relative transform initialization.";
    if (!no_gt_seed) {
      res.note += seedPerturbationNote(options.seed_perturbation);
    }
    if (voxel_schedule.size() > 1) {
      res.note += " Uses LiTAMIN2 coarse-to-fine voxel schedule.";
    }
    return res;
  }

  std::vector<std::unique_ptr<LiTAMIN2Registration>> registrations;
  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt[0];  // 初期推定にGTを使用
  Eigen::Matrix4d T_prev_prev_est = gt[0];
  Eigen::Matrix4d T_last_map_insert = gt[0];
  res.poses.push_back(T_est);

  auto rebuildTargets = [&]() {
    registrations.clear();
    registrations.reserve(voxel_schedule.size());
    for (size_t stage_index = 0; stage_index < voxel_schedule.size();
         stage_index++) {
      auto reg = std::make_unique<LiTAMIN2Registration>(
          makeParams(voxel_schedule[stage_index], stage_index));
      reg->setTarget(map_points);
      registrations.push_back(std::move(reg));
    }
  };

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.5),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      T_last_map_insert = T_est;
      rebuildTargets();
      continue;
    }

    // scan-to-map: local scan を world map に対して初期値付きで最適化
    const Eigen::Matrix4d T_init_guess =
        no_gt_seed
            ? (i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est) : T_est)
            : applySeedPerturbation(gt[i], options.seed_perturbation);
    const Eigen::Matrix4d T_prev_est_snapshot = T_est;
    const Eigen::Matrix4d expected_relative =
        no_gt_seed ? T_prev_prev_est.inverse() * T_prev_est_snapshot
                   : gt[i - 1].inverse() * gt[i];

    Eigen::Matrix4d T_stage_seed = T_init_guess;
    RegistrationResult final_result;
    for (auto& reg : registrations) {
      const auto stage_result = reg->align(pts_local, T_stage_seed);
      final_result = stage_result;
      if (isAcceptableResult(stage_result, T_stage_seed)) {
        T_stage_seed = stage_result.transformation;
      }
    }

    if (isAcceptableResult(final_result, T_init_guess) &&
        isMotionConsistent(final_result.transformation, T_prev_est_snapshot,
                           expected_relative)) {
      T_est = final_result.transformation;
    } else {
      T_est = T_init_guess;
    }
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);

    bool added_to_map = false;
    bool should_rebuild = false;
    using Policy = LiTAMIN2DogfoodingOptions::LocalMapPolicy;
    switch (options.local_map_policy) {
      case Policy::RefreshOnly:
        if (shouldRefreshTargetMap(i, options.refresh_interval)) {
          added_to_map = true;
          should_rebuild = true;
        }
        break;
      case Policy::Accumulate:
        added_to_map = true;
        should_rebuild = shouldRefreshTargetMap(i, options.refresh_interval);
        break;
      case Policy::Keyframe: {
        const bool moved_enough =
            poseTranslationDelta(T_est, T_last_map_insert) >=
                options.keyframe_translation ||
            poseRotationDelta(T_est, T_last_map_insert) >=
                options.keyframe_rotation_rad;
        if (moved_enough || shouldRefreshTargetMap(i, options.refresh_interval)) {
          added_to_map = true;
          should_rebuild = true;
        }
        break;
      }
    }
    if (added_to_map) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      T_last_map_insert = T_est;
    }
    if (should_rebuild) {
      rebuildTargets();
    }

    if (i % 10 == 0)
      std::cerr << "\r  [LiTAMIN2] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = no_gt_seed
      ? "Uses velocity-model prediction as scan-to-map initial guess (no GT seed)."
      : "Uses GT-seeded scan-to-map initialization with weak-update fallback "
        "in this dogfooding tool.";
  if (!no_gt_seed) {
    res.note += seedPerturbationNote(options.seed_perturbation);
  }
  if (!options.use_cov_cost) {
    res.note += " Covariance-shape term disabled.";
  }
  if (voxel_schedule.size() > 1) {
    res.note += " Uses LiTAMIN2 coarse-to-fine voxel schedule.";
  }
  res.note += " Local-map policy=" +
              litamin2LocalMapPolicyName(options.local_map_policy) + ".";
  return res;
}

MethodResult runGICP(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const GICPDogfoodingOptions& options,
                     bool no_gt_seed = false) {
  using namespace localization_zoo::gicp;
  MethodResult res;
  res.name = "GICP";

  GICPParams params;
  params.k_neighbors = options.k_neighbors;
  params.max_correspondence_distance = options.max_correspondence_distance;
  params.max_iterations = options.max_iterations;
  GICPRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt[0];
  Eigen::Matrix4d T_prev_prev_est = gt[0];
  res.poses.push_back(T_est);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      reg.setTarget(map_points);
      continue;
    }

    const Eigen::Matrix4d T_init_guess =
        no_gt_seed
            ? (i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est) : T_est)
            : applySeedPerturbation(gt[i], options.seed_perturbation);
    const Eigen::Matrix4d T_prev_est_snapshot = T_est;
    const auto result = reg.align(pts_local, T_init_guess);
    if ((result.converged || result.num_correspondences >= 128) &&
        isReasonableRefinement(result.transformation, T_init_guess,
                               options.max_seed_translation_delta,
                               options.max_seed_rotation_delta_rad)) {
      T_est = result.transformation;
    } else {
      T_est = T_init_guess;
    }
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);

    addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                   options.map_radius);
    if (shouldRefreshTargetMap(i, options.refresh_interval)) {
      reg.setTarget(map_points);
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [GICP] " << i << "/" << pcd_dirs.size()
                << " corr=" << result.num_correspondences;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = no_gt_seed
      ? "Uses velocity-model prediction as scan-to-map initial guess (no GT seed)."
      : "Uses GT-seeded scan-to-map initialization with weak-update fallback "
        "in this dogfooding tool.";
  if (!no_gt_seed) {
    res.note += seedPerturbationNote(options.seed_perturbation);
  }
  return res;
}

MethodResult runSmallGICP(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const SmallGICPDogfoodingOptions& options,
                          bool no_gt_seed = false) {
  using namespace localization_zoo::small_gicp;
  MethodResult res;
  res.name = "Small-GICP";

  SmallGICPParams params;
  params.voxel_resolution = options.voxel_resolution;
  params.k_neighbors = options.k_neighbors;
  params.max_correspondence_distance = options.max_correspondence_distance;
  params.max_correspondences = options.max_correspondences;
  params.max_iterations = options.max_iterations;
  params.rotation_epsilon = options.rotation_epsilon;
  params.translation_epsilon = options.translation_epsilon;
  params.covariance_regularization = options.covariance_regularization;
  params.fitness_epsilon = options.fitness_epsilon;
  SmallGICPRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt[0];
  Eigen::Matrix4d T_prev_prev_est = gt[0];
  res.poses.push_back(T_est);

  size_t seed_fallbacks = 0;
  size_t seeded_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      reg.setTarget(map_points);
      continue;
    }

    const Eigen::Matrix4d T_init_guess =
        no_gt_seed
            ? (i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est) : T_est)
            : applySeedPerturbation(gt[i], options.seed_perturbation);
    const Eigen::Matrix4d T_prev_est_snapshot = T_est;
    const auto result = reg.align(pts_local, T_init_guess);
    ++seeded_frames;
    if ((result.converged || result.num_correspondences >= 96) &&
        isReasonableRefinement(result.transformation, T_init_guess,
                               options.max_seed_translation_delta,
                               options.max_seed_rotation_delta_rad)) {
      T_est = result.transformation;
    } else {
      T_est = T_init_guess;
      ++seed_fallbacks;
    }
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);

    addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                   options.map_radius);
    if (shouldRefreshTargetMap(i, options.refresh_interval)) {
      reg.setTarget(map_points);
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [Small-GICP] " << i << "/" << pcd_dirs.size()
                << " corr=" << result.num_correspondences;
    }
  }
  std::cerr << std::endl;
  if (!no_gt_seed && seeded_frames > 0) {
    res.seed_fallback_rate_pct = 100.0 *
        static_cast<double>(seed_fallbacks) / static_cast<double>(seeded_frames);
    std::cerr << "  [Small-GICP] seed fallbacks=" << seed_fallbacks << "/"
              << seeded_frames << " (" << res.seed_fallback_rate_pct
              << "% rolled back to GT seed)" << std::endl;
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = no_gt_seed
      ? "Uses velocity-model prediction as scan-to-map initial guess (no GT seed)."
      : "Uses GT-seeded scan-to-map initialization with weak-update fallback "
        "in this dogfooding tool.";
  if (!no_gt_seed) {
    res.note += seedPerturbationNote(options.seed_perturbation);
  }
  return res;
}

MethodResult runVoxelGICP(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const VoxelGICPDogfoodingOptions& options,
                          bool no_gt_seed = false) {
  using namespace localization_zoo::voxel_gicp;
  MethodResult res;
  res.name = "Voxel-GICP";

  VoxelGICPParams params;
  params.voxel_resolution = options.voxel_resolution;
  params.min_points_per_voxel = options.min_points_per_voxel;
  params.max_correspondence_distance = options.max_correspondence_distance;
  params.max_iterations = options.max_iterations;
  params.rotation_epsilon = options.rotation_epsilon;
  params.translation_epsilon = options.translation_epsilon;
  params.covariance_regularization = options.covariance_regularization;
  params.fitness_epsilon = options.fitness_epsilon;
  VoxelGICPRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt[0];
  Eigen::Matrix4d T_prev_prev_est = gt[0];
  res.poses.push_back(T_est);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      reg.setTarget(map_points);
      continue;
    }

    const Eigen::Matrix4d T_init_guess =
        no_gt_seed
            ? (i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est) : T_est)
            : applySeedPerturbation(gt[i], options.seed_perturbation);
    const Eigen::Matrix4d T_prev_est_snapshot = T_est;
    const auto result = reg.align(pts_local, T_init_guess);
    if ((result.converged || result.num_correspondences >= 96) &&
        isReasonableRefinement(result.transformation, T_init_guess,
                               options.max_seed_translation_delta,
                               options.max_seed_rotation_delta_rad)) {
      T_est = result.transformation;
    } else {
      T_est = T_init_guess;
    }
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);

    addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                   options.map_radius);
    if (shouldRefreshTargetMap(i, options.refresh_interval)) {
      reg.setTarget(map_points);
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [Voxel-GICP] " << i << "/" << pcd_dirs.size()
                << " corr=" << result.num_correspondences;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = no_gt_seed
      ? "Uses velocity-model prediction as scan-to-map initial guess (no GT seed)."
      : "Uses GT-seeded scan-to-map initialization with weak-update fallback "
        "in this dogfooding tool.";
  if (!no_gt_seed) {
    res.note += seedPerturbationNote(options.seed_perturbation);
  }
  return res;
}

MethodResult runALOAM(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const ALOAMDogfoodingOptions& options) {
  using namespace localization_zoo::aloam;
  MethodResult res;
  res.name = "A-LOAM";

  ScanRegistrationParams scan_params;
  scan_params.n_scans = options.n_scans;
  scan_params.minimum_range = options.minimum_range;
  scan_params.scan_period = options.scan_period;
  scan_params.curvature_threshold = options.curvature_threshold;
  scan_params.max_corner_sharp = options.max_corner_sharp;
  scan_params.max_corner_less_sharp = options.max_corner_less_sharp;
  scan_params.max_surf_flat = options.max_surf_flat;
  scan_params.less_flat_leaf_size = options.less_flat_leaf_size;
  ScanRegistration scan_reg(scan_params);

  LaserOdometryParams odom_params;
  odom_params.distance_sq_threshold = options.odom_distance_sq_threshold;
  odom_params.nearby_scan = options.odom_nearby_scan;
  odom_params.num_optimization_iters = options.odom_outer_iters;
  odom_params.ceres_max_iterations = options.odom_ceres_iters;
  odom_params.huber_loss_s = options.odom_huber_loss_s;
  odom_params.enable_distortion = false;
  LaserOdometry laser_odom(odom_params);

  LaserMappingParams map_params;
  map_params.line_resolution = options.map_line_resolution;
  map_params.plane_resolution = options.map_plane_resolution;
  map_params.num_optimization_iters = options.map_outer_iters;
  map_params.ceres_max_iterations = options.map_ceres_iters;
  map_params.huber_loss_s = options.map_huber_loss_s;
  map_params.knn = options.map_knn;
  map_params.knn_max_dist_sq = options.map_knn_max_dist_sq;
  map_params.edge_eigenvalue_ratio = options.map_edge_eigenvalue_ratio;
  map_params.plane_threshold = options.map_plane_threshold;
  LaserMapping laser_map(map_params);

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
  res.poses.push_back(world_anchor);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0 /* no downsample */);
    if (pts.empty()) continue;

    auto cloud = toPclXYZICloud(pts);
    FeatureCloud features = scan_reg.extract(cloud);

    auto odom = laser_odom.process(features);
    if (!odom.valid) {
      if (i % 10 == 0) std::cerr << "\r  [A-LOAM] " << i << "/" << pcd_dirs.size();
      continue;
    }

    auto mapping = laser_map.process(features.corner_less_sharp,
                                     features.surf_less_flat,
                                     features.full_cloud,
                                     odom.q_w_curr,
                                     odom.t_w_curr);
    if (mapping.valid) {
      T_rel.setIdentity();
      T_rel.block<3, 3>(0, 0) = mapping.q_w_curr.toRotationMatrix();
      T_rel.block<3, 1>(0, 3) = mapping.t_w_curr;
    } else {
      // Fallback: use odometry pose when mapping didn't update.
      T_rel.setIdentity();
      T_rel.block<3, 3>(0, 0) = odom.q_w_curr.toRotationMatrix();
      T_rel.block<3, 1>(0, 3) = odom.t_w_curr;
    }
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    if (i % 10 == 0) std::cerr << "\r  [A-LOAM] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "Odometry+mapping pipeline (no GT seed). KITTI assumes n_scans=64.";
  return res;
}

MethodResult runFLOAM(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const FLOAMDogfoodingOptions& options) {
  using namespace localization_zoo::floam;
  MethodResult res;
  res.name = "F-LOAM";

  FLoamParams params;
  params.scan_registration.n_scans = options.n_scans;
  params.scan_registration.scan_period = options.scan_period;
  params.scan_registration.minimum_range = options.minimum_range;
  params.scan_registration.curvature_threshold = options.curvature_threshold;
  params.scan_registration.max_corner_sharp = options.max_corner_sharp;
  params.scan_registration.max_corner_less_sharp = options.max_corner_less_sharp;
  params.scan_registration.max_surf_flat = options.max_surf_flat;
  params.scan_registration.less_flat_leaf_size = options.less_flat_leaf_size;

  params.odometry.distance_sq_threshold = options.odom_distance_sq_threshold;
  params.odometry.num_optimization_iters = options.odom_outer_iters;
  params.odometry.ceres_max_iterations = options.odom_ceres_iters;
  params.odometry.enable_distortion = false;

  params.mapping.line_resolution = options.map_line_resolution;
  params.mapping.plane_resolution = options.map_plane_resolution;
  params.mapping.num_optimization_iters = options.map_outer_iters;
  params.mapping.ceres_max_iterations = options.map_ceres_iters;
  params.mapping.knn_max_dist_sq = options.map_knn_max_dist_sq;

  params.input_point_stride = options.input_point_stride;
  params.mapping_update_interval = options.mapping_update_interval;
  params.enable_mapping = options.enable_mapping;

  FLoam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  res.poses.push_back(world_anchor);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0 /* no downsample */);
    if (pts.empty()) continue;
    auto cloud = toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    if (!result.valid) {
      if (i % 10 == 0) std::cerr << "\r  [F-LOAM] " << i << "/" << pcd_dirs.size();
      continue;
    }

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    if (i % 10 == 0) {
      std::cerr << "\r  [F-LOAM] " << i << "/" << pcd_dirs.size()
                << " map_updates=" << result.mapping_updates
                << " stride=" << result.num_input_points << "->"
                << result.num_processed_points;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "Fast feature-based odometry+mapping with thinned input and throttled mapping updates (no GT seed).";
  return res;
}

MethodResult runILoam(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const ILoamDogfoodingOptions& options) {
  using namespace localization_zoo::i_loam;
  MethodResult res;
  res.name = "I-LOAM";

  ILoamParams params;
  params.scan_registration.n_scans = options.n_scans;
  params.scan_registration.scan_period = options.scan_period;
  params.scan_registration.minimum_range = options.minimum_range;
  params.scan_registration.curvature_threshold = options.curvature_threshold;
  params.scan_registration.max_corner_sharp = options.max_corner_sharp;
  params.scan_registration.max_corner_less_sharp = options.max_corner_less_sharp;
  params.scan_registration.max_surf_flat = options.max_surf_flat;
  params.scan_registration.less_flat_leaf_size = options.less_flat_leaf_size;

  params.input_point_stride = options.input_point_stride;
  params.distance_sq_threshold = options.odom_distance_sq_threshold;
  params.nearby_scan = options.odom_nearby_scan;
  params.num_optimization_iters = options.odom_outer_iters;
  params.ceres_max_iterations = options.odom_ceres_iters;
  params.huber_loss_s = options.odom_huber_loss_s;
  params.enable_distortion = false;

  params.use_intensity_weight = options.use_intensity_weight;
  params.use_intensity_correspondence = options.use_intensity_correspondence;
  params.intensity_sigma = options.intensity_sigma;
  params.intensity_corr_weight = options.intensity_corr_weight;

  params.enable_mapping = options.enable_mapping;
  params.mapping_update_interval = options.mapping_update_interval;
  params.mapping.line_resolution = options.map_line_resolution;
  params.mapping.plane_resolution = options.map_plane_resolution;
  params.mapping.num_optimization_iters = options.map_outer_iters;
  params.mapping.ceres_max_iterations = options.map_ceres_iters;
  params.mapping.huber_loss_s = options.map_huber_loss_s;
  params.mapping.knn = options.map_knn;
  params.mapping.knn_max_dist_sq = options.map_knn_max_dist_sq;
  params.mapping.edge_eigenvalue_ratio = options.map_edge_eigenvalue_ratio;
  params.mapping.plane_threshold = options.map_plane_threshold;

  ILoam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  res.poses.push_back(world_anchor);

  double weight_acc = 0.0;
  long weight_frames = 0;
  int mapping_updates = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    // 反射強度を保持して読み込む (I-LOAM の本質)。LOAM のスキャン構造を
    // 壊さないよう load 時はダウンサンプリングしない (leaf=0)。
    auto xyzi = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", 0.0 /* no downsample */);
    if (xyzi.empty()) continue;
    auto cloud = toPclXYZICloud(xyzi);
    const auto result = pipeline.process(cloud);
    if (!result.valid) {
      if (i % 10 == 0) std::cerr << "\r  [I-LOAM] " << i << "/" << pcd_dirs.size();
      continue;
    }

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    weight_acc += result.mean_intensity_weight;
    ++weight_frames;
    mapping_updates = result.mapping_updates;
    if (i % 10 == 0) {
      std::cerr << "\r  [I-LOAM] " << i << "/" << pcd_dirs.size()
                << " edges=" << result.num_edge_correspondences
                << " planes=" << result.num_plane_correspondences
                << " w=" << result.mean_intensity_weight
                << " map=" << result.mapping_updates;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double mean_w =
      weight_frames ? weight_acc / static_cast<double>(weight_frames) : 1.0;
  res.note =
      "I-LOAM (Park/Jang/Kim, UR 2020): intensity-enhanced LOAM odometry"
      + std::string(options.enable_mapping ? "+mapping" : " (scan-to-scan only)")
      + " on KITTI PointXYZI; no GT seed. mean_intensity_weight=" +
      std::to_string(mean_w) + " mapping_updates=" + std::to_string(mapping_updates);
  return res;
}

MethodResult runPlLoam(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const std::vector<double>& frame_timestamps,
                       const PlLoamDogfoodingOptions& options) {
  using namespace localization_zoo::pl_loam;
  MethodResult res;
  res.name = options.use_rgb ? "PL-LOAM-RGB" : "PL-LOAM";

  PlLoamParams params;
  params.input_stride = options.input_stride;
  params.max_point_features = options.max_point_features;
  params.max_line_features = options.max_line_features;
  params.patch_radius = options.patch_radius;
  params.use_depth_prior = options.use_depth_prior;
  params.use_line_features = options.use_line_features;
  params.use_scale_correction = options.use_scale_correction;
  params.use_intensity_pseudo_image = options.use_intensity_pseudo_image;
  params.intensity_dilation_radius = options.intensity_dilation_radius;
  params.depth_prior_weight = options.depth_prior_weight;
  params.ceres_max_iterations = options.ceres_max_iterations;
  params.use_rgb_features = options.use_rgb;
  if (options.use_rgb) {
    params.camera = options.rgb_half_res ? CameraModel::kittiColor02HalfRes()
                                         : CameraModel::kittiColor02();
  }

  PlLoam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double scale_acc = 0.0;
  double depth_res_acc = 0.0;
  long valid_frames = 0;
  long rgb_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto xyzi = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", 0.0);
    if (xyzi.empty()) continue;

    std::vector<Eigen::Vector3d> points;
    std::vector<float> intensity;
    points.reserve(xyzi.size());
    intensity.reserve(xyzi.size());
    for (const auto& p : xyzi) {
      points.push_back(p.point);
      intensity.push_back(p.intensity);
    }

    PlLoamResult result;
    if (options.use_rgb && !options.rgb_image_root.empty() &&
        i < frame_timestamps.size()) {
      const int global_idx = static_cast<int>(std::lround(frame_timestamps[i]));
      const std::string rgb_path = resolveKittiRawRgbPath(
          options.rgb_image_root, options.rgb_camera_subdir, global_idx);
      GrayscaleImage gray;
      if (gray.loadRgbPng(rgb_path, params.camera.width, params.camera.height)) {
        result = pipeline.processWithGrayscale(points, intensity, gray);
        ++rgb_frames;
      } else {
        result = pipeline.process(points, intensity);
      }
    } else {
      result = pipeline.process(points, intensity);
    }
    if (result.frame_count < 1) continue;

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    if (result.valid) {
      scale_acc += result.scale_correction;
      depth_res_acc += result.mean_depth_prior_residual;
      ++valid_frames;
    }
    if (i % 10 == 0) {
      std::cerr << "\r  [PL-LOAM] " << i << "/" << pcd_dirs.size()
                << " pts=" << result.num_points << " lines=" << result.num_lines
                << " pm=" << result.num_point_matches
                << " scale=" << result.scale_correction;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double mean_scale =
      valid_frames ? scale_acc / static_cast<double>(valid_frames) : 1.0;
  const double mean_depth_res =
      valid_frames ? depth_res_acc / static_cast<double>(valid_frames) : 0.0;
  res.note =
      std::string("PL-LOAM (Huang et al., ICRA 2020): LiDAR-monocular point+line VO with "
                  "depth priors in PL-BA; no GT seed. eval=") +
      (options.use_rgb ? "KITTI-Raw-RGB"
                       : (options.use_intensity_pseudo_image
                              ? "intensity-pseudo-image"
                              : "depth-pseudo-image")) +
      " mean_scale_correction=" + std::to_string(mean_scale) +
      " mean_depth_prior_residual=" + std::to_string(mean_depth_res) +
      " depth_prior=" + std::string(options.use_depth_prior ? "on" : "off") +
      " line_features=" + std::string(options.use_line_features ? "on" : "off") +
      " scale_correction=" +
      std::string(options.use_scale_correction ? "on" : "off") +
      " intensity_dilation_radius=" +
      std::to_string(options.intensity_dilation_radius) +
      " rgb_frames=" + std::to_string(rgb_frames);
  return res;
}

MethodResult runInTenLoam(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const InTenLoamDogfoodingOptions& options) {
  using namespace localization_zoo::inten_loam;
  MethodResult res;
  res.name = "InTEn-LOAM";
  if (options.paper_odometry) {
    InTenLoamPaperParams pp;
    pp.accelerated = options.paper_accelerated;
    pp.use_intensity = options.paper_intensity;
    pp.use_mapping = options.paper_mapping;
    pp.use_dor = options.paper_dor;
    pp.s2m_interval = options.paper_s2m_interval;
    pp.max_range = g_input_max_range_m;
    for (const auto& kv : options.paper_overrides) {
      const std::string& k = kv.first;
      const double v = kv.second;
      if (k == "map_plane_voxel") pp.map_plane_voxel = v;
      else if (k == "map_edge_voxel") pp.map_edge_voxel = v;
      else if (k == "huber") pp.huber = v;
      else if (k == "s2m_gate_sq") pp.s2m_gate_sq = v;
      else if (k == "s2s_gate_sq") pp.s2s_gate_sq = v;
      else if (k == "s2s_mapped_prior") pp.s2s_mapped_prior = v != 0.0;
      else if (k == "s2s_translation_prior_ratio") pp.s2s_translation_prior_ratio = v;
      else if (k == "s2s_row_support") pp.s2s_row_support = v != 0.0;
      else if (k == "s2s_ground_pca") pp.s2s_ground_pca = v != 0.0;
      else if (k == "s2s_facade_pca") pp.s2s_facade_pca = v != 0.0;
      else if (k == "s2s_intensity_normalized") pp.s2s_intensity_normalized = v != 0.0;
      else if (k == "s2s_intensity_consistent") pp.s2s_intensity_consistent = v != 0.0;
      else if (k == "s2s_facade_cauchy") pp.s2s_facade_cauchy = v != 0.0;
      else if (k == "s2s_geometry_consensus") pp.s2s_geometry_consensus = v != 0.0;
      else if (k == "max_ground") pp.max_ground = static_cast<int>(v);
      else if (k == "facades_per_sector") pp.facades_per_sector = static_cast<int>(v);
      else if (k == "edges_per_sector") pp.edges_per_sector = static_cast<int>(v);
      else if (k == "edge_threshold") pp.edge_threshold = v;
      else if (k == "facade_threshold") pp.facade_threshold = v;
      else if (k == "map_radius") pp.map_radius = v;
      else if (k == "intensity_weight") pp.intensity_weight = v;
      else if (k == "s2s_iterations") {
        if (!std::isfinite(v) || v < 0.0 || v > std::numeric_limits<int>::max() || std::floor(v) != v)
          throw std::invalid_argument("s2s_iterations must be a non-negative integer within int range");
        pp.s2s_iterations = static_cast<int>(v);
      }
      else if (k == "s2m_iterations") pp.s2m_iterations = static_cast<int>(v);
      else if (k == "ground_threshold") pp.ground_threshold = v;
      else if (k == "deskew") pp.deskew = static_cast<int>(v);
      else if (k == "theta_up_deg") pp.theta_up_deg = v;
      else if (k == "theta_down_deg") pp.theta_down_deg = v;
      else if (k == "height") pp.height = static_cast<int>(v);
      else if (k == "ground_start_below") pp.ground_start_below = v;
      else if (k == "cluster_angle_deg") pp.cluster_angle_deg = v;
      else if (k == "min_cluster_points") pp.min_cluster_points = static_cast<int>(v);
      else if (k == "segment_bin") pp.segment_bin = v;
      else if (k == "ground_max_slope") pp.ground_max_slope = v;
      else if (k == "width") pp.width = static_cast<int>(v);
      else if (k == "sectors_per_row") pp.sectors_per_row = static_cast<int>(v);
      else if (k == "map_intensity_voxel") pp.map_intensity_voxel = v;
      else if (k == "use_dor") pp.use_dor = v != 0.0;
      else if (k == "s2s_predicted_dor_facade") pp.s2s_predicted_dor_facade = v != 0.0;
      else if (k == "use_intensity") pp.use_intensity = v != 0.0;
      else if (k == "s2m_plane_max_dist") pp.s2m_plane_max_dist = v;
      else if (k == "s2m_plane_min_spread") pp.s2m_plane_min_spread = v;
      else std::cerr << "unknown --inten-loam-paper-set key " << k << std::endl;
    }
    InTenLoamPaper paper(pp);
    const Eigen::Matrix4d anchor = gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
    namespace trace_json = localization_zoo::evaluation::inten_trace;
    std::unique_ptr<trace_json::Writer> trace_writer;
    if (!options.paper_trace_jsonl.empty()) {
      trace_writer = std::make_unique<trace_json::Writer>(options.paper_trace_jsonl);
      trace_writer->write(trace_json::header(pp, options.trace_argv, pcd_dirs.size(),
          g_input_min_range_m, g_input_max_range_m, g_input_vertical_angle_correction_rad,
          g_input_sensor_pose, anchor));
    }
    std::unique_ptr<InTenLoamPaperTrace> trace;
    if (trace_writer) trace = std::make_unique<InTenLoamPaperTrace>();
    size_t skipped_frames = 0;
    long s2s = 0, s2m = 0, dor = 0, n = 0;
    auto t_start = Clock::now();
    for (size_t i = 0; i < pcd_dirs.size(); i++) {
      const auto xyzi = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", 0.0);
      if (xyzi.empty()) {
        if (trace_writer) trace_writer->write(trace_json::skipped(i, pcd_dirs[i] + "/cloud.pcd"));
        ++skipped_frames;
        continue;
      }
      std::vector<Eigen::Vector3d> pts;
      std::vector<float> inten;
      pts.reserve(xyzi.size());
      inten.reserve(xyzi.size());
      for (const auto& p : xyzi) {
        pts.push_back(p.point);
        inten.push_back(p.intensity);
      }
      // The paper's thresholds are for intensity in [0, 1] (KITTI); scans
      // that store 0-255 (NCLT) are scaled.
      if (!inten.empty() && *std::max_element(inten.begin(), inten.end()) > 1.0f) {
        for (auto& value : inten) value /= 255.0f;
      }
      const auto r = paper.process(pts, inten, nullptr, trace.get());
      res.poses.push_back(anchorRelativePose(anchor, r.pose));
      if (trace_writer) trace_writer->write(trace_json::frame(i, pcd_dirs[i] + "/cloud.pcd",
          *trace, r, res.poses.back()));
      s2s += r.s2s_pairs;
      s2m += r.s2m_pairs;
      dor += static_cast<long>(r.dor_removed);
      ++n;
      if (i % 10 == 0)
        std::cerr << "\r  [InTEn-LOAM paper] " << i << "/" << pcd_dirs.size() << " g/f/e/r=" << r.num_ground << "/"
                  << r.num_facade << "/" << r.num_edge << "/" << r.num_reflector << " s2s=" << r.s2s_pairs
                  << " s2m=" << r.s2m_pairs << " (e/g/f/i " << r.s2m_class_pairs[0] << "/" << r.s2m_class_pairs[1]
                  << "/" << r.s2m_class_pairs[2] << "/" << r.s2m_class_pairs[3] << ")   ";
    }
    if (trace_writer) trace_writer->finish(static_cast<size_t>(n), skipped_frames);
    std::cerr << std::endl;
    res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t_start).count();
    const long d = std::max(1L, n);
    res.note = "InTEn-LOAM paper pipeline (FEF, S2S Alg. 1 with re-association, S2M Alg. 2 with TVF map, DOR "
               "gating map insertion); no GT seed. intensity=" + std::string(options.paper_intensity ? "on" : "off") +
               " mapping=" + (options.paper_mapping ? "on" : "off") + " dor=" + (options.paper_dor ? "on" : "off") +
               " mean pairs s2s=" + std::to_string(s2s / d) + " s2m=" + std::to_string(s2m / d) +
               " dor points/frame=" + std::to_string(dor / d);
    if (options.paper_accelerated) res.note += "; repository acceleration enabled (opt-in, not in the paper)";
    if (pp.s2s_mapped_prior) res.note += "; S2S previous mapped-motion seed enabled (repository extension, opt-in)";
    if (pp.s2s_translation_prior_ratio > 0.0) res.note += "; S2S weak-translation prediction prior enabled (repository extension, opt-in)";
    if (pp.s2s_predicted_dor_facade) res.note += "; predicted-DOR S2S facade gate enabled (repository extension, opt-in)";
    if (pp.s2s_row_support) res.note += "; S2S missing-row completion enabled (repository extension, opt-in)";
    if (pp.s2s_ground_pca) res.note += "; S2S ground PCA normals enabled (repository extension, opt-in)";
    if (pp.s2s_facade_pca) res.note += "; S2S facade PCA normals enabled (repository extension, opt-in)";
    if (pp.s2s_intensity_normalized) res.note += "; S2S normalized occupied intensity weights enabled (repository extension, opt-in)";
    if (pp.s2s_intensity_consistent) res.note += "; S2S fixed-node intensity completion enabled (repository extension, opt-in)";
    if (pp.s2s_facade_cauchy) res.note += "; S2S facade Cauchy influence enabled (repository extension, opt-in)";
    if (pp.s2s_geometry_consensus) res.note += "; S2S fixed-rotation geometric translation consensus enabled (repository extension, opt-in)";
    return res;
  }

  InTenLoamParams params;
  params.input_stride = options.input_stride;
  params.cylindrical.width = options.cyl_width;
  params.cylindrical.height = options.cyl_height;
  params.use_intensity_registration = options.use_intensity_registration;
  params.max_edge_features = options.max_edge_features;
  params.max_surface_features = options.max_surface_features;
  params.max_reflector_features = options.max_reflector_features;
  params.intensity_weight = options.intensity_weight;
  params.enable_tvf = options.enable_tvf;
  params.enable_dor = options.enable_dor;
  params.enable_mapping = options.enable_mapping;
  params.tvf_voxel_size = options.tvf_voxel_size;
  params.tvf_min_observations = options.tvf_min_observations;
  params.dor_range_delta_thresh = options.dor_range_delta_thresh;
  params.map_voxel_size = options.map_voxel_size;
  params.local_map_radius = options.local_map_radius;
  params.mapping_keyframe_interval = options.mapping_keyframe_interval;

  InTenLoam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double int_res_acc = 0.0;
  long valid_frames = 0;
  long mapping_updates = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto xyzi = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", 0.0);
    if (xyzi.empty()) continue;
    std::vector<PointI> points;
    points.reserve(xyzi.size());
    for (const auto& p : xyzi) {
      PointI pt;
      pt.p = p.point;
      pt.intensity = p.intensity;
      points.push_back(pt);
    }
    const auto result = pipeline.process(points);
    if (result.frame_count < 1) continue;

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    if (result.valid) {
      int_res_acc += result.mean_intensity_residual;
      ++valid_frames;
      mapping_updates += result.mapping_updates;
    }
    if (i % 10 == 0) {
      std::cerr << "\r  [InTEn-LOAM] " << i << "/" << pcd_dirs.size()
                << " edge=" << result.num_edge << " refl=" << result.num_reflector;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double mean_int_res =
      valid_frames ? int_res_acc / static_cast<double>(valid_frames) : 0.0;
  res.note =
      "InTEn-LOAM (Li et al., RS 2022/23): cylindrical FEF + intensity registration + "
      "TVF/DOR/mapping; no GT seed. tvf=" +
      std::string(options.enable_tvf ? "on" : "off") + " dor=" +
      (options.enable_dor ? "on" : "off") + " mapping=" +
      (options.enable_mapping ? "on" : "off") +
      " mapping_updates=" + std::to_string(mapping_updates) +
      " mean_intensity_residual=" + std::to_string(mean_int_res);
  return res;
}

MethodResult runMcGicpLo(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const McGicpLoDogfoodingOptions& options) {
  using namespace localization_zoo::mcgicp;
  MethodResult res;
  res.name = "MCGICP-LO";

  McGicpLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.initial_threshold = options.initial_threshold;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_iterations = options.max_iterations;
  params.intensity_scale = options.intensity_scale;
  params.normal_epsilon = options.normal_epsilon;
  params.intensity_epsilon = options.intensity_epsilon;
  params.enable_intensity = options.enable_intensity;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  McGicpLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double int_res_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto xyzi = limitLoadedXYZI(
        loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size),
        options.max_source_points);
    if (xyzi.empty()) continue;
    std::vector<PointI> points;
    points.reserve(xyzi.size());
    for (const auto& p : xyzi) {
      points.push_back({p.point, static_cast<double>(p.intensity)});
    }
    const auto result = pipeline.registerFrame(points);
    int_res_sum += result.mean_intensity_residual;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [MCGICP-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.3f / scale=%.2f",
                n > 0 ? int_res_sum / static_cast<double>(n) : 0.0,
                options.intensity_scale);
  res.note =
      "MCGICP-LO (Servos/Waslander, RAS 2017): 4D multi-channel GICP with "
      "intensity in point covariance + Mahalanobis correspondences; "
      "constant-velocity prior, no GT seed. mean_intensity_residual/scale=" +
      std::string(buf);
  return res;
}

MethodResult runIcpscLo(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const IcpscLoDogfoodingOptions& options) {
  using namespace localization_zoo::icpsc;
  MethodResult res;
  res.name = "ICPSC-LO";

  IcpscParams params;
  params.cylindrical.width = options.cyl_width;
  params.cylindrical.height = options.cyl_height;
  params.num_rings = options.num_rings;
  params.num_sectors = options.num_sectors;
  params.intensity_sigma = options.intensity_sigma;
  params.adaptive_alpha = options.adaptive_alpha;
  params.enable_intensity = options.enable_intensity;
  params.voxel_size = options.voxel_size;
  params.max_iterations = options.max_iterations;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  IcpscPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double geom_w_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto xyzi = limitLoadedXYZI(
        loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size),
        options.max_source_points);
    if (xyzi.empty()) continue;
    std::vector<PointI> points;
    points.reserve(xyzi.size());
    for (const auto& p : xyzi) {
      points.push_back({p.point, p.intensity});
    }
    const auto result = pipeline.registerFrame(points);
    geom_w_sum += result.geom_weight;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [ICPSC-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize()
                << " w_geom=" << result.geom_weight;
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? geom_w_sum / static_cast<double>(n) : 0.0);
  res.note =
      "ICPSC-LO (Zhang et al., JAG 2023): cylindrical intensity shape-context "
      "+ adaptive geom/intensity fusion scan-to-map; loop closure deferred. "
      "no GT seed. mean_geom_weight=" +
      std::string(buf);
  return res;
}

MethodResult runVlom(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const std::vector<double>& frame_timestamps,
                     const VlomDogfoodingOptions& options) {
  using namespace localization_zoo::vlom;
  MethodResult res;
  res.name = options.use_rgb ? "VLOM-RGB" : "VLOM";

  VlomParams params;
  params.input_point_stride = options.input_point_stride;
  params.visual.input_stride = options.visual_input_stride;
  params.visual.max_point_features = options.max_point_features;
  params.visual.max_line_features = options.max_line_features;
  params.visual.use_rgb_features = options.use_rgb;
  params.visual.use_intensity_pseudo_image = options.use_intensity_pseudo_image;
  params.visual.intensity_dilation_radius = options.intensity_dilation_radius;
  if (options.use_rgb) {
    params.visual.camera =
        options.rgb_half_res
            ? localization_zoo::pl_loam::CameraModel::kittiColor02HalfRes()
            : localization_zoo::pl_loam::CameraModel::kittiColor02();
  }
  params.enable_visual_bootstrap = options.enable_visual_bootstrap;
  params.enable_scale_correction = options.enable_scale_correction;
  params.scale_correction_interval = options.scale_correction_interval;
  params.mad_outlier_k = options.mad_outlier_k;
  params.enable_mapping = options.enable_mapping;

  params.scan_registration.n_scans = options.n_scans;
  params.scan_registration.scan_period = options.scan_period;
  params.scan_registration.minimum_range = options.minimum_range;
  params.scan_registration.curvature_threshold = options.curvature_threshold;
  params.scan_registration.max_corner_sharp = options.max_corner_sharp;
  params.scan_registration.max_corner_less_sharp = options.max_corner_less_sharp;
  params.scan_registration.max_surf_flat = options.max_surf_flat;
  params.scan_registration.less_flat_leaf_size = options.less_flat_leaf_size;

  params.odometry.distance_sq_threshold = options.odom_distance_sq_threshold;
  params.odometry.nearby_scan = options.odom_nearby_scan;
  params.odometry.num_optimization_iters = options.odom_outer_iters;
  params.odometry.ceres_max_iterations = options.odom_ceres_iters;
  params.odometry.huber_loss_s = options.odom_huber_loss_s;

  params.mapping.line_resolution = options.map_line_resolution;
  params.mapping.plane_resolution = options.map_plane_resolution;
  params.mapping.num_optimization_iters = options.map_outer_iters;
  params.mapping.ceres_max_iterations = options.map_ceres_iters;
  params.mapping.huber_loss_s = options.map_huber_loss_s;
  params.mapping.knn = options.map_knn;
  params.mapping.knn_max_dist_sq = options.map_knn_max_dist_sq;
  params.mapping.edge_eigenvalue_ratio = options.map_edge_eigenvalue_ratio;
  params.mapping.plane_threshold = options.map_plane_threshold;

  Vlom pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  res.poses.push_back(world_anchor);

  double scale_acc = 0.0;
  long scale_frames = 0;
  long bootstrap_frames = 0;
  long rgb_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto xyzi = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", 0.0);
    if (xyzi.empty()) continue;
    auto cloud = toPclXYZICloud(xyzi);
    std::vector<float> intensity;
    intensity.reserve(xyzi.size());
    for (const auto& p : xyzi) intensity.push_back(p.intensity);

    localization_zoo::pl_loam::GrayscaleImage gray;
    const localization_zoo::pl_loam::GrayscaleImage* gray_ptr = nullptr;
    if (options.use_rgb && !options.rgb_image_root.empty() &&
        i < frame_timestamps.size()) {
      const int global_idx = static_cast<int>(std::lround(frame_timestamps[i]));
      const std::string rgb_path = resolveKittiRawRgbPath(
          options.rgb_image_root, options.rgb_camera_subdir, global_idx);
      if (gray.loadRgbPng(rgb_path, params.visual.camera.width,
                           params.visual.camera.height)) {
        gray_ptr = &gray;
        ++rgb_frames;
      }
    }

    const auto result = pipeline.process(cloud, intensity, gray_ptr);
    if (!result.valid) {
      if (i % 10 == 0) std::cerr << "\r  [VLOM] " << i << "/" << pcd_dirs.size();
      continue;
    }

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    scale_acc += result.scale_factor;
    ++scale_frames;
    if (result.visual_bootstrap_used) ++bootstrap_frames;
    if (i % 10 == 0) {
      std::cerr << "\r  [VLOM] " << i << "/" << pcd_dirs.size()
                << " bootstrap=" << result.visual_bootstrap_used
                << " scale=" << result.scale_factor;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char note_buf[320];
  std::snprintf(
      note_buf, sizeof(note_buf),
      "VLOM (arXiv:2304.08978): scale-corrected A-LOAM with optional visual "
      "bootstrap; eval=%s; bootstrap=%s scale_correction=%s; no GT seed. "
      "mean_scale=%.3f bootstrap_frames=%ld rgb_frames=%ld "
      "intensity_dilation_radius=%d",
      options.use_rgb ? "KITTI-Raw-RGB"
                      : (options.use_intensity_pseudo_image
                             ? "intensity-pseudo-image"
                             : "depth-pseudo-image"),
      options.enable_visual_bootstrap ? "on" : "off",
      options.enable_scale_correction ? "on" : "off",
      scale_frames ? scale_acc / static_cast<double>(scale_frames) : 1.0,
      bootstrap_frames, rgb_frames, options.intensity_dilation_radius);
  res.note = note_buf;
  return res;
}

struct OdoNetDogfoodingOptions {
  std::string weights_path = "papers/odonet/weights/odonet_kitti.json";
  bool enable_nhc = true;
  bool enable_zupt = true;
  bool enable_cnn_speed = true;
};

MethodResult runOdoNet(const std::vector<Eigen::Matrix4d>& gt,
                       const std::vector<double>& frame_timestamps,
                       const std::vector<ImuSampleCsv>& imu_samples,
                       const OdoNetDogfoodingOptions& options) {
  using namespace localization_zoo::odonet;
  MethodResult res;
  res.name = "OdoNet";

  if (imu_samples.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note =
        "imu.csv not found. OdoNet requires synchronized IMU for pseudo-odometer "
        "dead reckoning.";
    return res;
  }
  if (frame_timestamps.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = "OdoNet requires per-frame timestamps aligned with imu.csv.";
    return res;
  }

  std::vector<ImuReading> imu;
  imu.reserve(imu_samples.size());
  for (const auto& sample : imu_samples) {
    ImuReading reading;
    reading.stamp = sample.timestamp;
    reading.gyro = sample.gyro;
    reading.accel = sample.accel;
    imu.push_back(reading);
  }

  OdoNetParams params;
  params.weights_path = options.weights_path;
  params.enable_nhc = options.enable_nhc;
  params.enable_zupt = options.enable_zupt;
  params.enable_cnn_speed = options.enable_cnn_speed;

  long zupt_frames = 0;
  long cnn_frames = 0;
  std::string error;
  auto t0 = Clock::now();
  const auto rel_poses =
      integrateImuTrajectory(imu, frame_timestamps, params, &zupt_frames,
                             &cnn_frames, &error);
  if (rel_poses.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = error.empty() ? "OdoNet integration failed." : error;
    return res;
  }

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  for (const auto& T : rel_poses) {
    res.poses.push_back(anchorRelativePose(world_anchor, T));
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();

  char note_buf[256];
  std::snprintf(
      note_buf, sizeof(note_buf),
      "OdoNet (arXiv:2109.03091): CNN pseudo-odometer + strapdown INS + "
      "NHC/ZUPT; no GT seed. cnn_frames=%ld zupt_frames=%ld nhc=%d",
      cnn_frames, zupt_frames, options.enable_nhc ? 1 : 0);
  res.note = note_buf;
  return res;
}

struct NhcNetDogfoodingOptions {
  std::string weights_path = "papers/nhc_net/weights/nhc_net_kitti.json";
  bool enable_zupt = true;
  bool adaptive_gain = true;
  double nhc_gain = 6.0;
};

MethodResult runNhcNet(const std::vector<Eigen::Matrix4d>& gt,
                       const std::vector<double>& frame_timestamps,
                       const std::vector<ImuSampleCsv>& imu_samples,
                       const NhcNetDogfoodingOptions& options) {
  using namespace localization_zoo::nhc_net;
  MethodResult res;
  res.name = "NHC-Net";

  if (imu_samples.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = "imu.csv not found. NHC-Net requires synchronized IMU samples.";
    return res;
  }

  std::vector<ImuReading> imu;
  imu.reserve(imu_samples.size());
  for (const auto& s : imu_samples) {
    ImuReading r;
    r.stamp = s.timestamp;
    r.gyro = s.gyro;
    r.accel = s.accel;
    imu.push_back(r);
  }

  NhcNetParams params;
  params.weights_path = options.weights_path;
  params.enable_zupt = options.enable_zupt;
  params.adaptive_gain = options.adaptive_gain;
  params.nhc_gain = options.nhc_gain;

  long zupt_frames = 0;
  long cnn_frames = 0;
  std::string error;
  auto t0 = Clock::now();
  const auto rel_poses =
      integrateImuTrajectory(imu, frame_timestamps, params, &zupt_frames,
                             &cnn_frames, &error);
  if (rel_poses.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = error.empty() ? "NHC-Net integration failed." : error;
    return res;
  }

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  for (const auto& T : rel_poses) {
    res.poses.push_back(anchorRelativePose(world_anchor, T));
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char note_buf[256];
  std::snprintf(
      note_buf, sizeof(note_buf),
      "NHC-Net/VMSC (GPS Solutions 2023): CNN motion-state + adaptive NHC DR; "
      "no GT seed. vmsc_frames=%ld zupt_frames=%ld",
      cnn_frames, zupt_frames);
  res.note = note_buf;
  return res;
}

struct NnZuptDogfoodingOptions {
  std::string weights_path = "papers/nn_zupt/weights/nn_zupt_kitti.json";
  bool enable_zupt = true;
  bool enable_nhc = true;
  bool use_threshold_detector = false;
  double stop_prob_threshold = 0.5;
};

MethodResult runNnZupt(const std::vector<Eigen::Matrix4d>& gt,
                       const std::vector<double>& frame_timestamps,
                       const std::vector<ImuSampleCsv>& imu_samples,
                       const NnZuptDogfoodingOptions& options) {
  using namespace localization_zoo::nn_zupt;
  MethodResult res;
  res.name = "NN-ZUPT";

  if (imu_samples.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = "imu.csv not found. NN-ZUPT requires synchronized IMU samples.";
    return res;
  }

  std::vector<ImuReading> imu;
  imu.reserve(imu_samples.size());
  for (const auto& s : imu_samples) {
    ImuReading r;
    r.stamp = s.timestamp;
    r.gyro = s.gyro;
    r.accel = s.accel;
    imu.push_back(r);
  }

  NnZuptParams params;
  params.weights_path = options.weights_path;
  params.enable_zupt = options.enable_zupt;
  params.enable_nhc = options.enable_nhc;
  params.use_threshold_detector = options.use_threshold_detector;
  params.stop_prob_threshold = options.stop_prob_threshold;

  long zupt_frames = 0;
  long nn_frames = 0;
  std::string error;
  auto t0 = Clock::now();
  const auto rel_poses =
      integrateImuTrajectory(imu, frame_timestamps, params, &zupt_frames,
                             &nn_frames, &error);
  if (rel_poses.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = error.empty() ? "NN-ZUPT integration failed." : error;
    return res;
  }

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  for (const auto& T : rel_poses) {
    res.poses.push_back(anchorRelativePose(world_anchor, T));
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char note_buf[256];
  std::snprintf(
      note_buf, sizeof(note_buf),
      "NN-ZUPT (Meas. Sci. Technol. 2023): CNN zero-velocity detection + ZUPT/NHC "
      "DR; no GT seed. nn_frames=%ld zupt_frames=%ld threshold=%d",
      nn_frames, zupt_frames, options.use_threshold_detector ? 1 : 0);
  res.note = note_buf;
  return res;
}

struct ImuDeadReckoningDogfoodingOptions {
  double static_init_duration_s = 2.0;
  bool estimate_gyro_bias = true;
  bool estimate_accel_bias = false;
  bool motion_gated_static_init = false;
  int min_static_samples = 5;
  double static_accel_std_gate = 0.5;
  bool midpoint_integration = true;
  bool rk4_integration = false;
  bool enable_zupt = false;
  double zupt_gyro_threshold = 0.05;
  double zupt_accel_tolerance = 0.8;
  bool enable_leveling = false;
  double leveling_gain = 0.05;
  bool enable_zaru = false;
  double zaru_gain = 0.01;
  bool enable_nhc = false;
  double nhc_gain = 0.0;
  int forward_axis = 0;
  bool enable_eskf = false;
  double eskf_sigma_accel = 0.2;
  double eskf_sigma_gyro = 0.02;
  double eskf_zupt_sigma = 0.02;
  double eskf_nhc_sigma = 0.1;
  double eskf_leveling_sigma = 0.3;
};

MethodResult runImuDeadReckoning(
    const std::vector<Eigen::Matrix4d>& gt,
    const std::vector<double>& frame_timestamps,
    const std::vector<ImuSampleCsv>& imu_samples,
    const ImuDeadReckoningDogfoodingOptions& options) {
  using namespace localization_zoo::imu_dead_reckoning;
  MethodResult res;
  res.name = "IMU-DR";

  if (imu_samples.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note =
        "imu.csv not found. IMU dead reckoning requires synchronized IMU "
        "samples.";
    return res;
  }

  std::vector<ImuReading> imu;
  imu.reserve(imu_samples.size());
  for (const auto& s : imu_samples) {
    ImuReading r;
    r.stamp = s.timestamp;
    r.gyro = s.gyro;
    r.accel = s.accel;
    imu.push_back(r);
  }

  ImuDeadReckoningParams params;
  params.static_init_duration_s = options.static_init_duration_s;
  params.estimate_gyro_bias = options.estimate_gyro_bias;
  params.estimate_accel_bias = options.estimate_accel_bias;
  params.motion_gated_static_init = options.motion_gated_static_init;
  params.min_static_samples = options.min_static_samples;
  params.static_accel_std_gate = options.static_accel_std_gate;
  params.midpoint_integration = options.midpoint_integration;
  params.rk4_integration = options.rk4_integration;
  params.enable_zupt = options.enable_zupt;
  params.zupt_gyro_threshold = options.zupt_gyro_threshold;
  params.zupt_accel_tolerance = options.zupt_accel_tolerance;
  params.enable_leveling = options.enable_leveling;
  params.leveling_gain = options.leveling_gain;
  params.enable_zaru = options.enable_zaru;
  params.zaru_gain = options.zaru_gain;
  params.enable_nhc = options.enable_nhc;
  params.nhc_gain = options.nhc_gain;
  params.forward_axis = options.forward_axis;
  params.enable_eskf = options.enable_eskf;
  params.eskf_sigma_accel = options.eskf_sigma_accel;
  params.eskf_sigma_gyro = options.eskf_sigma_gyro;
  params.eskf_zupt_sigma = options.eskf_zupt_sigma;
  params.eskf_nhc_sigma = options.eskf_nhc_sigma;
  params.eskf_leveling_sigma = options.eskf_leveling_sigma;

  long zupt_frames = 0;
  std::string error;
  auto t0 = Clock::now();
  const auto rel_poses = integrateImuTrajectory(imu, frame_timestamps, params,
                                                &zupt_frames, &error);
  if (rel_poses.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note = error.empty() ? "IMU dead reckoning integration failed." : error;
    return res;
  }

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  for (const auto& T : rel_poses) {
    res.poses.push_back(anchorRelativePose(world_anchor, T));
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char note_buf[384];
  std::snprintf(
      note_buf, sizeof(note_buf),
      "IMU-DR baseline: unaided strapdown INS, static init %.1fs, "
      "eskf=%d midpoint=%d rk4=%d zupt=%d lvl=%d zaru=%d nhc=%d "
      "zupt_frames=%ld; no GT seed.%s%s",
      options.static_init_duration_s, options.enable_eskf ? 1 : 0,
      options.midpoint_integration ? 1 : 0, options.rk4_integration ? 1 : 0,
      options.enable_zupt ? 1 : 0, options.enable_leveling ? 1 : 0,
      options.enable_zaru ? 1 : 0, options.enable_nhc ? 1 : 0, zupt_frames,
      error.empty() ? "" : " ", error.c_str());
  res.note = note_buf;
  return res;
}

MethodResult runLeGOLOAM(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const LeGOLOAMDogfoodingOptions& options) {
  using namespace localization_zoo::lego_loam;
  MethodResult res;
  res.name = "LeGO-LOAM";

  LeGOLOAMParams params;
  params.scan_registration.n_scans = options.n_scans;
  params.scan_registration.ground_scan_limit = options.ground_scan_limit;
  params.scan_registration.num_subregions = options.num_subregions;
  params.scan_registration.neighbor_window = options.neighbor_window;
  params.scan_registration.minimum_range = options.minimum_range;
  params.scan_registration.maximum_range = options.maximum_range;
  params.scan_registration.sensor_height = options.sensor_height;
  params.scan_registration.ground_height_tolerance =
      options.ground_height_tolerance;
  params.scan_registration.sensor_mount_angle_deg =
      options.sensor_mount_angle_deg;
  params.scan_registration.ground_angle_threshold_deg =
      options.ground_angle_threshold_deg;
  params.scan_registration.scan_period = options.scan_period;
  params.scan_registration.curvature_threshold = options.curvature_threshold;
  params.scan_registration.max_corner_sharp = options.max_corner_sharp;
  params.scan_registration.max_corner_less_sharp =
      options.max_corner_less_sharp;
  params.scan_registration.max_surf_flat = options.max_surf_flat;
  params.scan_registration.less_flat_leaf_size = options.less_flat_leaf_size;

  params.odometry.distance_sq_threshold = options.odom_distance_sq_threshold;
  params.odometry.nearby_scan = options.odom_nearby_scan;
  params.odometry.num_optimization_iters = options.odom_outer_iters;
  params.odometry.ceres_max_iterations = options.odom_ceres_iters;
  params.odometry.huber_loss_s = options.odom_huber_loss_s;
  params.odometry.enable_distortion = false;

  params.mapping.line_resolution = options.map_line_resolution;
  params.mapping.plane_resolution = options.map_plane_resolution;
  params.mapping.num_optimization_iters = options.map_outer_iters;
  params.mapping.ceres_max_iterations = options.map_ceres_iters;
  params.mapping.huber_loss_s = options.map_huber_loss_s;
  params.mapping.knn = options.map_knn;
  params.mapping.knn_max_dist_sq = options.map_knn_max_dist_sq;
  params.mapping.edge_eigenvalue_ratio = options.map_edge_eigenvalue_ratio;
  params.mapping.plane_threshold = options.map_plane_threshold;

  LeGOLOAM pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  res.poses.push_back(world_anchor);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0 /* no downsample */);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud =
        toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    if (!result.valid) {
      if (i % 10 == 0) {
        std::cerr << "\r  [LeGO-LOAM] " << i << "/" << pcd_dirs.size();
      }
      continue;
    }

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    if (i % 10 == 0) {
      std::cerr << "\r  [LeGO-LOAM] " << i << "/" << pcd_dirs.size()
                << " ground=" << result.num_ground_points
                << " corner=" << result.num_corner_features
                << " surf=" << result.num_surface_features;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "Ground-aware feature odometry+mapping (no GT seed). n_scans=64 matches Velodyne HDL-64E layout.";
  return res;
}

MethodResult runMULLSLO(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const std::string& disable, bool highway) {
  using namespace localization_zoo::mulls;
  MethodResult res;
  res.name = "MULLS";
  // The elevation correction comes from --input-vertical-angle-correction-deg
  // like every other method; MULLS-LO applies its own 120 m horizontal limit
  // instead of the shared 80 m loader cap.
  MullsLOParams params = highway ? MullsLOParams::kittiHighway() : MullsLOParams();
  params.vertical_angle_correction_deg = 0.0;
  {
    std::stringstream ss(disable);
    std::string item;
    while (std::getline(ss, item, ',')) {
      if (item == "vertex-promotion") params.use_vertex_promotion = false;
      else if (item == "source-pruning") params.use_source_pruning = false;
      else if (item == "ground-balance") params.use_ground_balance = false;
      else if (item == "distance-weight") params.use_distance_weight = false;
      else if (item == "huber") params.use_huber = false;
      else if (item == "intensity-weight") params.use_intensity_weight = false;
      else if (item == "dynamic-removal") params.use_dynamic_removal = false;
      else if (item == "pillar-refresh") params.use_pillar_refresh = false;
      else if (item == "scan-to-map") params.use_scan_to_map = false;
      else if (!item.empty()) std::cerr << "unknown --mulls-lo-disable item: " << item << "\n";
    }
  }
  MullsLO lo(params);
  const Eigen::Matrix4d world_anchor = gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  size_t aborted = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    const fs::path path = resolvePointCloudPath(pcd_dirs[i] + "/cloud.pcd");
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZI>);
    if (path.extension() == ".bin") {
      if (!loadKittiBin(path, cloud.get())) cloud->clear();
    } else if (pcl::io::loadPCDFile<pcl::PointXYZI>(path.string(), *cloud) == -1) {
      cloud->clear();
    }
    applyInputVerticalAngleCorrection(cloud.get());
    float max_intensity = 0.0f;
    for (const auto& p : cloud->points)
      if (std::isfinite(p.intensity)) max_intensity = std::max(max_intensity, p.intensity);
    // KITTI stores reflectance in [0, 1]; MULLS works in [0, 255].
    const double scale = max_intensity <= 1.0f ? 255.0 : 1.0;
    std::vector<Eigen::Vector4d> xyzi;
    xyzi.reserve(cloud->size());
    for (const auto& p : cloud->points) {
      if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z)) continue;
      xyzi.emplace_back(p.x, p.y, p.z, std::isfinite(p.intensity) ? p.intensity * scale : 0.0);
    }
    const MullsLOFrameResult r = lo.process(xyzi);
    aborted += r.icp.aborted ? 1 : 0;
    res.poses.push_back(world_anchor * r.pose.matrix());
    if (i % 10 == 0) std::cerr << "\r  [MULLS-LO] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream note;
  note << "MULLS-LO (KITTI " << (highway ? "highway" : "urban")
       << " profile); anchor matches the first GT pose. "
       << aborted << " registrations stopped early (too few pairs or an implausible step).";
  if (!disable.empty()) note << " Disabled: " << disable << ".";
  res.note = note.str();
  return res;
}

MethodResult runMULLS(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const MULLSDogfoodingOptions& options) {
  using namespace localization_zoo::mulls;
  if (options.lo) return runMULLSLO(pcd_dirs, gt, options.lo_disable, options.lo_highway);
  MethodResult res;
  res.name = "MULLS";

  MULLSParams params;
  params.scan_registration.n_scans = options.n_scans;
  params.scan_registration.minimum_range = options.minimum_range;
  params.scan_registration.scan_period = options.scan_period;
  params.scan_registration.curvature_threshold = options.curvature_threshold;
  params.scan_registration.max_corner_sharp = options.max_corner_sharp;
  params.scan_registration.max_corner_less_sharp = options.max_corner_less_sharp;
  params.scan_registration.max_surf_flat = options.max_surf_flat;
  params.scan_registration.less_flat_leaf_size = options.less_flat_leaf_size;

  params.odometry.distance_sq_threshold = options.odom_distance_sq_threshold;
  params.odometry.nearby_scan = options.odom_nearby_scan;
  params.odometry.num_optimization_iters = options.odom_outer_iters;
  params.odometry.ceres_max_iterations = options.odom_ceres_iters;
  params.odometry.huber_loss_s = options.odom_huber_loss_s;
  params.odometry.enable_distortion = false;

  params.mapping.line_resolution = options.line_resolution;
  params.mapping.plane_resolution = options.plane_resolution;
  params.mapping.point_resolution = options.point_resolution;
  params.mapping.num_optimization_iters = options.mulls_map_iters;
  params.mapping.ceres_max_iterations = options.mulls_ceres_iters;
  params.mapping.huber_loss_s = options.mulls_huber_loss_s;
  params.mapping.knn = options.mulls_knn;
  params.mapping.knn_max_dist_sq = options.mulls_knn_max_dist_sq;
  params.mapping.edge_eigenvalue_ratio = options.mulls_edge_eigenvalue_ratio;
  params.mapping.plane_threshold = options.mulls_plane_threshold;
  params.mapping.point_neighbor_max_dist_sq =
      options.mulls_point_neighbor_max_dist_sq;
  params.mapping.line_weight = options.mulls_line_weight;
  params.mapping.plane_weight = options.mulls_plane_weight;
  params.mapping.point_weight = options.mulls_point_weight;
  params.mapping.full_downsample_rate = options.mulls_full_downsample_rate;
  params.mapping.max_frames_in_map = options.mulls_max_frames_in_map;

  MULLS pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  res.poses.push_back(world_anchor);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0 /* no downsample */);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud =
        toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    if (!result.valid) {
      if (i % 10 == 0) {
        std::cerr << "\r  [MULLS] " << i << "/" << pcd_dirs.size();
      }
      continue;
    }

    Eigen::Matrix4d T_rel = Eigen::Matrix4d::Identity();
    T_rel.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    T_rel.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, T_rel));

    if (i % 10 == 0) {
      std::cerr << "\r  [MULLS] " << i << "/" << pcd_dirs.size()
                << " L=" << result.num_line_constraints
                << " P=" << result.num_plane_constraints
                << " Pt=" << result.num_point_constraints
                << " map_frames=" << result.num_frames_in_map;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "Multi-metric scan-to-map (line/plane/point Ceres) after A-LOAM-style feature odometry (no GT seed).";
  return res;
}

MethodResult runNDT(const std::vector<std::string>& pcd_dirs,
                    const std::vector<Eigen::Matrix4d>& gt,
                    const NDTDogfoodingOptions& options,
                    bool no_gt_seed = false,
                    const std::vector<Eigen::Matrix4d>* external_seed_poses = nullptr,
                    const std::string& external_seed_note = "") {
  using namespace localization_zoo::ndt;
  MethodResult res;
  res.name = external_seed_poses ? "CT-ICP+NDT" : "NDT";

  NDTParams params;
  params.resolution = options.resolution;
  params.max_iterations = options.max_iterations;
  params.step_size = options.step_size;
  params.convergence_threshold = options.convergence_threshold;
  params.min_points_per_cell = options.min_points_per_cell;
  NDTRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt[0];
  Eigen::Matrix4d T_prev_prev_est = gt[0];
  res.poses.push_back(T_est);

  size_t seed_fallbacks = 0;
  size_t seeded_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      reg.setTarget(map_points);
      continue;
    }

    Eigen::Matrix4d T_init_guess = T_est;
    const bool gt_seeded_frame = !external_seed_poses && !no_gt_seed;
    if (external_seed_poses && i < external_seed_poses->size()) {
      T_init_guess = (*external_seed_poses)[i];
    } else if (no_gt_seed) {
      T_init_guess = i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est)
                            : T_est;
    } else {
      T_init_guess = applySeedPerturbation(gt[i], options.seed_perturbation);
    }
    const Eigen::Matrix4d T_prev_est_snapshot = T_est;
    const auto result = reg.align(pts_local, T_init_guess);
    if (gt_seeded_frame) ++seeded_frames;
    if ((result.converged || result.iterations >= 2) &&
        isReasonableRefinement(result.transformation, T_init_guess,
                               options.max_seed_translation_delta,
                               options.max_seed_rotation_delta_rad)) {
      T_est = result.transformation;
    } else {
      T_est = T_init_guess;
      if (gt_seeded_frame) ++seed_fallbacks;
    }
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);

    addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                   options.map_radius);
    if (shouldRefreshTargetMap(i, options.refresh_interval)) {
      reg.setTarget(map_points);
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [NDT] " << i << "/" << pcd_dirs.size()
                << " score=" << std::fixed << std::setprecision(3)
                << result.score;
    }
  }
  std::cerr << std::endl;
  if (seeded_frames > 0) {
    res.seed_fallback_rate_pct = 100.0 *
        static_cast<double>(seed_fallbacks) / static_cast<double>(seeded_frames);
    std::cerr << "  [NDT] seed fallbacks=" << seed_fallbacks << "/"
              << seeded_frames << " (" << res.seed_fallback_rate_pct
              << "% rolled back to GT seed)" << std::endl;
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  if (external_seed_poses) {
    res.note = external_seed_note.empty()
        ? "Uses external pose prior as scan-to-map initial guess."
        : external_seed_note;
  } else {
    res.note = no_gt_seed
        ? "Uses velocity-model prediction as scan-to-map initial guess (no GT seed)."
        : "Uses GT-seeded scan-to-map initialization with weak-update fallback "
          "in this dogfooding tool.";
  }
  if (!external_seed_poses && !no_gt_seed) {
    res.note += seedPerturbationNote(options.seed_perturbation);
  }
  return res;
}

MethodResult runFixedMapNDT(const std::vector<std::string>& pcd_dirs,
                            const std::vector<Eigen::Matrix4d>& gt,
                            const NDTDogfoodingOptions& ndt_options,
                            const CTICPDogfoodingOptions& ct_icp_options,
                            const FixedMapNDTOptions& fixed_map_options) {
  using namespace localization_zoo::ndt;

  MethodResult res;
  res.name = "FixedMap-NDT";
  if (fixed_map_options.seed_source == "ct_icp") {
    res.name += "+CTICP";
  } else if (fixed_map_options.seed_source == "scan_context") {
    res.name += "+ScanContext";
  } else if (fixed_map_options.seed_source == "velocity") {
    res.name += "+Vel";
  } else {
    res.name += "+GT";
  }

  NDTParams params;
  params.resolution = ndt_options.resolution;
  params.max_iterations = ndt_options.max_iterations;
  params.step_size = ndt_options.step_size;
  params.convergence_threshold = ndt_options.convergence_threshold;
  params.min_points_per_cell = ndt_options.min_points_per_cell;
  NDTRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  localization_zoo::scan_context::ScanContextParams sc_params;
  sc_params.exclude_recent_frames = 0;
  sc_params.distance_threshold = fixed_map_options.scan_context_distance_threshold;
  sc_params.num_candidates = std::max(1, fixed_map_options.scan_context_top_k);
  localization_zoo::scan_context::ScanContextManager scan_context(sc_params);
  std::vector<Eigen::Matrix4d> scan_context_poses;
  const int map_stride = std::max(1, fixed_map_options.map_stride);
  if (!fixed_map_options.map_ply_path.empty()) {
    map_points = loadPLYMap(fixed_map_options.map_ply_path,
                            ndt_options.source_voxel_size);
    if (map_points.empty()) {
      throw std::runtime_error("Failed to load fixed-map PLY: " +
                               fixed_map_options.map_ply_path);
    }
    map_points = limitPoints(map_points, ndt_options.map_max_points);
  }
  for (size_t i = 0; i < pcd_dirs.size() && i < gt.size();
       i += static_cast<size_t>(map_stride)) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         ndt_options.source_voxel_size),
                                 ndt_options.max_source_points);
    if (pts_local.empty()) continue;
    if (fixed_map_options.map_ply_path.empty()) {
      addPointsToMap(map_points, pts_local, gt[i], ndt_options.map_max_points,
                     0.0);
    }
    if (fixed_map_options.seed_source == "scan_context") {
      scan_context.addScan(pts_local);
      scan_context_poses.push_back(gt[i]);
    }
  }
  reg.setTarget(map_points);

  MethodResult ct_icp_prior;
  const std::vector<Eigen::Matrix4d>* prior_poses = nullptr;
  double prior_ate = std::numeric_limits<double>::quiet_NaN();
  if (fixed_map_options.seed_source == "ct_icp") {
    ct_icp_prior = runCTICP(pcd_dirs, gt, ct_icp_options, false);
    prior_poses = &ct_icp_prior.poses;
    prior_ate = computeATE(ct_icp_prior.poses, gt);
  }

  Eigen::Matrix4d T_est = gt.empty() ? Eigen::Matrix4d::Identity() : gt[0];
  Eigen::Matrix4d T_prev_prev_est = T_est;
  res.poses.push_back(T_est);
  std::vector<FixedMapNDTTraceFrame> trace_frames;
  FixedMapNDTPublishPolicyState publish_policy_state;
  FixedMapNDTTraceFrame previous_policy_frame;
  bool has_previous_policy_frame = false;
  size_t publish_pose_outputs = 0;
  size_t publish_unknown_outputs = 0;
  size_t publish_hold_outputs = 0;
  size_t gt_wrong_pose_suppressed = 0;
  size_t gt_unsafe_transition_suppressed = 0;
  auto update_publish_counters = [&](const FixedMapNDTTraceFrame& frame) {
    if (frame.publish_action == "publish_pose") {
      ++publish_pose_outputs;
    } else if (frame.publish_action == "hold_last_pose") {
      ++publish_hold_outputs;
    } else if (frame.publish_action == "return_unknown") {
      ++publish_unknown_outputs;
    }
    if (!frame.has_pose_output && frame.gt_wrong_pose) {
      ++gt_wrong_pose_suppressed;
    }
    if (!frame.has_pose_output && frame.gt_unsafe_transition) {
      ++gt_unsafe_transition_suppressed;
    }
  };
  FixedMapNDTTraceFrame frame0;
  frame0.frame_index = 0;
  frame0.decision = "anchor";
  frame0.seed_source = fixed_map_options.seed_source;
  frame0.seed_pose = T_est;
  frame0.refined_pose = T_est;
  frame0.final_pose = T_est;
  finalizeFixedMapNDTTraceFrame(frame0, gt, nullptr);
  annotateFixedMapNDTPublishPolicy(
      frame0, fixed_map_options, publish_policy_state, nullptr);
  update_publish_counters(frame0);
  previous_policy_frame = frame0;
  has_previous_policy_frame = true;
  if (!fixed_map_options.trace_json_path.empty()) {
    trace_frames.push_back(frame0);
  }

  size_t accepted = 0;
  size_t rejected = 0;
  size_t fallback_seed = 0;
  size_t scan_context_hits = 0;
  size_t scan_context_candidates_evaluated = 0;
  double scan_context_distance_sum = 0.0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         ndt_options.source_voxel_size),
                                 ndt_options.max_source_points);
    if (pts_local.empty()) continue;
    if (i == 0) continue;

    const Eigen::Matrix4d T_prev_est_snapshot = T_est;
    FixedMapNDTTraceFrame trace;
    trace.frame_index = i;
    trace.seed_source = fixed_map_options.seed_source;
    trace.seed_pose = T_est;
    trace.refined_pose = T_est;
    trace.final_pose = T_est;

    Eigen::Matrix4d T_seed = T_est;
    if (fixed_map_options.seed_source == "ct_icp") {
      if (prior_poses && i < prior_poses->size() && isFiniteMatrix((*prior_poses)[i])) {
        T_seed = (*prior_poses)[i];
      } else {
        ++fallback_seed;
        trace.seed_fallback = true;
      }
    } else if (fixed_map_options.seed_source == "scan_context") {
      const auto candidates = scan_context.detectLoopCandidates(pts_local);
      trace.scan_context_candidate_count = static_cast<int>(candidates.size());
      if (candidates.empty()) {
        ++fallback_seed;
        trace.seed_fallback = true;
      } else {
        ++scan_context_hits;
        trace.scan_context_hit = true;
        trace.scan_context_front_distance = candidates.front().distance;
        scan_context_distance_sum += candidates.front().distance;

        bool best_valid = false;
        double best_score = std::numeric_limits<double>::infinity();
        Eigen::Matrix4d best_pose = T_est;
        Eigen::Matrix4d best_seed_pose = T_est;
        Eigen::Matrix4d best_refined_pose = T_est;
        int best_iterations = 0;
        bool best_converged = false;
        for (const auto& candidate : candidates) {
          if (!candidate.valid ||
              candidate.index < 0 ||
              candidate.index >= static_cast<int>(scan_context_poses.size())) {
            continue;
          }
          Eigen::Matrix4d candidate_seed =
              scan_context_poses[static_cast<size_t>(candidate.index)];
          const Eigen::Matrix4d yaw_delta =
              (Eigen::Translation3d(0.0, 0.0, 0.0) *
               Eigen::AngleAxisd(candidate.yaw_offset_rad,
                                 Eigen::Vector3d::UnitZ()))
                  .matrix();
          candidate_seed = candidate_seed * yaw_delta;
          const auto result = reg.align(pts_local, candidate_seed);
          ++scan_context_candidates_evaluated;
          ++trace.scan_context_candidates_evaluated;
          if ((result.converged || result.iterations >= 2) &&
              std::isfinite(result.score) &&
              isFiniteMatrix(result.transformation) &&
              isReasonableRefinement(result.transformation, candidate_seed,
                                     ndt_options.max_seed_translation_delta,
                                     ndt_options.max_seed_rotation_delta_rad) &&
              result.score < best_score) {
            best_valid = true;
            best_score = result.score;
            best_pose = result.transformation;
            best_seed_pose = candidate_seed;
            best_refined_pose = result.transformation;
            best_iterations = result.iterations;
            best_converged = result.converged;
            trace.selected_candidate_index = candidate.index;
            trace.selected_candidate_distance = candidate.distance;
            trace.selected_candidate_yaw_offset_rad = candidate.yaw_offset_rad;
          }
        }

        trace.ndt_score = best_score;
        trace.ndt_iterations = best_iterations;
        trace.ndt_converged = best_converged;
        trace.seed_pose = best_seed_pose;
        trace.refined_pose = best_refined_pose;
        if (best_valid) {
          T_est = best_pose;
          ++accepted;
          trace.accepted = true;
          trace.decision = "accepted";
        } else {
          T_est = T_prev_est_snapshot;
          ++rejected;
          trace.accepted = false;
          trace.decision = trace.scan_context_candidates_evaluated > 0
                               ? "rejected"
                               : "no_valid_scan_context_candidate";
        }
        trace.final_pose = T_est;
        finalizeFixedMapNDTTraceFrame(trace, gt, &T_prev_est_snapshot);
        annotateFixedMapNDTPublishPolicy(
            trace, fixed_map_options, publish_policy_state,
            has_previous_policy_frame ? &previous_policy_frame : nullptr);
        update_publish_counters(trace);
        previous_policy_frame = trace;
        has_previous_policy_frame = true;
        T_prev_prev_est = T_prev_est_snapshot;
        res.poses.push_back(T_est);
        if (!fixed_map_options.trace_json_path.empty()) {
          trace_frames.push_back(trace);
        }

        if (i % 10 == 0) {
          std::cerr << "\r  [FixedMap-NDT] " << i << "/" << pcd_dirs.size()
                    << " sc_candidates=" << candidates.size()
                    << " best_score=" << std::fixed << std::setprecision(3)
                    << best_score
                    << " accepted=" << accepted << "/" << (accepted + rejected);
        }
        continue;
      }
    } else if (fixed_map_options.seed_source == "velocity") {
      T_seed = i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est) : T_est;
    } else {
      T_seed = applySeedPerturbation(gt[i], ndt_options.seed_perturbation);
    }

    trace.seed_pose = T_seed;
    const auto result = reg.align(pts_local, T_seed);
    trace.refined_pose = result.transformation;
    trace.ndt_score = result.score;
    trace.ndt_iterations = result.iterations;
    trace.ndt_converged = result.converged;
    if ((result.converged || result.iterations >= 2) &&
        isFiniteMatrix(result.transformation) &&
        isReasonableRefinement(result.transformation, T_seed,
                               ndt_options.max_seed_translation_delta,
                               ndt_options.max_seed_rotation_delta_rad)) {
      T_est = result.transformation;
      ++accepted;
      trace.accepted = true;
      trace.decision = "accepted";
    } else {
      T_est = T_seed;
      ++rejected;
      trace.accepted = false;
      trace.decision = "rejected_to_seed";
    }
    trace.final_pose = T_est;
    finalizeFixedMapNDTTraceFrame(trace, gt, &T_prev_est_snapshot);
    annotateFixedMapNDTPublishPolicy(
        trace, fixed_map_options, publish_policy_state,
        has_previous_policy_frame ? &previous_policy_frame : nullptr);
    update_publish_counters(trace);
    previous_policy_frame = trace;
    has_previous_policy_frame = true;
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);
    if (!fixed_map_options.trace_json_path.empty()) {
      trace_frames.push_back(trace);
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [FixedMap-NDT] " << i << "/" << pcd_dirs.size()
                << " score=" << std::fixed << std::setprecision(3)
                << result.score
                << " accepted=" << accepted << "/" << (accepted + rejected);
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count() +
      ct_icp_prior.time_ms;

  std::ostringstream note;
  note << "Fixed-map NDT: target map ";
  if (fixed_map_options.map_ply_path.empty()) {
    note << "built once from GT/reference poses (stride=" << map_stride
         << ", map_points=" << map_points.size() << ")";
  } else {
    note << "loaded from PLY=" << fixed_map_options.map_ply_path
         << " (map_points=" << map_points.size() << ")";
  }
  note << ". Seed source=" << fixed_map_options.seed_source
       << ", accepted=" << accepted << "/" << (accepted + rejected)
       << ", rejected=" << rejected
       << ", seed fallbacks=" << fallback_seed
       << ". Runtime publish policy outputs="
       << publish_pose_outputs
       << ", holds=" << publish_hold_outputs
       << ", unknown=" << publish_unknown_outputs
       << ", GT-wrong suppressed=" << gt_wrong_pose_suppressed
       << ", GT-unsafe transitions suppressed="
       << gt_unsafe_transition_suppressed << ".";
  if (fixed_map_options.seed_source == "scan_context") {
    note << " ScanContext hits=" << scan_context_hits << "/" << (pcd_dirs.size() - 1)
         << ", top_k=" << fixed_map_options.scan_context_top_k
         << ", NDT candidates evaluated=" << scan_context_candidates_evaluated
         << ", mean distance=";
    if (scan_context_hits > 0) {
      note << std::fixed << std::setprecision(4)
           << (scan_context_distance_sum / scan_context_hits) << ".";
    } else {
      note << "n/a.";
    }
  }
  if (fixed_map_options.seed_source == "ct_icp") {
    note << " CT-ICP prior ATE=";
    if (std::isfinite(prior_ate)) {
      note << std::fixed << std::setprecision(3) << prior_ate << "m.";
    } else {
      note << "nonfinite.";
    }
    note << " Runtime is CT-ICP+NDT combined.";
  } else if (fixed_map_options.seed_source == "gt") {
    note << seedPerturbationNote(ndt_options.seed_perturbation);
  }
  if (!fixed_map_options.trace_json_path.empty()) {
    writeFixedMapNDTTraceJson(fixed_map_options.trace_json_path,
                              fixed_map_options, pcd_dirs.size(),
                              map_points.size(), trace_frames);
    note << " Per-frame trace=" << fixed_map_options.trace_json_path << ".";
  }
  res.note = note.str();
  return res;
}

MethodResult runKISSICP(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const KISSICPDogfoodingOptions& options) {
  using namespace localization_zoo::kiss_icp;
  MethodResult res;
  res.name = "KISS-ICP";

  KISSICPParams params;
  params.voxel_size = options.voxel_size;
  params.initial_threshold = options.initial_threshold;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  params.update_full_voxels = options.update_full_voxels;
  params.neighbor_voxel_radius = options.neighbor_voxel_radius;
  params.min_range = options.min_range;
  params.convergence_criterion = options.convergence_criterion;
  params.registration_voxel_multiplier =
      options.registration_voxel_multiplier;
  params.geman_mcclure_kernel = options.geman_mcclure_kernel;
  params.map_min_point_distance = options.map_min_point_distance;
  params.use_model_deviation_threshold =
      options.use_model_deviation_threshold;
  params.model_deviation_correspondence_multiplier =
      options.model_deviation_correspondence_multiplier;
  params.enable_motion_guard = options.enable_motion_guard;
  params.max_step_translation_m = options.max_step_translation_m;
  params.max_step_rotation_rad =
      options.max_step_rotation_deg * (std::acos(-1.0) / 180.0);
  params.enable_adaptive_motion_guard =
      options.enable_adaptive_motion_guard;
  params.adaptive_motion_guard_min_trusted_steps =
      options.adaptive_motion_guard_min_trusted_steps;
  params.adaptive_motion_guard_max_translation_multiplier =
      options.adaptive_motion_guard_max_translation_multiplier;
  params.adaptive_motion_guard_translation_consistency_m =
      options.adaptive_motion_guard_translation_consistency_m;
  params.adaptive_motion_guard_rotation_consistency_rad =
      options.adaptive_motion_guard_rotation_consistency_deg *
      (std::acos(-1.0) / 180.0);
  KISSICPPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double threshold_sum = 0.0;
  double threshold_min = std::numeric_limits<double>::infinity();
  double threshold_max = 0.0;
  std::size_t threshold_samples = 0;
  double algorithm_time_ms = 0.0;
  std::size_t deskewed_frames = 0;
  std::size_t deskew_timestamp_fallbacks = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    std::vector<Eigen::Vector3d> pts_local;
    if (options.deskew_mulran) {
      LoadedScan scan =
          loadTimedPCD(pcd_dirs[i] + "/cloud.pcd", 0.0, false);
      if (scan.has_per_point_time &&
          scan.points.size() == scan.relative_times.size()) {
        pts_local = deskewScanToEnd(
            scan.points, scan.relative_times, pipeline.lastDelta());
        pts_local =
            voxelDownsamplePoints(pts_local, options.source_voxel_size);
        pts_local = filterPointRange(pts_local, 1.0, 80.0);
        ++deskewed_frames;
      } else {
        pts_local =
            loadPCD(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size);
        ++deskew_timestamp_fallbacks;
      }
    } else {
      pts_local =
          loadPCD(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size);
    }
    pts_local = limitPoints(pts_local, options.max_source_points);
    correctElevationAngle(
        pts_local, options.vertical_angle_correction_deg *
                       (std::acos(-1.0) / 180.0));
    if (pts_local.empty()) continue;

    const auto algorithm_start = Clock::now();
    const auto result = pipeline.registerFrame(pts_local);
    algorithm_time_ms += std::chrono::duration<double, std::milli>(
                             Clock::now() - algorithm_start)
                             .count();
    const double threshold = pipeline.adaptiveThreshold();
    if (std::isfinite(threshold)) {
      threshold_sum += threshold;
      threshold_min = std::min(threshold_min, threshold);
      threshold_max = std::max(threshold_max, threshold);
      ++threshold_samples;
    }
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [KISS-ICP] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.algorithm_time_ms = algorithm_time_ms;
  if (threshold_samples > 0) {
    std::ostringstream note;
    note << "Adaptive sigma min/mean/max=" << threshold_min << "/"
         << threshold_sum / static_cast<double>(threshold_samples) << "/"
         << threshold_max << "; correspondence_multiplier="
         << (options.use_model_deviation_threshold
                 ? options.model_deviation_correspondence_multiplier
                 : 1.0)
         << "; neighbor_voxel_radius="
         << (options.neighbor_voxel_radius >= 0
                 ? std::to_string(options.neighbor_voxel_radius)
                 : std::string("auto"))
         << "; vertical_angle_correction_deg="
         << options.vertical_angle_correction_deg
         << "; mulran_deskew="
         << (options.deskew_mulran ? "on" : "off")
         << "; deskewed_frames=" << deskewed_frames
         << "; deskew_timestamp_fallbacks=" << deskew_timestamp_fallbacks
         << "; motion_guard="
         << (options.enable_motion_guard ? "on" : "off")
         << "; motion_guard_rejections=" << pipeline.motionGuardRejections()
         << "; adaptive_motion_guard_acceptances="
         << pipeline.adaptiveMotionGuardAcceptances()
         << "; end_to_end_fps="
         << (res.time_ms > 0.0
                 ? res.poses.size() / (res.time_ms / 1000.0)
                 : 0.0)
         << "; algorithm_fps="
         << (res.algorithm_time_ms > 0.0
                 ? res.poses.size() / (res.algorithm_time_ms / 1000.0)
                 : 0.0)
         << ".";
    res.note = note.str();
  }
  return res;
}

MethodResult runKISSPoseGraph(
    const std::vector<std::string>& pcd_dirs,
    const std::vector<Eigen::Matrix4d>& gt,
    const KISSICPDogfoodingOptions& options,
    double scan_context_threshold,
    double correction_gain,
    const std::string& external_pose_path,
    bool causal_output = false) {
  using namespace localization_zoo::kiss_icp;
  MethodResult res;
  if (causal_output) {
    res.name = external_pose_path.empty() ? "KISS-Pose-Graph-Causal"
                                          : "External-KISS-Pose-Graph-Causal";
  } else {
    res.name = external_pose_path.empty() ? "KISS-Pose-Graph"
                                          : "External-KISS-Pose-Graph";
  }

  std::vector<Eigen::Matrix4d> external_poses;
  if (!external_pose_path.empty()) {
    external_poses = loadKittiPoseMatrices(external_pose_path);
    if (external_poses.size() < pcd_dirs.size()) {
      std::ostringstream message;
      message << "External pose count " << external_poses.size()
              << " is smaller than selected point-cloud frame count "
              << pcd_dirs.size();
      throw std::runtime_error(message.str());
    }
    external_poses.resize(pcd_dirs.size());
  }

  KISSICPParams frontend_params;
  frontend_params.voxel_size = options.voxel_size;
  frontend_params.initial_threshold = options.initial_threshold;
  frontend_params.max_points_per_voxel = options.max_points_per_voxel;
  frontend_params.max_icp_iterations = options.max_icp_iterations;
  frontend_params.local_map_radius = options.local_map_radius;
  frontend_params.map_cleanup_interval = options.map_cleanup_interval;
  frontend_params.update_full_voxels = options.update_full_voxels;
  frontend_params.neighbor_voxel_radius = options.neighbor_voxel_radius;
  frontend_params.use_model_deviation_threshold =
      options.use_model_deviation_threshold;
  frontend_params.model_deviation_correspondence_multiplier =
      options.model_deviation_correspondence_multiplier;
  frontend_params.enable_motion_guard = options.enable_motion_guard;
  frontend_params.max_step_translation_m = options.max_step_translation_m;
  frontend_params.max_step_rotation_rad =
      options.max_step_rotation_deg * (std::acos(-1.0) / 180.0);
  frontend_params.enable_adaptive_motion_guard =
      options.enable_adaptive_motion_guard;
  frontend_params.adaptive_motion_guard_min_trusted_steps =
      options.adaptive_motion_guard_min_trusted_steps;
  frontend_params.adaptive_motion_guard_max_translation_multiplier =
      options.adaptive_motion_guard_max_translation_multiplier;
  frontend_params.adaptive_motion_guard_translation_consistency_m =
      options.adaptive_motion_guard_translation_consistency_m;
  frontend_params.adaptive_motion_guard_rotation_consistency_rad =
      options.adaptive_motion_guard_rotation_consistency_deg *
      (std::acos(-1.0) / 180.0);
  KISSICPPipeline frontend(frontend_params);

  localization_zoo::hdl_graph_slam::HdlGraphSlamParams backend_params;
  backend_params.registration_voxel_size = 0.8;
  backend_params.map_voxel_size = 0.8;
  backend_params.keyframe_stride = 10;
  backend_params.keyframe_translation_threshold =
      std::numeric_limits<double>::infinity();
  backend_params.keyframe_rotation_threshold_rad =
      std::numeric_limits<double>::infinity();
  backend_params.min_loop_index_gap = 30;
  backend_params.scan_context.exclude_recent_frames = 30;
  backend_params.scan_context.distance_threshold =
      scan_context_threshold;
  backend_params.scan_context.num_candidates = 5;
  backend_params.loop_gicp.max_correspondence_distance = 5.0;
  backend_params.loop_gicp.max_iterations = 30;
  backend_params.loop_fitness_threshold =
      std::numeric_limits<double>::infinity();
  backend_params.loop_rmse_threshold = 1.0;
  backend_params.min_loop_correspondences = 80;
  backend_params.loop_submap_half_window = 2;
  backend_params.min_loop_clusters_for_correction = 2;
  backend_params.loop_cluster_keyframe_radius = 5;
  backend_params.descriptor_stride = 1;
  backend_params.loop_stride = 2;
  backend_params.enable_floor_constraint = false;
  backend_params.optimize_every_n_keyframes = 0;
  backend_params.odom_rotation_weight = 40.0;
  backend_params.odom_translation_weight = 20.0;
  backend_params.loop_rotation_weight = 200.0;
  backend_params.loop_translation_weight = 100.0;
  localization_zoo::hdl_graph_slam::HdlGraphSlam backend(backend_params);

  std::vector<Eigen::Matrix4d> raw_poses;
  raw_poses.reserve(pcd_dirs.size());
  std::vector<Eigen::Matrix4d> causal_poses;
  causal_poses.reserve(pcd_dirs.size());
  double algorithm_time_ms = 0.0;
  std::size_t deskewed_frames = 0;
  std::size_t deskew_timestamp_fallbacks = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); ++i) {
    std::vector<Eigen::Vector3d> points;
    if (options.deskew_mulran) {
      LoadedScan scan =
          loadTimedPCD(pcd_dirs[i] + "/cloud.pcd", 0.0, false);
      if (scan.has_per_point_time &&
          scan.points.size() == scan.relative_times.size()) {
        points = deskewScanToEnd(
            scan.points, scan.relative_times, frontend.lastDelta());
        points = voxelDownsamplePoints(points, options.source_voxel_size);
        points = filterPointRange(points, 1.0, 80.0);
        ++deskewed_frames;
      } else {
        points =
            loadPCD(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size);
        ++deskew_timestamp_fallbacks;
      }
    } else {
      points =
          loadPCD(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size);
    }
    points = limitPoints(points, options.max_source_points);
    correctElevationAngle(
        points, options.vertical_angle_correction_deg *
                    (std::acos(-1.0) / 180.0));
    if (points.empty()) continue;

    const auto algorithm_start = Clock::now();
    Eigen::Matrix4d frontend_pose;
    if (external_poses.empty()) {
      frontend_pose = frontend.registerFrame(points).pose;
    } else {
      frontend_pose = external_poses[i];
    }
    raw_poses.push_back(frontend_pose);
    const auto cloud = toPclXYZICloud(points);
    const auto backend_result =
        backend.processExternalOdometry(cloud, frontend_pose);
    causal_poses.push_back(backend_result.pose);
    algorithm_time_ms +=
        std::chrono::duration<double, std::milli>(
            Clock::now() - algorithm_start)
            .count();
    if (i % 10 == 0) {
      std::cerr << "\r  [KISS-PG] " << i << "/" << pcd_dirs.size()
                << " kf=" << backend_result.num_keyframes
                << " loops=" << backend_result.num_loop_edges
                << " clusters=" << backend.numLoopClusters()
                << " correction="
                << (backend.loopCorrectionEnabled() ? "on" : "off");
    }
  }
  std::cerr << std::endl;

  const auto correction_start = Clock::now();
  const auto corrected = causal_output
                             ? causal_poses
                             : backend.correctedExternalTrajectory(
                                   raw_poses, correction_gain);
  algorithm_time_ms +=
      std::chrono::duration<double, std::milli>(
          Clock::now() - correction_start)
          .count();
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  res.poses.reserve(corrected.size());
  for (const auto& pose : corrected) {
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
  }
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.algorithm_time_ms = algorithm_time_ms;
  std::ostringstream note;
  note << (external_poses.empty()
               ? "KISS odometry with GT-free Scan Context/GICP pose graph; "
               : "External odometry with GT-free Scan Context/GICP pose graph; ")
       << "external_pose_path="
       << (external_pose_path.empty() ? "none" : external_pose_path) << "; "
       << "output_policy="
       << (causal_output
               ? "current_pose_corrected_only_by_loops_available_through_current_frame"
               : "offline_retrospective_trajectory_correction")
       << "; "
       << "keyframes=" << backend.numKeyframes()
       << "; loop_edges=" << backend.numLoopEdges()
       << "; loop_clusters=" << backend.numLoopClusters()
       << "; min_loop_clusters_for_correction=2"
       << "; loop_cluster_keyframe_radius=5"
       << "; correction_enabled="
       << (backend.loopCorrectionEnabled() ? "true" : "false")
       << "; loop_candidates=" << backend.loopCandidateDetections()
       << "; loop_registration_rejections="
       << backend.loopRegistrationRejections()
       << "; candidate_distance_min/mean="
       << backend.minLoopCandidateDistance() << "/"
       << backend.meanLoopCandidateDistance()
       << "; keyframe_stride=10; scan_context_threshold="
       << scan_context_threshold
       << "; correction_gain=" << correction_gain
       << "; loop_submap_half_window=2"
       << "; floor_constraint=off"
       << "; deskewed_frames=" << deskewed_frames
       << "; deskew_timestamp_fallbacks="
       << deskew_timestamp_fallbacks
       << "; motion_guard_rejections="
       << frontend.motionGuardRejections()
       << "; adaptive_motion_guard_acceptances="
       << frontend.adaptiveMotionGuardAcceptances()
       << "; algorithm_fps="
       << (algorithm_time_ms > 0.0
               ? raw_poses.size() /
                     (algorithm_time_ms / 1000.0)
               : 0.0)
       << "; loop_attempts=[";
  const auto& loop_attempts = backend.loopAttempts();
  for (size_t i = 0; i < loop_attempts.size(); ++i) {
    const auto& attempt = loop_attempts[i];
    if (i > 0) note << ",";
    note << attempt.from << "->" << attempt.to
         << ":d=" << attempt.descriptor_distance
         << ":converged=" << (attempt.converged ? 1 : 0)
         << ":fitness=" << attempt.fitness
         << ":rmse=" << attempt.rmse
         << ":corr=" << attempt.correspondences
         << ":accepted=" << (attempt.accepted ? 1 : 0);
  }
  note << "].";
  res.note = note.str();
  return res;
}

MethodResult runKISSMultiHorizon(
    const std::vector<std::string>& pcd_dirs,
    const std::vector<Eigen::Matrix4d>& gt,
    const KISSMultiHorizonDogfoodingOptions& options) {
  using namespace localization_zoo::kiss_icp;
  MethodResult res;
  res.name = "KISS-Multi-Horizon";

  KISSICPParams frontend_params;
  frontend_params.voxel_size = options.frontend.voxel_size;
  frontend_params.initial_threshold = options.frontend.initial_threshold;
  frontend_params.max_points_per_voxel =
      options.frontend.max_points_per_voxel;
  frontend_params.max_icp_iterations =
      options.frontend.max_icp_iterations;
  frontend_params.local_map_radius = options.frontend.local_map_radius;
  frontend_params.map_cleanup_interval =
      options.frontend.map_cleanup_interval;
  frontend_params.update_full_voxels =
      options.frontend.update_full_voxels;
  frontend_params.neighbor_voxel_radius =
      options.frontend.neighbor_voxel_radius;
  frontend_params.use_model_deviation_threshold =
      options.frontend.use_model_deviation_threshold;
  frontend_params.model_deviation_correspondence_multiplier =
      options.frontend.model_deviation_correspondence_multiplier;
  frontend_params.enable_motion_guard =
      options.frontend.enable_motion_guard;
  frontend_params.max_step_translation_m =
      options.frontend.max_step_translation_m;
  frontend_params.max_step_rotation_rad =
      options.frontend.max_step_rotation_deg *
      (std::acos(-1.0) / 180.0);
  KISSICPPipeline frontend(frontend_params);

  KISSMatcherParams matcher_params;
  matcher_params.target_voxel_size = options.matcher_voxel_size;
  matcher_params.source_voxel_size = options.matcher_voxel_size;
  matcher_params.max_correspondence_distance =
      options.matcher_max_correspondence_distance;
  matcher_params.max_icp_iterations = options.matcher_max_iterations;
  matcher_params.min_correspondences =
      options.matcher_min_correspondences;

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  std::vector<std::vector<Eigen::Vector3d>> scans;
  std::vector<Eigen::Matrix4d> raw_poses;
  std::vector<Eigen::Matrix4d> corrected_poses;
  scans.reserve(pcd_dirs.size());
  raw_poses.reserve(pcd_dirs.size());
  corrected_poses.reserve(pcd_dirs.size());
  res.poses.reserve(pcd_dirs.size());

  Eigen::Matrix4d correction = Eigen::Matrix4d::Identity();
  Eigen::Matrix4d correction_at_previous_keyframe = correction;
  size_t previous_keyframe = 0;
  int accepted_constraints = 0;
  int rejected_constraints = 0;
  int rejected_registration = 0;
  int rejected_rmse = 0;
  int rejected_degeneracy = 0;
  int rejected_motion = 0;
  int rejected_consensus = 0;
  int correction_events = 0;
  std::size_t deskewed_frames = 0;
  std::size_t deskew_timestamp_fallbacks = 0;
  double observed_rmse_sum = 0.0;
  double observed_rmse_min = std::numeric_limits<double>::infinity();
  double observed_rmse_max = 0.0;
  int observed_rmse_count = 0;

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    std::vector<Eigen::Vector3d> points;
    if (options.frontend.deskew_mulran) {
      LoadedScan scan =
          loadTimedPCD(pcd_dirs[i] + "/cloud.pcd", 0.0, false);
      if (scan.has_per_point_time &&
          scan.points.size() == scan.relative_times.size()) {
        points = deskewScanToEnd(
            scan.points, scan.relative_times, frontend.lastDelta());
        points = voxelDownsamplePoints(
            points, options.frontend.source_voxel_size);
        points = filterPointRange(points, 1.0, 80.0);
        ++deskewed_frames;
      } else {
        points = loadPCD(pcd_dirs[i] + "/cloud.pcd",
                         options.frontend.source_voxel_size);
        ++deskew_timestamp_fallbacks;
      }
    } else {
      points = loadPCD(pcd_dirs[i] + "/cloud.pcd",
                       options.frontend.source_voxel_size);
    }
    points = limitPoints(points, options.frontend.max_source_points);
    correctElevationAngle(
        points, options.frontend.vertical_angle_correction_deg *
                    (std::acos(-1.0) / 180.0));
    if (points.empty()) continue;

    const auto frontend_result = frontend.registerFrame(points);
    scans.push_back(points);
    raw_poses.push_back(frontend_result.pose);
    corrected_poses.push_back(correction * frontend_result.pose);
    res.poses.push_back(
        anchorRelativePose(world_anchor, corrected_poses.back()));

    const size_t current = raw_poses.size() - 1;
    if (options.correction_gain <= 0.0 || current == 0 ||
        current % static_cast<size_t>(options.keyframe_stride) != 0) {
      continue;
    }

    const Eigen::Matrix4d base_pose = correction * raw_poses[current];
    Eigen::Matrix<double, 6, 1> weighted_delta =
        Eigen::Matrix<double, 6, 1>::Zero();
    double total_weight = 0.0;
    std::vector<Eigen::Matrix<double, 6, 1>> constraint_deltas;

    for (const int horizon : options.horizons) {
      if (horizon <= 0 || current < static_cast<size_t>(horizon)) continue;
      const size_t target = current - static_cast<size_t>(horizon);

      std::vector<Eigen::Vector3d> target_submap;
      for (size_t submap_frame = target;
           submap_frame < current &&
           submap_frame < target + static_cast<size_t>(options.submap_frames);
           ++submap_frame) {
        const Eigen::Matrix4d frame_to_target =
            raw_poses[target].inverse() * raw_poses[submap_frame];
        auto transformed =
            transformPoints(scans[submap_frame], frame_to_target);
        target_submap.insert(target_submap.end(),
                             transformed.begin(), transformed.end());
      }
      KISSMatcher matcher(matcher_params);
      matcher.setTarget(target_submap);
      const Eigen::Matrix4d initial_relative =
          raw_poses[target].inverse() * raw_poses[current];
      const auto match = matcher.align(scans[current], initial_relative);
      if (!match.converged ||
          match.num_correspondences <
              options.matcher_min_correspondences) {
        ++rejected_constraints;
        ++rejected_registration;
        continue;
      }
      if (std::isfinite(match.rmse)) {
        observed_rmse_sum += match.rmse;
        observed_rmse_min = std::min(observed_rmse_min, match.rmse);
        observed_rmse_max = std::max(observed_rmse_max, match.rmse);
        ++observed_rmse_count;
      }
      if (!std::isfinite(match.rmse) ||
          match.rmse > options.max_matcher_rmse) {
        ++rejected_constraints;
        ++rejected_rmse;
        continue;
      }
      if (!std::isfinite(match.information_condition) ||
          match.information_condition >
              options.max_information_condition) {
        ++rejected_constraints;
        ++rejected_degeneracy;
        continue;
      }

      const Eigen::Matrix4d candidate =
          corrected_poses[target] * match.transform;
      const Eigen::Matrix4d delta = base_pose.inverse() * candidate;
      const double translation = delta.block<3, 1>(0, 3).norm();
      Eigen::AngleAxisd angle_axis(delta.block<3, 3>(0, 0));
      const double angle = std::abs(angle_axis.angle());
      if (!std::isfinite(angle) ||
          translation > options.max_correction_translation ||
          angle > options.max_correction_rotation_rad) {
        ++rejected_constraints;
        ++rejected_motion;
        continue;
      }

      Eigen::Matrix<double, 6, 1> delta_vector;
      delta_vector.head<3>().setZero();
      if (angle >= 1e-12) {
        delta_vector.head<3>() =
            angle_axis.axis() * angle_axis.angle();
      }
      delta_vector.tail<3>() = delta.block<3, 1>(0, 3);
      const double degeneracy_weight =
          std::clamp(1.0 / std::sqrt(match.information_condition),
                     1e-3, 1.0);
      const double weight =
          degeneracy_weight * match.num_correspondences /
          std::max(match.rmse * match.rmse, 1e-4);
      weighted_delta += weight * delta_vector;
      total_weight += weight;
      constraint_deltas.push_back(delta_vector);
      ++accepted_constraints;
    }

    if (total_weight > 0.0) {
      const Eigen::Matrix<double, 6, 1> unscaled_mean =
          weighted_delta / total_weight;
      bool consensus = constraint_deltas.size() >= 2;
      for (const auto& delta : constraint_deltas) {
        if ((delta.tail<3>() - unscaled_mean.tail<3>()).norm() >
                options.max_consensus_translation ||
            (delta.head<3>() - unscaled_mean.head<3>()).norm() >
                options.max_consensus_rotation_rad) {
          consensus = false;
          break;
        }
      }
      if (!consensus) {
        ++rejected_consensus;
        previous_keyframe = current;
        correction_at_previous_keyframe = correction;
        continue;
      }
      const Eigen::Matrix<double, 6, 1> mean_delta =
          options.correction_gain * unscaled_mean;
      Eigen::Matrix4d scaled_delta = Eigen::Matrix4d::Identity();
      const double rotation_norm = mean_delta.head<3>().norm();
      if (rotation_norm > 1e-12) {
        scaled_delta.block<3, 3>(0, 0) =
            Eigen::AngleAxisd(rotation_norm,
                              mean_delta.head<3>() / rotation_norm)
                .toRotationMatrix();
      }
      scaled_delta.block<3, 1>(0, 3) = mean_delta.tail<3>();
      const Eigen::Matrix4d corrected_current = base_pose * scaled_delta;
      const Eigen::Matrix4d new_correction =
          corrected_current * raw_poses[current].inverse();

      const size_t window_start = previous_keyframe + 1;
      const size_t window_length =
          std::max<size_t>(current - previous_keyframe, 1);
      for (size_t frame = window_start; frame <= current; ++frame) {
        const double alpha =
            static_cast<double>(frame - previous_keyframe) / window_length;
        const Eigen::Matrix4d interpolated_correction =
            interpolateTransform(correction_at_previous_keyframe,
                                 new_correction, alpha);
        corrected_poses[frame] =
            interpolated_correction * raw_poses[frame];
        res.poses[frame] =
            anchorRelativePose(world_anchor, corrected_poses[frame]);
      }
      correction = new_correction;
      ++correction_events;
    }

    previous_keyframe = current;
    correction_at_previous_keyframe = correction;
    if (i % 10 == 0) {
      std::cerr << "\r  [KISS-MH] " << i << "/" << pcd_dirs.size()
                << " accepted=" << accepted_constraints
                << " corrections=" << correction_events;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream note;
  note << "Fast KISS frontend with fixed-lag independent scan constraints; "
       << "accepted=" << accepted_constraints
       << ", rejected=" << rejected_constraints
       << " (registration=" << rejected_registration
       << ", rmse=" << rejected_rmse
       << ", degeneracy=" << rejected_degeneracy
       << ", motion=" << rejected_motion
       << ", consensus_events=" << rejected_consensus << ")"
       << ", correction_events=" << correction_events << ".";
  note << " deskewed_frames=" << deskewed_frames
       << ", deskew_timestamp_fallbacks="
       << deskew_timestamp_fallbacks
       << ", motion_guard_rejections="
       << frontend.motionGuardRejections() << ".";
  if (observed_rmse_count > 0) {
    note << " Matcher RMSE min/mean/max="
         << observed_rmse_min << "/"
         << (observed_rmse_sum / observed_rmse_count) << "/"
         << observed_rmse_max << ".";
  }
  res.note = note.str();
  return res;
}

MethodResult runGenZICP(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const GenZICPDogfoodingOptions& options) {
  using namespace localization_zoo::genz_icp;
  MethodResult res;
  res.name = "GenZ-ICP";

  GenZICPParams params;
  params.voxel_size = options.voxel_size;
  params.initial_threshold = options.initial_threshold;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  GenZICPPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    const auto result = pipeline.registerFrame(pts_local);
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [GenZ-ICP] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Adaptive point-to-plane / point-to-point hybrid odometry (no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runLFGICP(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const LFGICPDogfoodingOptions& options) {
  using namespace localization_zoo::lf_gicp;
  MethodResult res;
  res.name = "LF-GICP";
  LFGICPParams params;
  params.enable_mitigation = options.enable_mitigation;
  params.covariance_regularization = options.covariance_regularization;
  params.field_regularization = options.field_regularization;
  LFGICPOdometry odom(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  std::vector<double> f0s, lambdas;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    // Full-resolution scan; LF-GICP applies its own 0.3 m source voxel and
    // 1-80 m range filter (paper Table SI).
    auto pts_local = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0);
    if (pts_local.empty()) continue;
    const auto result = odom.registerFrame(pts_local);
    if (result.field.sampled_voxels > 0) {
      f0s.push_back(result.field.f0);
      lambdas.push_back(result.field.lambda0);
    }
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [LF-GICP] " << i << "/" << pcd_dirs.size()
                << " voxels=" << odom.mapSize()
                << " degenerate=" << odom.degenerateFrames();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  auto median_of = [](std::vector<double> v) {
    if (v.empty()) return 0.0;
    std::nth_element(v.begin(), v.begin() + v.size() / 2, v.end());
    return v[v.size() / 2];
  };
  std::ostringstream note;
  note << "Voxel-normal localizability field gate + soft Fisher weighting on "
          "GICP scan-to-map (no GT seed; anchor matches first GT pose). mitigation="
       << (options.enable_mitigation ? "on" : "off")
       << " beta=" << options.covariance_regularization
       << " field_beta=" << options.field_regularization
       << " degenerate_frames=" << odom.degenerateFrames() << "/" << odom.frames()
       << " median_f0=" << median_of(f0s) << " median_lambda0=" << median_of(lambdas);
  res.note = note.str();
  return res;
}

// Applies a --l-lo-set key=value override; returns false for an unknown key.
bool setLLOParam(localization_zoo::l_lo::LLOParams& p, const std::string& kv) {
  const auto eq = kv.find('=');
  if (eq == std::string::npos) return false;
  const std::string key = kv.substr(0, eq);
  const double v = std::stod(kv.substr(eq + 1));
  std::map<std::string, double*> doubles = {
      {"min_range", &p.min_range},
      {"max_range", &p.max_range},
      {"voxel_size", &p.voxel_size},
      {"ground_sector_deg", &p.ground_sector_deg},
      {"ground_bin_m", &p.ground_bin_m},
      {"ground_max_slope", &p.ground_max_slope},
      {"ground_tolerance", &p.ground_tolerance},
      {"sensor_height", &p.sensor_height},
      {"cluster_cell", &p.cluster_cell},
      {"sor_std_mul", &p.sor_std_mul},
      {"similarity_weight_shape", &p.similarity_weight_shape},
      {"similarity_weight_size", &p.similarity_weight_size},
      {"step_coeff_translation", &p.step_coeff_translation},
      {"step_coeff_rotation", &p.step_coeff_rotation},
      {"termination", &p.termination},
      {"pitch_ground_min_range", &p.pitch_ground_min_range},
      {"pitch_ground_max_range", &p.pitch_ground_max_range},
      {"patch_half_length", &p.patch_half_length},
      {"patch_half_width", &p.patch_half_width},
      {"patch_blind_radius", &p.patch_blind_radius},
      {"vertical_angle_correction_deg", &p.vertical_angle_correction_deg}};
  std::map<std::string, int*> ints = {
      {"min_cluster_points", &p.min_cluster_points},
      {"max_cluster_points", &p.max_cluster_points},
      {"sor_k", &p.sor_k},
      {"max_rounds", &p.max_rounds},
      {"min_matches", &p.min_matches},
      {"pitch_mode", &p.pitch_mode}};
  if (auto it = doubles.find(key); it != doubles.end()) {
    *it->second = v;
    return true;
  }
  if (auto it = ints.find(key); it != ints.end()) {
    *it->second = static_cast<int>(v);
    return true;
  }
  return false;
}

MethodResult runLLO(const std::vector<std::string>& pcd_dirs,
                    const std::vector<Eigen::Matrix4d>& gt,
                    const localization_zoo::l_lo::LLOParams& params) {
  using namespace localization_zoo::l_lo;
  MethodResult res;
  res.name = "L-LO";
  LLOOdometry odom(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  long matches = 0, frames = 0, weak = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0);
    if (pts_local.empty()) continue;
    const auto result = odom.registerFrame(pts_local);
    if (i > 0) {
      matches += result.matches;
      ++frames;
      if (result.matches < 3) ++weak;
    }
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [L-LO] " << i << "/" << pcd_dirs.size()
                << " clusters=" << result.clusters << " matches=" << result.matches;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream note;
  note << "Landmark convex-hull overlap odometry, frame-to-frame (no GT seed; "
          "anchor matches first GT pose). mean_matches="
       << (frames ? static_cast<double>(matches) / frames : 0.0)
       << " frames_below_3_matches=" << weak << "/" << frames;
  res.note = note.str();
  return res;
}

MethodResult runAdaptiveICP(const std::vector<std::string>& pcd_dirs,
                            const std::vector<Eigen::Matrix4d>& gt,
                            const AdaptiveICPDogfoodingOptions& options) {
  using namespace localization_zoo::adaptive_icp;
  MethodResult res;
  res.name = "Adaptive-ICP";

  AdaptiveICPParams params;
  params.voxel_size = options.voxel_size;
  params.initial_threshold = options.initial_threshold;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.coarse_max_iterations = options.coarse_max_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.density_percentile = options.density_percentile;
  params.reliable_translation_tau = options.reliable_translation_tau;
  params.motion_decay = options.motion_decay;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  AdaptiveICPPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  int coarse_accepted = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    const auto result = pipeline.registerFrame(pts_local);
    if (result.used_coarse_pose) ++coarse_accepted;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [Adaptive-ICP] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Reliable-initial-pose adaptive ICP: density-filtered coarse pose vs "
      "constant-velocity prediction, robust point-to-plane with sigma_th gating "
      "(no GT seed; anchor matches first GT pose). coarse_accepted=" +
      std::to_string(coarse_accepted);
  return res;
}

MethodResult runRKOLIO(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const std::vector<double>& frame_timestamps,
                       const std::vector<ImuSampleCsv>& imu_samples,
                       const RKOLIODogfoodingOptions& options) {
  using namespace localization_zoo::rko_lio;
  MethodResult res;
  res.name = "RKO-LIO";

  RKOLIOParams params;
  params.voxel_size = options.voxel_size;
  params.initial_threshold = options.initial_threshold;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  params.gyro_bias_gain = options.gyro_bias_gain;
  RKOLIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.used_imu) ++imu_frames;
    res.poses.push_back(result.pose);

    if (i % 10 == 0) {
      std::cerr << "\r  [RKO-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      imu_frames > 0
          ? "Scan-to-map odometry with IMU rotation prior (GT-seeded init; "
            "IMU gyro preintegration used as ICP rotation guess)."
          : "Scan-to-map odometry, constant-velocity fallback (no imu.csv; "
            "GT-seeded init).";
  return res;
}

MethodResult runFRLIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const FRLIODogfoodingOptions& options) {
  using namespace localization_zoo::fr_lio;
  MethodResult res;
  res.name = "FR-LIO";

  if (imu_samples.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note =
        "imu.csv not found. FR-LIO requires synchronized IMU for sub-frame "
        "splitting and inertial priors.";
    return res;
  }

  FRLIOParams params;
  params.source_voxel_size = options.source_voxel_size;
  params.voxel_size = options.voxel_size;
  params.grid_size = options.grid_size;
  params.lidar_range = options.lidar_range;
  params.map_lambda = options.map_lambda;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_subframes = options.max_subframes;
  params.esks_gain = options.esks_gain;
  params.min_valid_matches = options.min_valid_matches;
  FRLIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  int subframe_total = 0;
  int smoothed_total = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.used_imu) ++imu_frames;
    subframe_total += result.subframes;
    smoothed_total += result.smoothed_subframes;
    res.poses.push_back(result.pose);

    if (i % 10 == 0) {
      std::cerr << "\r  [FR-LIO] " << i << "/" << pcd_dirs.size()
                << " grids=" << pipeline.mapGrids()
                << " sub=" << result.subframes;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream oss;
  oss << "RC-Vox scan-to-map LIO with adaptive sub-frames + simplified ESKS "
         "(IMU required).";
  if (imu_frames > 0) {
    oss << " IMU prior frames=" << imu_frames;
    if (subframe_total > 0) {
      oss << " avg_subframes="
          << (static_cast<double>(subframe_total) /
              static_cast<double>(pcd_dirs.size()));
    }
    if (smoothed_total > 0) {
      oss << " smoothed_subframes=" << smoothed_total;
    }
  }
  res.note = oss.str();
  return res;
}

MethodResult runPGLIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const PGLIODogfoodingOptions& options) {
  using namespace localization_zoo::pg_lio;
  MethodResult res;
  res.name = "PG-LIO";

  if (imu_samples.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note =
        "imu.csv not found. PG-LIO requires synchronized IMU for inertial "
        "priors and degeneracy regularization.";
    return res;
  }

  auto probe = loadPCDXYZI(pcd_dirs.front() + "/cloud.pcd", options.source_voxel_size);
  if (probe.empty()) {
    res.skipped = true;
    res.status = "skipped";
    res.note =
        "cloud.pcd lacks PointXYZI intensity. PG-LIO requires per-point "
        "intensity for photometric NCC factors.";
    return res;
  }

  PGLIOParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.range_image_width = options.range_image_width;
  params.range_image_height = options.range_image_height;
  params.max_patches = options.max_patches;
  params.photometric_weight = options.photometric_weight;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  PGLIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  long photo_patches = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size);
    if (pts.empty()) continue;
    pts = limitLoadedXYZI(pts, options.max_source_points);
    if (pts.empty()) continue;

    std::vector<IntensityPoint> frame;
    frame.reserve(pts.size());
    for (const auto& p : pts) frame.push_back({p.point, p.intensity});

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.registerFrame(frame, imu_batch);
    if (result.used_imu) ++imu_frames;
    photo_patches += result.photometric_patches;
    res.poses.push_back(result.pose);

    if (i % 10 == 0) {
      std::cerr << "\r  [PG-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize()
                << " patches=" << pipeline.patchCount();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream oss;
  oss << "Photometric-geometric LIO with NCC range-image patches (IMU required).";
  if (imu_frames > 0) oss << " IMU frames=" << imu_frames;
  if (photo_patches > 0) {
    oss << " photometric_patch_frames=" << photo_patches;
  }
  res.note = oss.str();
  return res;
}

MethodResult runD2LIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const D2LIODogfoodingOptions& options) {
  using namespace localization_zoo::d2lio;
  MethodResult res;
  res.name = "D2-LIO";

  D2LIOParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.base_threshold = options.base_threshold;
  params.max_threshold = options.max_threshold;
  params.cauchy_scale = options.cauchy_scale;
  params.degeneracy_ratio = options.degeneracy_ratio;
  params.imu_prior_weight = options.imu_prior_weight;
  params.gyro_bias_gain = options.gyro_bias_gain;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  D2LIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  long deg_rot_total = 0;
  long deg_trans_total = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.used_imu) ++imu_frames;
    deg_rot_total += result.degenerate_rot_dirs;
    deg_trans_total += result.degenerate_trans_dirs;
    res.poses.push_back(result.pose);

    if (i % 10 == 0) {
      std::cerr << "\r  [D2-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      (imu_frames > 0
           ? "Directional-degeneracy LiDAR-IMU scan-to-submap (first-pose anchored; "
             "adaptive per-point outlier gate + IMU-prior degeneracy "
             "regularization)."
           : "Scan-to-submap, constant-velocity fallback (no imu.csv; "
             "first-pose anchored; degeneracy prior diagnostics-only).") +
      std::string(" deg_dirs/frame rot=") +
      std::to_string(deg_rot_total) + " trans=" +
      std::to_string(deg_trans_total);
  return res;
}

MethodResult runCTVoxelMap(const std::vector<std::string>& pcd_dirs,
                           const std::vector<Eigen::Matrix4d>& gt,
                           const CTVoxelMapDogfoodingOptions& options) {
  using namespace localization_zoo::ct_voxelmap;
  MethodResult res;
  res.name = "CT-VoxelMap";

  CTVoxelMapParams params;
  params.voxel_size = options.voxel_size;
  params.voxel_min_points = options.voxel_min_points;
  params.planarity_ratio = options.planarity_ratio;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.sigma_depth = options.sigma_depth;
  params.sigma_bearing = options.sigma_bearing;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  CTVoxelMapPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double planar_ratio_sum = 0.0;
  int planar_ratio_n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    const auto result = pipeline.registerFrame(pts_local);
    planar_ratio_sum += result.planar_ratio;
    ++planar_ratio_n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [CT-VoxelMap] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double mean_planar =
      planar_ratio_n > 0 ? planar_ratio_sum / planar_ratio_n : 0.0;
  res.note =
      "Probabilistic adaptive voxel map: uncertainty-weighted hybrid "
      "point-to-plane / point-to-distribution (no GT seed; anchor matches first "
      "GT pose). mean_planar_ratio=" +
      std::to_string(mean_planar);
  return res;
}

MethodResult runRVoxelMap(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const RVoxelMapDogfoodingOptions& options) {
  using namespace localization_zoo::r_voxelmap;
  MethodResult res;
  res.name = "R-VoxelMap";

  RVoxelMapParams params;
  params.voxel_size = options.voxel_size;
  params.voxel_min_points = options.voxel_min_points;
  params.planarity_ratio = options.planarity_ratio;
  params.inlier_dist = options.inlier_dist;
  params.max_depth = options.max_depth;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_plane_weight = options.max_plane_weight;
  params.icp_damping = options.icp_damping;
  params.huber_residual = options.huber_residual;
  params.max_iteration_translation = options.max_iteration_translation;
  params.max_iteration_rotation = options.max_iteration_rotation;
  params.min_map_matched_ratio = options.min_map_matched_ratio;
  params.max_registration_translation = options.max_registration_translation;
  params.max_registration_rotation = options.max_registration_rotation;
  params.max_map_fallback_translation_delta =
      options.max_map_fallback_translation_delta;
  params.max_map_fallback_rotation_delta =
      options.max_map_fallback_rotation_delta;
  params.enable_scan_to_scan_fallback =
      options.enable_scan_to_scan_fallback;
  params.fallback_max_correspondence_dist =
      options.fallback_max_correspondence_dist;
  params.min_fallback_matched_ratio = options.min_fallback_matched_ratio;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  RVoxelMapPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double matched_sum = 0.0;
  int matched_n = 0;
  double fallback_sum = 0.0;
  int fallback_count = 0;
  int fallback_disagreement_count = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    matched_sum += result.matched_ratio;
    ++matched_n;
    if (result.used_fallback) {
      fallback_sum += result.fallback_matched_ratio;
      ++fallback_count;
      if (result.fallback_disagreement) ++fallback_disagreement_count;
    }
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [R-VoxelMap] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double mean_matched = matched_n > 0 ? matched_sum / matched_n : 0.0;
  const double fallback_rate =
      matched_n > 0 ? 100.0 * static_cast<double>(fallback_count) / matched_n
                    : 0.0;
  const double mean_fallback =
      fallback_count > 0 ? fallback_sum / fallback_count : 0.0;
  res.note =
      "Recursive plane-fitting voxel map (outlier detect-and-reuse octree; no "
      "GT seed; anchor matches first GT pose" +
      std::string(options.enable_scan_to_scan_fallback
                      ? "; scan-to-scan fallback on low map correspondence"
                      : "") +
      std::string(options.max_map_fallback_translation_delta > 0.0 ||
                          options.max_map_fallback_rotation_delta > 0.0
                      ? " and map/fallback disagreement"
                      : "") +
      "). mean_matched_ratio=" + std::to_string(mean_matched) +
      " fallback_rate_pct=" + std::to_string(fallback_rate) +
      " fallback_disagreement_count=" +
      std::to_string(fallback_disagreement_count) +
      " mean_fallback_ratio=" + std::to_string(mean_fallback);
  return res;
}

MethodResult runDammLoam(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const DammLoamDogfoodingOptions& options) {
  using namespace localization_zoo::damm_loam;
  MethodResult res;
  res.name = "DAMM-LOAM";

  DammLoamParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_icp_iterations = options.max_icp_iterations;
  params.initial_threshold = options.initial_threshold;
  params.vertical_cos = options.vertical_cos;
  params.horizontal_cos = options.horizontal_cos;
  params.ground_z = options.ground_z;
  params.edge_weight = options.edge_weight;
  params.degeneracy_ratio = options.degeneracy_ratio;
  params.degeneracy_boost = options.degeneracy_boost;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  DammLoamPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long ground_sum = 0, wall_sum = 0, edge_sum = 0;
  int degenerate_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    ground_sum += result.counts.ground;
    wall_sum += result.counts.wall;
    edge_sum += result.counts.edge;
    if (result.degenerate) ++degenerate_frames;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [DAMM-LOAM] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Degeneracy-aware multi-metric LiDAR odometry: range-image normal-class "
      "weighting (ground/wall/edge) + Hessian-eigen degeneracy boost (no GT "
      "seed; anchor matches first GT pose). ground=" +
      std::to_string(ground_sum) + " wall=" + std::to_string(wall_sum) +
      " edge=" + std::to_string(edge_sum) +
      " degenerate_frames=" + std::to_string(degenerate_frames);
  return res;
}

MethodResult runLodestar(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const LodestarDogfoodingOptions& options) {
  using namespace localization_zoo::lodestar;
  MethodResult res;
  res.name = "LODESTAR";

  LodestarParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_icp_iterations = options.max_icp_iterations;
  params.initial_threshold = options.initial_threshold;
  params.t_chi = options.t_chi;
  params.anchor_strength = options.anchor_strength;
  params.active_window = options.active_window;
  params.enable_data_exploitation = options.enable_data_exploitation;
  params.t_loc = options.t_loc;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  LodestarPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  int degenerate_frames = 0;
  long pruned_sum = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    if (result.degenerate) ++degenerate_frames;
    pruned_sum += result.num_pruned;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [LODESTAR] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Degeneracy-aware LiDAR odometry: condition-number Schmidt-Kalman "
      "anchoring of degenerate directions to constant-velocity prediction "
      "(DA-ASKF) + localizability pruning (DA-DE); pure-LiDAR scope, no GT "
      "seed (anchor matches first GT pose). degenerate_frames=" +
      std::to_string(degenerate_frames) +
      " pruned=" + std::to_string(pruned_sum);
  return res;
}

MethodResult runTerrainRbf(const std::vector<std::string>& pcd_dirs,
                           const std::vector<Eigen::Matrix4d>& gt,
                           const TerrainRbfDogfoodingOptions& options) {
  using namespace localization_zoo::terrain_rbf_lio;
  MethodResult res;
  res.name = "Terrain-RBF-LIO";

  TerrainRbfParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_icp_iterations = options.max_icp_iterations;
  params.initial_threshold = options.initial_threshold;
  params.terrain_cell_size = options.terrain_cell_size;
  params.terrain_sigma = options.terrain_sigma;
  params.terrain_ground_band = options.terrain_ground_band;
  params.terrain_weight = options.terrain_weight;
  params.terrain_warmup = options.terrain_warmup;
  params.sensor_height_alpha = options.sensor_height_alpha;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  TerrainRbfPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  int terrain_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    if (result.terrain_active) ++terrain_frames;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Terrain-RBF] " << i << "/" << pcd_dirs.size()
                << " terrain_cells=" << pipeline.terrainSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Terrain-aware RBF-LIO: Gaussian RBF terrain height field (RLS) used as a "
      "vehicle-height-above-terrain soft prior to suppress z-drift (legged-wheel "
      "contact constraint reinterpreted for the car platform); constant-velocity, "
      "no GT seed. terrain_active_frames=" +
      std::to_string(terrain_frames);
  return res;
}

MethodResult runLidarIba(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const LidarIbaDogfoodingOptions& options) {
  using namespace localization_zoo::lidar_iba;
  MethodResult res;
  res.name = "LiDAR-IBA";

  LidarIbaParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_icp_iterations = options.max_icp_iterations;
  params.initial_threshold = options.initial_threshold;
  params.enable_ba = options.enable_ba;
  params.keyframe_interval = options.keyframe_interval;
  params.window_size = options.window_size;
  params.ba_iterations = options.ba_iterations;
  params.plane_voxel = options.plane_voxel;
  params.max_landmarks = options.max_landmarks;
  params.lidar_sigma = options.lidar_sigma;
  params.pose_prior_weight = options.pose_prior_weight;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  LidarIbaPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  int ba_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    if (result.ba_ran) ++ba_frames;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [LiDAR-IBA] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Consistency-improved LiDAR bundle adjustment: stereographic plane-normal "
      "parameterization + sliding-window plane BA with FEJ (oldest keyframe "
      "gauge-fixed) and a front-end odometry prior; constant-velocity, no GT "
      "seed. ba_frames=" +
      std::to_string(ba_frames);
  return res;
}

MethodResult runDaliSlam(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const DaliSlamDogfoodingOptions& options) {
  using namespace localization_zoo::dali_slam;
  MethodResult res;
  res.name = "DALI-SLAM";

  DaliSlamParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_icp_iterations = options.max_icp_iterations;
  params.initial_threshold = options.initial_threshold;
  params.enable_deskew = options.enable_deskew;
  params.spline_quadratic = options.spline_quadratic;
  params.degeneracy_ratio = options.degeneracy_ratio;
  params.enable_degeneracy = options.enable_degeneracy;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  DaliSlamPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  int degenerate_frames = 0;
  int deskew_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    if (result.degenerate) ++degenerate_frames;
    if (result.deskew_applied) ++deskew_frames;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [DALI-SLAM] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "DALI-SLAM: dual-spline motion distortion correction (constant-velocity "
      "spline deskew, azimuth per-point time) + degeneracy-aware solution "
      "remapping; pure-LiDAR, no GT seed. degenerate_frames=" +
      std::to_string(degenerate_frames) +
      " deskew_frames=" + std::to_string(deskew_frames);
  return res;
}

MethodResult runIntensityFlow(const std::vector<std::string>& pcd_dirs,
                              const std::vector<Eigen::Matrix4d>& gt,
                              const IntensityFlowDogfoodingOptions& options) {
  using namespace localization_zoo::intensity_flow;
  MethodResult res;
  res.name = "Intensity-Flow";

  IntensityFlowParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_icp_iterations = options.max_icp_iterations;
  params.initial_threshold = options.initial_threshold;
  params.enable_gradient_flow = options.enable_gradient_flow;
  params.gf_radius = options.gf_radius;
  params.gf_num_bins = options.gf_num_bins;
  params.gf_keep_ratio = options.gf_keep_ratio;
  params.enable_intensity = options.enable_intensity;
  params.intensity_sigma = options.intensity_sigma;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  IntensityFlowPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long sampled_sum = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto xyzi = limitLoadedXYZI(
        loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size),
        options.max_source_points);
    if (xyzi.empty()) continue;
    std::vector<PointI> pts_local(xyzi.size());
    for (size_t k = 0; k < xyzi.size(); k++) {
      pts_local[k].p = xyzi[k].point;
      pts_local[k].intensity = xyzi[k].intensity;
    }
    const auto result = pipeline.registerFrame(pts_local);
    sampled_sum += result.num_sampled;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Intensity-Flow] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Intensity-gradient-flow odometry: RMS geometric gradient-flow sampling + "
      "intensity-geometry fused point-to-plane matching (intensity-consistency "
      "weight); pure-LiDAR (uses KITTI PointXYZI), no GT seed. sampled_points=" +
      std::to_string(sampled_sum);
  return res;
}

MethodResult runSvnIcp(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const SvnIcpDogfoodingOptions& options) {
  using namespace localization_zoo::svn_icp;
  MethodResult res;
  res.name = "SVN-ICP";

  SvnIcpParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.initial_threshold = options.initial_threshold;
  params.num_particles = options.num_particles;
  params.svn_iterations = options.svn_iterations;
  params.step_size = options.step_size;
  params.lidar_sigma = options.lidar_sigma;
  params.prior_precision = options.prior_precision;
  params.init_spread_rot = options.init_spread_rot;
  params.init_spread_trans = options.init_spread_trans;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  SvnIcpPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double trans_std_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    trans_std_sum += result.trans_std;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [SVN-ICP] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.4f",
                n > 0 ? trans_std_sum / static_cast<double>(n) : 0.0);
  res.note =
      "SVN-ICP: Stein Variational Newton on SE(3) over M particles for "
      "point-to-plane LiDAR odometry with built-in pose uncertainty (particle "
      "covariance); constant-velocity prior, no GT seed. mean_trans_std_m=" +
      std::string(buf);
  return res;
}

MethodResult runPcrDat(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const PcrDatDogfoodingOptions& options) {
  using namespace localization_zoo::pcr_dat;
  MethodResult res;
  res.name = "PCR-DAT";

  PcrDatParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.initial_threshold = options.initial_threshold;
  params.max_iterations = options.max_iterations;
  params.distribution_min_points = options.distribution_min_points;
  params.distribution_planarity = options.distribution_planarity;
  params.distance_planarity = options.distance_planarity;
  params.distance_sigma = options.distance_sigma;
  params.distribution_regularization = options.distribution_regularization;
  params.distance_weight = options.distance_weight;
  params.distribution_weight = options.distribution_weight;
  params.robust_scale = options.robust_scale;
  params.prior_precision = options.prior_precision;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  PcrDatPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long n_distrib_sum = 0, n_dist_sum = 0, n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    n_distrib_sum += result.num_distribution;
    n_dist_sum += result.num_distance;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [PCR-DAT] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.0f/%.0f",
                n > 0 ? static_cast<double>(n_distrib_sum) / n : 0.0,
                n > 0 ? static_cast<double>(n_dist_sum) / n : 0.0);
  res.note =
      "PCR-DAT: per-point switch between Gauss-distribution (rich) and "
      "point-to-plane distance (sparse) factors fused in one GN system; "
      "constant-velocity prior, no GT seed. mean_distrib/distance_corr=" +
      std::string(buf);
  return res;
}

MethodResult runSmallMighty(const std::vector<std::string>& pcd_dirs,
                            const std::vector<Eigen::Matrix4d>& gt,
                            const SmallMightyDogfoodingOptions& options) {
  using namespace localization_zoo::small_mighty;
  MethodResult res;
  res.name = "Small-but-Mighty";

  SmallMightyParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.initial_threshold = options.initial_threshold;
  params.max_iterations = options.max_iterations;
  params.planar_min = options.planar_min;
  params.edge_min = options.edge_min;
  params.contribution_gain = options.contribution_gain;
  params.contribution_cap = options.contribution_cap;
  params.plane_weight = options.plane_weight;
  params.edge_weight = options.edge_weight;
  params.robust_scale = options.robust_scale;
  params.prior_precision = options.prior_precision;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  SmallMightyPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long n_planar_sum = 0, n_edge_sum = 0, n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    n_planar_sum += result.num_planar;
    n_edge_sum += result.num_edge;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Small-but-Mighty] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.0f/%.0f",
                n > 0 ? static_cast<double>(n_planar_sum) / n : 0.0,
                n > 0 ? static_cast<double>(n_edge_sum) / n : 0.0);
  res.note =
      "Small-but-Mighty: stability-aware feature selection (statistical "
      "smoothness distribution) + contribution-weighted point-to-plane/line "
      "optimization; constant-velocity prior, no GT seed. "
      "mean_planar/edge_corr=" +
      std::string(buf);
  return res;
}

MethodResult runMGclo(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const MGcloDogfoodingOptions& options,
                      bool no_gt_seed = false) {
  using namespace localization_zoo::m_gclo;
  MethodResult res;
  res.name = "M-GCLO";

  MGcloParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.initial_threshold = options.initial_threshold;
  params.max_iterations = options.max_iterations;
  params.ground_normal_threshold = options.ground_normal_threshold;
  params.ground_height_offset = options.ground_height_offset;
  params.ground_weight =
      options.ground_constraints ? options.ground_weight : 0.0;
  params.nonground_weight = options.nonground_weight;
  params.ground_planarity = options.ground_planarity;
  params.distribution_regularization = options.distribution_regularization;
  params.uncertainty_range_ref = options.uncertainty_range_ref;
  params.robust_scale = options.robust_scale;
  params.prior_precision = options.prior_precision;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  MGcloPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long n_ground_sum = 0, n_nonground_sum = 0, n = 0;
  int seeded_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    Eigen::Matrix4d rel_guess;
    const Eigen::Matrix4d* init_guess = nullptr;
    if (!no_gt_seed && i > 0 && i < gt.size()) {
      rel_guess = world_anchor.inverse() * gt[i];
      init_guess = &rel_guess;
      ++seeded_frames;
    }
    const auto result = pipeline.registerFrame(pts_local, init_guess);
    n_ground_sum += result.num_ground;
    n_nonground_sum += result.num_nonground;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [M-GCLO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.0f/%.0f",
                n > 0 ? static_cast<double>(n_ground_sum) / n : 0.0,
                n > 0 ? static_cast<double>(n_nonground_sum) / n : 0.0);
  const std::string ground_mode =
      options.ground_constraints
          ? "multiple-ground point-to-plane constraints (vertical accuracy)"
          : "ground factor disabled (non-ground NDT only; classified ground held out)";
  res.note =
      "M-GCLO: " + ground_mode +
      " + non-ground point-to-distribution (NDT) with per-point range-uncertainty "
      "weighting; " +
      (no_gt_seed
           ? "constant-velocity prior, no GT seed."
           : "GT-seeded scan-to-map initialization with constant-velocity fallback.") +
      " mean_ground/nonground_corr=" + std::string(buf);
  if (!no_gt_seed && seeded_frames > 0) {
    res.note += " gt_seeded_frames=" + std::to_string(seeded_frames) + ".";
  }
  return res;
}

MethodResult runQuadricLo(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const QuadricLoDogfoodingOptions& options) {
  using namespace localization_zoo::quadric_lo;
  MethodResult res;
  res.name = "Quadric-LO";

  QuadricLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.plane_min_neighbors = options.plane_min_neighbors;
  params.initial_threshold = options.initial_threshold;
  params.max_iterations = options.max_iterations;
  params.quadric_min_neighbors = options.quadric_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.allow_plane_fallback = options.allow_plane_fallback;
  params.quadric_weight = options.quadric_weight;
  params.min_grad_norm = options.min_grad_norm;
  params.robust_scale = options.robust_scale;
  params.prior_precision = options.prior_precision;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  QuadricLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long n_quadric_sum = 0, n_plane_sum = 0, n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    n_quadric_sum += result.num_quadric;
    n_plane_sum += result.num_plane;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Quadric-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.0f/%.0f",
                n > 0 ? static_cast<double>(n_quadric_sum) / n : 0.0,
                n > 0 ? static_cast<double>(n_plane_sum) / n : 0.0);
  const double fallback_ratio =
      (n_quadric_sum + n_plane_sum) > 0
          ? static_cast<double>(n_plane_sum) /
                static_cast<double>(n_quadric_sum + n_plane_sum)
          : 0.0;
  char ratio_buf[32];
  std::snprintf(ratio_buf, sizeof(ratio_buf), "%.4f", fallback_ratio);
  const std::string fallback_mode =
      options.allow_plane_fallback ? "plane fallback enabled"
                                   : "plane fallback disabled";
  res.note =
      "Quadric-LO: quadric-surface (implicit q=xAx+bx+c) representation with "
      "point-to-quadric Taubin-distance residuals and " + fallback_mode + "; "
      "constant-velocity prior, no GT seed. mean_quadric/plane_corr=" +
      std::string(buf) + " plane_fallback_ratio=" + std::string(ratio_buf);
  return res;
}

MethodResult runDiloPaper(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const DiloDogfoodingOptions& options) {
  using namespace localization_zoo::dilo;
  MethodResult res;
  res.name = "DiLO";
  DiloPaperParams params;
  params.window = options.paper_window;
  params.update_iterations = options.paper_update_iterations;
  params.keypoints_per_list = options.paper_keypoints_per_list;
  params.use_edges = options.paper_edges;
  if (options.paper_min_planarity >= 0.0) params.min_planarity = options.paper_min_planarity;
  if (options.paper_keypoint_cell >= 0) params.keypoint_cell_px = options.paper_keypoint_cell;
  if (options.paper_fill_slope >= 0.0) params.fill_slope = options.paper_fill_slope;
  if (options.paper_max_fill_gap >= 0) params.max_fill_gap = options.paper_max_fill_gap;
  if (options.paper_degenerate_ratio >= 0.0) params.degenerate_ratio = options.paper_degenerate_ratio;
  if (options.paper_top_elevation_deg < 1e9) params.top_elevation_deg = options.paper_top_elevation_deg;
  if (options.paper_height > 0) params.height = options.paper_height;
  params.edge_detector = options.paper_edge_detector;
  params.edge_subpixel = options.paper_edge_subpixel;
  params.edge_dofs = options.paper_edge_dofs;
  if (options.paper_edge_sum_weight > 0.0) {
    params.edge_sum_normal_equations = true;
    params.edge_weight = options.paper_edge_sum_weight;
  }
  DiloPaperOdometry odometry(params);
  const Eigen::Matrix4d anchor = gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  std::vector<Eigen::Matrix4d> causal;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    const auto points = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0);
    causal.push_back(odometry.process(points));
    if (i % 50 == 0) std::cerr << "\r  [DiLO paper] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::vector<Eigen::Matrix4d> poses;
  if (options.paper_causal_output) {
    poses = causal;
  } else {
    poses = odometry.finalizedPoses();
    for (const auto& p : odometry.windowPoses()) poses.push_back(p);
  }
  for (const auto& p : poses) res.poses.push_back(anchor * p);
  std::ostringstream note;
  note << "DiLO paper odometry (" << params.height << "x" << params.width
       << " sin-elevation range image, top " << params.top_elevation_deg << " deg, vertical fill up to "
       << params.max_fill_gap << " rows, Farid-filter normals, "
       << (params.degenerate_ratio > 0.0 ? "degenerate translation directions below " + std::to_string(params.degenerate_ratio) + " of the largest kept at the prediction (not in the paper), " : std::string())
       << "11 planarity-weighted key-point lists x " << params.keypoints_per_list << ", window of "
       << params.window << " frames, " << params.update_iterations
       << " pairwise-averaging iterations; "
       << (params.use_edges ? "plane and edge key points" : "plane key points only") << "); "
       << (options.paper_causal_output ? "causal poses" : "poses after leaving the window")
       << "; no GT seed.";
  res.note = note.str();
  return res;
}

MethodResult runDilo(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const DiloDogfoodingOptions& options) {
  using namespace localization_zoo::dilo;
  if (options.paper_odometry) return runDiloPaper(pcd_dirs, gt, options);
  MethodResult res;
  res.name = "DiLO";

  DiloParams params;
  params.sri_height = options.sri_height;
  params.sri_width = options.sri_width;
  params.fov_up_deg = options.fov_up_deg;
  params.fov_down_deg = options.fov_down_deg;
  params.lookup_radius = options.lookup_radius;
  params.max_lookup_point_distance = options.max_lookup_point_distance;
  params.max_iterations = options.max_iterations;
  params.initial_threshold = options.initial_threshold;
  params.robust_scale = options.robust_scale;
  params.keyframe_translation = options.keyframe_translation;
  params.keyframe_rotation_deg = options.keyframe_rotation_deg;
  params.source_voxel_size = options.gn_voxel_size;  // GN ソースの間引き (SRI は密な frame から構築)
  DiloPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long n_kf = 0, n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    // SRI を密にするため浅い間引きで読み込む。
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    if (result.keyframe_updated) ++n_kf;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [DiLO] " << i << "/" << pcd_dirs.size()
                << " keyframes=" << n_kf;
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[32];
  std::snprintf(buf, sizeof(buf), "%ld", n_kf);
  char lookup_buf[96];
  std::snprintf(lookup_buf, sizeof(lookup_buf),
                " lookup_radius=%d lookup_max_dist=%.2f",
                options.lookup_radius, options.max_lookup_point_distance);
  res.note =
      "DiLO: direct frame-to-keyframe LiDAR odometry via spherical-range-image "
      "projective data association (no NN search) + point-to-plane GN; "
      "constant-velocity prior, no GT seed." +
      std::string(lookup_buf) + " keyframes=" + std::string(buf);
  return res;
}

MethodResult runNhcLio(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const NhcLioDogfoodingOptions& options) {
  using namespace localization_zoo::nhc_lio;
  MethodResult res;
  res.name = "NHC-LIO";

  NhcLioParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.initial_threshold = options.initial_threshold;
  params.max_iterations = options.max_iterations;
  params.enable_nhc = options.enable_nhc;
  params.nhc_weight = options.nhc_weight;
  params.nhc_yaw_ref = options.nhc_yaw_ref;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  NhcLioPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double nhc_w_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    nhc_w_sum += result.nhc_weight_used;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [NHC-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? nhc_w_sum / static_cast<double>(n) : 0.0);
  res.note =
      "NHC-LIO: scan-to-map point-to-plane + nonholonomic-constraint factor "
      "(body lateral/vertical velocity ~0) with yaw-rate-adaptive weight; "
      "constant-velocity prior, no GT seed. mean_nhc_weight=" +
      std::string(buf);
  return res;
}

MethodResult runStudentTLo(const std::vector<std::string>& pcd_dirs,
                           const std::vector<Eigen::Matrix4d>& gt,
                           const StudentTLoDogfoodingOptions& options) {
  using namespace localization_zoo::student_t_lo;
  MethodResult res;
  res.name = "Student-T-LO";

  StudentTLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.initial_threshold = options.initial_threshold;
  params.max_iterations = options.max_iterations;
  params.enable_student_t = options.enable_student_t;
  params.student_t_dof = options.student_t_dof;
  params.scale_init = options.scale_init;
  params.estimate_scale = options.estimate_scale;
  params.scale_floor = options.scale_floor;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  StudentTLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double scale_sum = 0.0;
  double weight_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    scale_sum += result.scale_used;
    weight_sum += result.mean_weight;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Student-T-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.3f m / %.3f",
                n > 0 ? scale_sum / static_cast<double>(n) : 0.0,
                n > 0 ? weight_sum / static_cast<double>(n) : 0.0);
  res.note =
      "Student-T-LO: scan-to-map point-to-plane with Student's-t robust IRLS "
      "weighting w=(nu+1)/(nu+(r/sigma)^2) and EM-updated scale; "
      "constant-velocity prior, no GT seed. mean_scale/mean_weight=" +
      std::string(buf);
  return res;
}

MethodResult runSpectralLo(const std::vector<std::string>& pcd_dirs,
                           const std::vector<Eigen::Matrix4d>& gt,
                           const SpectralLoDogfoodingOptions& options) {
  using namespace localization_zoo::spectral_lo;
  MethodResult res;
  res.name = "Spectral-LO";

  SpectralLoParams params;
  params.bev_size = options.bev_size;
  params.bev_range = options.bev_range;
  params.max_range = options.max_range;
  params.z_min = options.z_min;
  params.z_max = options.z_max;
  params.logpolar_angles = options.logpolar_angles;
  params.logpolar_radii = options.logpolar_radii;
  params.max_yaw_deg = options.max_yaw_deg;
  params.keyframe_translation = options.keyframe_translation;
  params.translation_refinement_iterations =
      options.translation_refinement_iterations;
  params.max_translation_refinement_m = options.max_translation_refinement_m;
  SpectralLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double peak_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    peak_sum += result.translation_peak;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Spectral-LO] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? peak_sum / static_cast<double>(n) : 0.0);
  res.note =
      "Spectral-LO: frequency-domain BEV odometry; Fourier-Mellin log-polar "
      "phase correlation for yaw + phase-only correlation for translation "
      "(3-DoF, z held); no ICP, no GT seed. bev_size=" +
      std::to_string(options.bev_size) + " bev_range=" +
      std::to_string(options.bev_range) +
      " translation_refinement_iters=" +
      std::to_string(options.translation_refinement_iterations) +
      " mean_translation_peak=" +
      std::string(buf);
  return res;
}

MethodResult runGmmLo(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const GmmLoDogfoodingOptions& options) {
  using namespace localization_zoo::gmm_lo;
  MethodResult res;
  res.name = "GMM-LO";

  GmmLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_iterations = options.max_iterations;
  params.sigma_init = options.sigma_init;
  params.sigma_final = options.sigma_final;
  params.outlier_weight = options.outlier_weight;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  GmmLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double w_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    w_sum += result.mean_weight;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [GMM-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? w_sum / static_cast<double>(n) : 0.0);
  res.note =
      "GMM-LO: scan-to-map GMM/EM soft-assignment registration; Gaussian "
      "responsibilities with uniform-outlier term, soft-centroid point-to-plane, "
      "deterministic annealing of sigma; CV prior, no GT seed. mean_weight=" +
      std::string(buf);
  return res;
}

MethodResult runGncLo(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const GncLoDogfoodingOptions& options) {
  using namespace localization_zoo::gnc_lo;
  MethodResult res;
  res.name = "GNC-LO";

  GncLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_iterations = options.max_iterations;
  params.gnc_truncation = options.gnc_truncation;
  params.gnc_factor = options.gnc_factor;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  GncLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double inlier_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    inlier_sum += result.inlier_ratio;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [GNC-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? inlier_sum / static_cast<double>(n) : 0.0);
  res.note =
      "GNC-LO: scan-to-map point-to-plane with Graduated Non-Convexity (TLS) "
      "robust weighting; mu continuation from convex to non-convex, hard "
      "outlier rejection; CV prior, no GT seed. mean_inlier_ratio=" +
      std::string(buf);
  return res;
}

MethodResult runMccLo(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const MccLoDogfoodingOptions& options) {
  using namespace localization_zoo::mcc_lo;
  MethodResult res;
  res.name = "MCC-LO";

  MccLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_iterations = options.max_iterations;
  params.mcc_sigma = options.mcc_sigma;
  params.mcc_adaptive_sigma = options.mcc_adaptive_sigma;
  params.mcc_sigma_floor = options.mcc_sigma_floor;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  MccLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double weight_sum = 0.0;
  double sigma_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    weight_sum += result.mean_weight;
    sigma_sum += result.sigma_used;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [MCC-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.3f sigma=%.3f",
                n > 0 ? weight_sum / static_cast<double>(n) : 0.0,
                n > 0 ? sigma_sum / static_cast<double>(n) : 0.0);
  res.note =
      "MCC-LO: scan-to-map point-to-plane with Maximum Correntropy Criterion "
      "(Welsch/Gaussian kernel) robust weighting and Silverman adaptive kernel "
      "bandwidth; CV prior, no GT seed. mean_weight=" +
      std::string(buf);
  return res;
}

MethodResult runImlsPaperOdometry(const std::vector<std::string>& pcd_dirs,
                                  const std::vector<Eigen::Matrix4d>& gt,
                                  const ImlsSlamDogfoodingOptions& options) {
  using namespace localization_zoo::imls_slam;
  MethodResult res;
  res.name = "IMLS-SLAM";
  ImlsPaperParams params;
  params.accelerated = options.paper_accelerated;
  params.window_scans = options.paper_window_scans;
  params.samples_per_list = options.paper_samples_per_list;
  params.iterations = options.paper_iterations;
  params.h = options.paper_h;
  params.r = options.paper_r;
  params.scan_normal_radius = options.paper_scan_normal_radius;
  params.coarse_frames = options.paper_coarse_frames;
  params.coarse_r = options.paper_coarse_r;
  params.coarse_h = options.paper_coarse_h;
  ImlsPaperOdometry odometry(params);
  const Eigen::Matrix4d world_anchor = gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  double samples = 0.0;
  size_t registered = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    const auto points = loadPCD(pcd_dirs[i] + "/cloud.pcd", 0.0);
    const auto r = odometry.process(points);
    res.poses.push_back(world_anchor * r.pose);
    if (i > 0) {
      samples += r.samples;
      ++registered;
    }
    if (i % 20 == 0)
      std::cerr << "\r  [IMLS paper] " << i << "/" << pcd_dirs.size() << " model=" << r.model_points;
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream note;
  note << std::fixed << std::setprecision(2)
       << "IMLS-SLAM paper odometry (raw scans, window of " << params.window_scans
       << " raw scans, h=" << params.h << " r=" << params.r << ", nine lists x "
       << params.samples_per_list << ", " << params.iterations
       << " iterations); no GT seed. mean samples " << std::setprecision(1) << samples / std::max<size_t>(1, registered);
  if (params.coarse_frames > 0)
    note << "; coarse start on the first " << params.coarse_frames << " registrations (r=" << params.coarse_r
         << " h=" << params.coarse_h << ", not in the paper)";
  if (params.accelerated) note << "; repository acceleration enabled (opt-in, not in the paper)";
  res.note = note.str();
  return res;
}

MethodResult runImlsSlam(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const ImlsSlamDogfoodingOptions& options) {
  using namespace localization_zoo::imls_slam;
  if (options.paper_odometry) return runImlsPaperOdometry(pcd_dirs, gt, options);
  MethodResult res;
  res.name = "IMLS-SLAM";

  ImlsSlamParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.normal_radius = options.normal_radius;
  params.imls_h = options.imls_h;
  params.imls_support_radius = options.imls_support_radius;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_iterations = options.max_iterations;
  params.samples_per_axis = options.samples_per_axis;
  params.use_observability_sampling = options.use_observability_sampling;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  ImlsSlamPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double residual_sum = 0.0;
  double sample_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    residual_sum += result.mean_abs_residual;
    sample_sum += result.num_samples;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [IMLS-SLAM] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[96];
  std::snprintf(buf, sizeof(buf), "%.3f samples=%.0f",
                n > 0 ? residual_sum / static_cast<double>(n) : 0.0,
                n > 0 ? sample_sum / static_cast<double>(n) : 0.0);
  res.note =
      "IMLS-SLAM: scan-to-model matching on an implicit moving least squares "
      "surface (point-to-implicit-surface) with observability-based sampling; "
      "CV prior, no GT seed. mean|residual|=" +
      std::string(buf);
  return res;
}

MethodResult runMeshLoam(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const MeshLoamDogfoodingOptions& options) {
  using namespace localization_zoo::mesh_loam;
  MethodResult res;
  res.name = "Mesh-LOAM";

  MeshLoamParams params;
  params.voxel_size = options.voxel_size;
  params.imls_h = options.imls_h;
  params.lambda_n = options.lambda_n;
  params.curvature_threshold = options.curvature_threshold;
  params.cos_gate = options.cos_gate;
  params.search_radius = options.search_radius;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_iterations = options.max_iterations;
  params.mesh_update_interval = options.mesh_update_interval;
  params.local_map_radius = options.local_map_radius;
  params.nearest_facet = options.nearest_facet;
  params.keep_mesh = options.keep_mesh;
  params.normal_neighbors = options.normal_neighbors;
  params.normal_search_radius = options.normal_search_radius;
  params.max_range = options.max_range;
  params.marching_cubes = options.marching_cubes;
  params.mesh_dirty_cells = options.dirty_cells;
  params.mesh_freeze_radius = options.freeze_radius;
  MeshLoamPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double residual_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    residual_sum += result.mean_abs_residual;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [Mesh-LOAM] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize()
                << " facets=" << pipeline.meshSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? residual_sum / static_cast<double>(n) : 0.0);
  res.note =
      "Mesh-LOAM: incremental voxel-hash IMLS-SDF map with block-wise "
      "zero-surface extraction and point-to-mesh GN odometry (normal cosine "
      "gate); CV prior, no GT seed. " +
      std::string(options.paper_odometry ? "Paper path (0.1 m input, nearest facet). " : "") +
      std::string(options.nearest_facet ? "nearest-facet association; " : "") +
      std::string(options.keep_mesh ? "global mesh kept; " : "") +
      std::string(options.marching_cubes ? "marching cubes; " : "") +
      "mean|residual|=" + std::string(buf);
  return res;
}

MethodResult runElo(const std::vector<std::string>& pcd_dirs,
                    const std::vector<Eigen::Matrix4d>& gt,
                    const EloDogfoodingOptions& options) {
  using namespace localization_zoo::elo;
  MethodResult res;
  res.name = "ELO";

  EloParams params;
  params.sri_width = options.sri_width;
  params.sri_height = options.sri_height;
  params.bev_resolution = options.bev_resolution;
  params.sensor_height = options.sensor_height;
  params.max_iterations = options.max_iterations;
  params.max_sri_correspondence_dist = options.max_sri_correspondence_dist;
  params.max_ground_correspondence_dist = options.max_ground_correspondence_dist;
  params.ground_weight = options.ground_weight;
  params.non_ground_weight = options.non_ground_weight;
  params.max_alignment_points = options.max_alignment_points;
  params.model_window_frames = options.model_window_frames;
  params.fusion_mode = options.fusion_mode;
  params.ground_requires_both_sides = options.ground_requires_both_sides;
  params.normal_patch_full_size = options.normal_patch_full_size;
  params.bev_keep_closest = options.bev_keep_closest;
  params.sri_fuse_same_surface = options.sri_fuse_same_surface;
  if (options.sri_fov_up_deg < 1e9) params.fov_up_deg = options.sri_fov_up_deg;
  if (options.sri_fov_down_deg < 1e9) params.fov_down_deg = options.sri_fov_down_deg;
  params.ground_constrains_forward = options.ground_constrains_forward;
  if (options.curvature_threshold >= 0.0) params.curvature_threshold = options.curvature_threshold;
  params.robust_scale = options.robust_scale;
  params.sri_search_radius_px = options.sri_search_radius_px;
  EloPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double residual_sum = 0.0;
  double ground_corr_sum = 0.0;
  double nonground_corr_sum = 0.0;
  double fusion_weight_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    fusion_weight_sum += result.fusion_weight;
    residual_sum += result.mean_abs_residual;
    ground_corr_sum += result.num_ground_correspondences;
    nonground_corr_sum += result.num_non_ground_correspondences;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [ELO] " << i << "/" << pcd_dirs.size()
                << " sri=" << pipeline.nonGroundMapSize()
                << " bev=" << pipeline.groundMapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[160];
  std::snprintf(buf, sizeof(buf), "%.3f g=%.0f ng=%.0f w=%.2f",
                n > 0 ? residual_sum / static_cast<double>(n) : 0.0,
                n > 0 ? ground_corr_sum / static_cast<double>(n) : 0.0,
                n > 0 ? nonground_corr_sum / static_cast<double>(n) : 0.0,
                n > 0 ? fusion_weight_sum / static_cast<double>(n) : 0.0);
  res.note =
      std::string(options.paper_profile ? "[paper profile] " : "") +
      "ELO: frame-to-model projective odometry with non-ground spherical "
      "range-image map, ground BEV map, range-adaptive PCA normals, and "
      "SRI/BEV model fusion; CV prior, no GT seed. mean|residual|=" +
      std::string(buf);
  return res;
}

MethodResult runTcLvgf(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const TcLvgfDogfoodingOptions& options) {
  using namespace localization_zoo::tc_lvgf;
  MethodResult res;
  res.name = "TC-LVGF";

  TcLvgfParams params;
  params.voxel_size = options.voxel_size;
  params.registration_voxel_size = options.registration_voxel_size;
  params.max_registration_points = options.max_registration_points;
  params.image_width = options.image_width;
  params.image_height = options.image_height;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.min_visual_lines = options.min_visual_lines;
  params.max_lidar_lines = options.max_lidar_lines;
  params.max_visual_lines = options.max_visual_lines;
  params.line_weight = options.line_weight;
  params.direction_weight = options.direction_weight;
  params.fusion_pixel_gate = options.fusion_pixel_gate;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  TcLvgfPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  long long visual_lines_total = 0;
  long long fused_lines_total = 0;
  long long plane_corr_total = 0;
  long long line_corr_total = 0;
  long fallback_frames = 0;
  double residual_sum = 0.0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); ++i) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    visual_lines_total += result.num_visual_lines;
    fused_lines_total += result.num_fused_lines;
    plane_corr_total += result.num_plane_correspondences;
    line_corr_total += result.num_line_correspondences;
    residual_sum += result.mean_abs_residual;
    if (result.lidar_fallback) ++fallback_frames;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [TC-LVGF] " << i << "/" << pcd_dirs.size()
                << " map=" << pipeline.mapSize()
                << " lines=" << pipeline.lineMapSize()
                << " fallback=" << fallback_frames;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double denom = std::max<size_t>(1, res.poses.size());
  res.note =
      "TC-LVGF: tightly coupled LiDAR-visual geometric-feature port with "
      "spherical fusion of pseudo-visual range-image lines and LiDAR linear "
      "features, point-to-plane + point-to-line scan-to-map optimization, and "
      "LiDAR fallback on visual-line scarcity. visual_lines/frame=" +
      std::to_string(static_cast<double>(visual_lines_total) / denom) +
      " fused_lines/frame=" +
      std::to_string(static_cast<double>(fused_lines_total) / denom) +
      " plane_corr/frame=" +
      std::to_string(static_cast<double>(plane_corr_total) / denom) +
      " line_corr/frame=" +
      std::to_string(static_cast<double>(line_corr_total) / denom) +
      " fallback_frames=" + std::to_string(fallback_frames) +
      " mean|residual|=" + std::to_string(residual_sum / denom);
  return res;
}

MethodResult runOplLvio(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const OplLvioDogfoodingOptions& options) {
  using namespace localization_zoo::opl_lvio;
  MethodResult res;
  res.name = "OPL-LVIO";

  OplLvioParams params;
  params.voxel_size = options.voxel_size;
  params.registration_voxel_size = options.registration_voxel_size;
  params.max_registration_points = options.max_registration_points;
  params.image_width = options.image_width;
  params.image_height = options.image_height;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.min_visual_points = options.min_visual_points;
  params.max_visual_points = options.max_visual_points;
  params.min_visual_lines = options.min_visual_lines;
  params.max_lidar_lines = options.max_lidar_lines;
  params.max_visual_lines = options.max_visual_lines;
  params.visual_point_weight = options.visual_point_weight;
  params.line_weight = options.line_weight;
  params.direction_weight = options.direction_weight;
  params.helmert_min_scale = options.helmert_min_scale;
  params.helmert_max_scale = options.helmert_max_scale;
  params.fusion_pixel_gate = options.fusion_pixel_gate;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  OplLvioPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  long long visual_points_total = 0;
  long long visual_lines_total = 0;
  long long fused_lines_total = 0;
  long long plane_corr_total = 0;
  long long point_corr_total = 0;
  long long line_corr_total = 0;
  long fallback_frames = 0;
  double point_scale_sum = 0.0;
  double line_scale_sum = 0.0;
  double residual_sum = 0.0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); ++i) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    visual_points_total += result.num_visual_points;
    visual_lines_total += result.num_visual_lines;
    fused_lines_total += result.num_fused_lines;
    plane_corr_total += result.num_plane_correspondences;
    point_corr_total += result.num_point_correspondences;
    line_corr_total += result.num_line_correspondences;
    point_scale_sum += result.point_weight_scale;
    line_scale_sum += result.line_weight_scale;
    residual_sum += result.mean_abs_residual;
    if (result.lidar_fallback) ++fallback_frames;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [OPL-LVIO] " << i << "/" << pcd_dirs.size()
                << " map=" << pipeline.mapSize()
                << " lines=" << pipeline.lineMapSize()
                << " fallback=" << fallback_frames;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double denom = std::max<size_t>(1, res.poses.size());
  res.note =
      "OPL-LVIO: optimized point-line LiDAR-visual-inertial port with "
      "range-image visual point/line proxies, LiDAR depth correlation, "
      "scan-to-map plane + visual point + visual line residuals, and "
      "Helmert-style variance component weighting. visual_points/frame=" +
      std::to_string(static_cast<double>(visual_points_total) / denom) +
      " visual_lines/frame=" +
      std::to_string(static_cast<double>(visual_lines_total) / denom) +
      " fused_lines/frame=" +
      std::to_string(static_cast<double>(fused_lines_total) / denom) +
      " plane_corr/frame=" +
      std::to_string(static_cast<double>(plane_corr_total) / denom) +
      " point_corr/frame=" +
      std::to_string(static_cast<double>(point_corr_total) / denom) +
      " line_corr/frame=" +
      std::to_string(static_cast<double>(line_corr_total) / denom) +
      " point_scale/frame=" + std::to_string(point_scale_sum / denom) +
      " line_scale/frame=" + std::to_string(line_scale_sum / denom) +
      " fallback_frames=" + std::to_string(fallback_frames) +
      " mean|residual|=" + std::to_string(residual_sum / denom);
  return res;
}

void applyVisualLidarAdapterOptions(
    const VisualLidarAdapterDogfoodingOptions& options,
    localization_zoo::opl_lvio::OplLvioParams* params) {
  params->voxel_size = options.voxel_size;
  params->registration_voxel_size = options.registration_voxel_size;
  params->max_registration_points = options.max_registration_points;
  params->image_width = options.image_width;
  params->image_height = options.image_height;
  params->max_icp_iterations = options.max_icp_iterations;
  params->max_correspondence_dist = options.max_correspondence_dist;
  params->min_visual_points = options.min_visual_points;
  params->max_visual_points = options.max_visual_points;
  params->min_visual_lines = options.min_visual_lines;
  params->max_lidar_lines = options.max_lidar_lines;
  params->max_visual_lines = options.max_visual_lines;
  params->local_map_radius = options.local_map_radius;
  params->map_cleanup_interval = options.map_cleanup_interval;
}

template <typename PipelineT, typename ParamsT>
MethodResult runVisualLidarAdapter(
    const std::vector<std::string>& pcd_dirs,
    const std::vector<Eigen::Matrix4d>& gt,
    const VisualLidarAdapterDogfoodingOptions& options,
    const std::string& result_name,
    const std::string& progress_name,
    const std::string& note_prefix) {
  MethodResult res;
  res.name = result_name;

  ParamsT params;
  applyVisualLidarAdapterOptions(options, &params.backend);
  PipelineT pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  long long visual_points_total = 0;
  long long visual_lines_total = 0;
  long long fused_lines_total = 0;
  long long plane_corr_total = 0;
  long long point_corr_total = 0;
  long long line_corr_total = 0;
  long fallback_frames = 0;
  double point_scale_sum = 0.0;
  double line_scale_sum = 0.0;
  double residual_sum = 0.0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); ++i) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    visual_points_total += result.backend.num_visual_points;
    visual_lines_total += result.backend.num_visual_lines;
    fused_lines_total += result.backend.num_fused_lines;
    plane_corr_total += result.backend.num_plane_correspondences;
    point_corr_total += result.backend.num_point_correspondences;
    line_corr_total += result.backend.num_line_correspondences;
    point_scale_sum += result.backend.point_weight_scale;
    line_scale_sum += result.backend.line_weight_scale;
    residual_sum += result.backend.mean_abs_residual;
    if (result.backend.lidar_fallback) ++fallback_frames;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [" << progress_name << "] " << i << "/"
                << pcd_dirs.size() << " map=" << pipeline.mapSize()
                << " lines=" << pipeline.lineMapSize()
                << " fallback=" << fallback_frames;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double denom = std::max<size_t>(1, res.poses.size());
  res.note =
      note_prefix + " visual_points/frame=" +
      std::to_string(static_cast<double>(visual_points_total) / denom) +
      " visual_lines/frame=" +
      std::to_string(static_cast<double>(visual_lines_total) / denom) +
      " fused_lines/frame=" +
      std::to_string(static_cast<double>(fused_lines_total) / denom) +
      " plane_corr/frame=" +
      std::to_string(static_cast<double>(plane_corr_total) / denom) +
      " point_corr/frame=" +
      std::to_string(static_cast<double>(point_corr_total) / denom) +
      " line_corr/frame=" +
      std::to_string(static_cast<double>(line_corr_total) / denom) +
      " point_scale/frame=" + std::to_string(point_scale_sum / denom) +
      " line_scale/frame=" + std::to_string(line_scale_sum / denom) +
      " fallback_frames=" + std::to_string(fallback_frames) +
      " mean|residual|=" + std::to_string(residual_sum / denom);
  return res;
}

MethodResult runTricpLo(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const TricpLoDogfoodingOptions& options) {
  using namespace localization_zoo::tricp_lo;
  MethodResult res;
  res.name = "TrICP-LO";

  TricpLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.normal_min_neighbors = options.normal_min_neighbors;
  params.planarity_threshold = options.planarity_threshold;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.max_iterations = options.max_iterations;
  params.auto_overlap = options.auto_overlap;
  params.overlap_ratio = options.overlap_ratio;
  params.min_overlap = options.min_overlap;
  params.frmsd_lambda = options.frmsd_lambda;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  TricpLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double overlap_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    overlap_sum += result.overlap;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [TrICP-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? overlap_sum / static_cast<double>(n) : 0.0);
  res.note =
      "TrICP-LO: trimmed/fractional ICP (least trimmed squares) point-to-plane "
      "with FRMSD automatic overlap estimation; CV prior, no GT seed. "
      "mean_overlap=" +
      std::string(buf);
  return res;
}

MethodResult runKcLo(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const KcLoDogfoodingOptions& options) {
  using namespace localization_zoo::kc_lo;
  MethodResult res;
  res.name = "KC-LO";

  KcLoParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_iterations = options.max_iterations;
  params.kc_sigma = options.kc_sigma;
  params.kc_sigma_init = options.kc_sigma_init;
  params.kc_anneal = options.kc_anneal;
  params.kc_radius_factor = options.kc_radius_factor;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  KcLoPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  double weight_sum = 0.0;
  long n = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    const auto result = pipeline.registerFrame(pts_local);
    weight_sum += result.mean_weight;
    ++n;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [KC-LO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.3f",
                n > 0 ? weight_sum / static_cast<double>(n) : 0.0);
  const bool annealed = options.kc_sigma_init > options.kc_sigma * 1.0001;
  std::ostringstream note;
  note << "KC-LO: correspondence-free kernel-correlation (Renyi quadratic entropy) "
       << "soft point-to-point with "
       << (annealed ? "coarse-to-fine sigma annealing" : "fixed sigma (no annealing)")
       << "; sigma_init=" << options.kc_sigma_init
       << " sigma_min=" << options.kc_sigma
       << "; CV prior, no GT seed. mean_weight=" << buf;
  res.note =
      note.str();
  return res;
}

MethodResult runDegenSense(const std::vector<std::string>& pcd_dirs,
                           const std::vector<Eigen::Matrix4d>& gt,
                           const std::vector<double>& frame_timestamps,
                           const std::vector<ImuSampleCsv>& imu_samples,
                           const DegenSenseDogfoodingOptions& options) {
  using namespace localization_zoo::degen_sense;
  MethodResult res;
  res.name = "DegenSense";

  DegenSenseParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.initial_threshold = options.initial_threshold;
  params.warmup_frames = options.warmup_frames;
  params.mad_k = options.mad_k;
  params.gyro_bias_gain = options.gyro_bias_gain;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  DegenSensePipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  long degen_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }
    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.used_imu) ++imu_frames;
    if (result.degenerate) ++degen_frames;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [DegenSense] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      (imu_frames > 0
           ? "Degeneracy-factor sensing (condition number) + adaptive "
             "MAD-outlier detection + IMU/LiDAR fusion compensation "
             "(first-pose anchored)."
           : "Degeneracy sensing, constant-velocity fallback (no imu.csv; "
             "first-pose anchored; compensation diagnostics-only).") +
      std::string(" degenerate_frames=") + std::to_string(degen_frames);
  return res;
}

MethodResult runVibrationLIO(const std::vector<std::string>& pcd_dirs,
                             const std::vector<Eigen::Matrix4d>& gt,
                             const std::vector<double>& frame_timestamps,
                             const std::vector<ImuSampleCsv>& imu_samples,
                             const VibrationLIODogfoodingOptions& options) {
  using namespace localization_zoo::vibration_lio;
  MethodResult res;
  res.name = "Vibration-LIO";

  VibrationLIOParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.sigma_depth = options.sigma_depth;
  params.sigma_bearing = options.sigma_bearing;
  params.gamma = options.gamma;
  params.scan_period = options.scan_period;
  params.gyro_bias_gain = options.gyro_bias_gain;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  VibrationLIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  double vib_sum = 0.0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }
    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.used_imu) ++imu_frames;
    vib_sum += result.vibration_omega;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [Vibration-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      (imu_frames > 0
           ? "Post-undistortion uncertainty LIO: IMU-MAD vibration intensity "
             "-> per-point covariance, Mahalanobis point-to-plane "
             "(first-pose anchored; no per-frame GT seed)."
           : "Uncertainty-weighted point-to-plane, no vibration estimate (no "
             "imu.csv; first-pose anchored; no per-frame GT seed).") +
      std::string(" mean_vib_omega=") +
      std::to_string(imu_frames > 0 ? vib_sum / imu_frames : 0.0);
  return res;
}

MethodResult runIDLIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const IDLIODogfoodingOptions& options) {
  using namespace localization_zoo::id_lio;
  MethodResult res;
  res.name = "ID-LIO";

  IDLIOParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.range_image_width = options.range_image_width;
  params.range_image_height = options.range_image_height;
  params.new_object_margin = options.new_object_margin;
  params.disappearance_margin = options.disappearance_margin;
  params.dynamic_weight = options.dynamic_weight;
  params.delayed_removal_frames = options.delayed_removal_frames;
  params.gyro_bias_gain = options.gyro_bias_gain;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  IDLIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  long long dynamic_total = 0;
  long long removed_total = 0;
  long long corr_total = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); ++i) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }
    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.used_imu) ++imu_frames;
    dynamic_total += result.num_dynamic_points;
    removed_total += result.num_removed_points;
    corr_total += result.num_correspondences;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [ID-LIO] " << i << "/" << pcd_dirs.size()
                << " map=" << pipeline.mapSize()
                << " dynamic_map=" << pipeline.dynamicMapPoints();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double denom = std::max<size_t>(1, res.poses.size());
  res.note =
      (imu_frames > 0
           ? "Indexed-point dynamic LIO: pseudo-occupancy dynamic detection, "
             "delayed removal, and IMU gyro prior."
           : "Indexed-point dynamic scan-to-map: pseudo-occupancy dynamic "
             "detection and delayed removal; no imu.csv so constant-velocity "
             "fallback.") +
      std::string(" dynamic/frame=") +
      std::to_string(static_cast<double>(dynamic_total) / denom) +
      " corr/frame=" + std::to_string(static_cast<double>(corr_total) / denom) +
      " removed_sum/frame=" +
      std::to_string(static_cast<double>(removed_total) / denom);
  return res;
}

MethodResult runRFLIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const RFLIODogfoodingOptions& options) {
  using namespace localization_zoo::rf_lio;
  MethodResult res;
  res.name = "RF-LIO";

  RfLioParams params;
  params.backend.voxel_size = options.voxel_size;
  params.backend.max_points_per_voxel = options.max_points_per_voxel;
  params.backend.max_icp_iterations = options.max_icp_iterations;
  params.backend.max_correspondence_dist = options.max_correspondence_dist;
  params.backend.range_image_width = options.range_image_width;
  params.backend.range_image_height = options.range_image_height;
  params.backend.new_object_margin = options.new_object_margin;
  params.backend.disappearance_margin = options.disappearance_margin;
  params.backend.dynamic_weight = options.dynamic_weight;
  params.backend.delayed_removal_frames = options.delayed_removal_frames;
  params.backend.gyro_bias_gain = options.gyro_bias_gain;
  params.backend.local_map_radius = options.local_map_radius;
  params.backend.map_cleanup_interval = options.map_cleanup_interval;
  params.range_image_width = options.range_image_width;
  params.range_image_height = options.range_image_height;
  params.foreground_margin = options.foreground_margin;
  params.max_removal_fraction = options.max_removal_fraction;
  params.min_keep_points = options.min_keep_points;
  RfLioPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());

  int imu_frames = 0;
  long long dynamic_total = 0;
  long long backend_removed_total = 0;
  long long corr_total = 0;
  long long removal_first_total = 0;
  long long candidate_total = 0;
  long long kept_total = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); ++i) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;
    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }
    const auto result = pipeline.registerFrame(pts_local, imu_batch);
    if (result.backend.used_imu) ++imu_frames;
    dynamic_total += result.backend.num_dynamic_points;
    backend_removed_total += result.backend.num_removed_points;
    corr_total += result.backend.num_correspondences;
    removal_first_total += result.removal_first_points;
    candidate_total += result.candidate_points;
    kept_total += result.kept_points;
    res.poses.push_back(result.pose);
    if (i % 10 == 0) {
      std::cerr << "\r  [RF-LIO] " << i << "/" << pcd_dirs.size()
                << " map=" << pipeline.mapSize()
                << " dynamic_map=" << pipeline.dynamicMapPoints()
                << " removed_first=" << removal_first_total;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  const double denom = std::max<size_t>(1, res.poses.size());
  res.note =
      (imu_frames > 0
           ? "RF-LIO removal-first LIO: adaptive multi-resolution range-image "
             "foreground removal before indexed dynamic LIO, with IMU gyro prior."
           : "RF-LIO removal-first scan-to-map: adaptive multi-resolution "
             "range-image foreground removal before indexed dynamic scan-to-map; "
             "no imu.csv so constant-velocity fallback.") +
      std::string(" removal_first/frame=") +
      std::to_string(static_cast<double>(removal_first_total) / denom) +
      " candidates/frame=" +
      std::to_string(static_cast<double>(candidate_total) / denom) +
      " kept/frame=" +
      std::to_string(static_cast<double>(kept_total) / denom) +
      " backend_dynamic/frame=" +
      std::to_string(static_cast<double>(dynamic_total) / denom) +
      " corr/frame=" + std::to_string(static_cast<double>(corr_total) / denom) +
      " backend_removed_sum/frame=" +
      std::to_string(static_cast<double>(backend_removed_total) / denom);
  return res;
}

MethodResult runBievrLIO(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const BievrLIODogfoodingOptions& options) {
  using namespace localization_zoo::bievr_lio;
  MethodResult res;
  res.name = "BIEVR-LIO";
  BievrLIOParams params;
  params.voxel_size = options.voxel_size;
  params.voxel_min_points = options.voxel_min_points;
  params.planarity_ratio = options.planarity_ratio;
  params.pixel_res = options.pixel_res;
  params.max_icp_iterations = options.max_icp_iterations;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  BievrLIOPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  double bump_sum = 0.0; int bn = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                   options.source_voxel_size),
                           options.max_source_points);
    if (pts.empty()) continue;
    const auto r = pipeline.registerFrame(pts);
    bump_sum += r.bump_constraint_ratio; ++bn;
    res.poses.push_back(anchorRelativePose(world_anchor, r.pose));
    if (i % 10 == 0)
      std::cerr << "\r  [BIEVR-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "Bump-image voxel map: oriented height image gradients add in-plane "
             "constraints (no GT seed; anchor matches first GT pose). "
             "mean_bump_ratio=" + std::to_string(bn > 0 ? bump_sum / bn : 0.0);
  return res;
}

MethodResult runUALIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const UALIODogfoodingOptions& options) {
  using namespace localization_zoo::ua_lio;
  MethodResult res;
  res.name = "UA-LIO";
  UALIOParams params;
  params.voxel_size = options.voxel_size;
  params.voxel_min_points = options.voxel_min_points;
  params.max_icp_iterations = options.max_icp_iterations;
  params.max_correspondence_dist = options.max_correspondence_dist;
  params.ground_constraint = options.ground_constraint;
  params.ground_weight = options.ground_weight;
  params.gyro_bias_gain = options.gyro_bias_gain;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  UALIOPipeline pipeline(params);
  pipeline.setInitialPose(gt.empty() ? Eigen::Matrix4d::Identity() : gt.front());
  int imu_frames = 0; long ground_total = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                   options.source_voxel_size),
                           options.max_source_points);
    if (pts.empty()) continue;
    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() &&
        frame_timestamps.size() == pcd_dirs.size() && i < frame_timestamps.size())
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    const auto r = pipeline.registerFrame(pts, imu_batch);
    if (r.used_imu) ++imu_frames;
    ground_total += r.ground_cells;
    res.poses.push_back(r.pose);
    if (i % 10 == 0)
      std::cerr << "\r  [UA-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = (imu_frames > 0
                  ? "Uncertainty-aware D2D LIO: per-point covariance + ground "
                    "constraint (first-pose anchored; no per-frame GT seed)."
                  : "D2D + ground constraint, constant-velocity (no imu.csv; "
                    "first-pose anchored; no per-frame GT seed).") +
             std::string(" ground_cells=") + std::to_string(ground_total);
  return res;
}

MethodResult runCubeLIO(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const CubeLIODogfoodingOptions& options) {
  using namespace localization_zoo::cube_lio;
  MethodResult res;
  res.name = "CUBE-LIO";

  CubeLIOParams params;
  params.voxel_size = options.voxel_size;
  params.max_points_per_voxel = options.max_points_per_voxel;
  params.max_icp_iterations = options.max_icp_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.initial_threshold = options.initial_threshold;
  params.cubemap_size = options.cubemap_size;
  params.gaussian_sigma = options.gaussian_sigma;
  params.semi_dense_quantile = options.semi_dense_quantile;
  params.intensity_sigma = options.intensity_sigma;
  params.local_map_radius = options.local_map_radius;
  params.map_cleanup_interval = options.map_cleanup_interval;
  CubeLIOPipeline pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  long semi_dense_total = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitLoadedXYZI(pts, options.max_input_points);
    if (pts.empty()) continue;

    std::vector<IntensityPoint> frame;
    frame.reserve(pts.size());
    for (const auto& p : pts) frame.push_back({p.point, p.intensity});

    const auto result = pipeline.registerFrame(frame);
    semi_dense_total += result.semi_dense_points;
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [CUBE-LIO] " << i << "/" << pcd_dirs.size()
                << " voxels=" << pipeline.mapSize();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Intensity-cubemap semi-dense odometry: IGM high-gradient feature "
      "selection + intensity-consistency-weighted point-to-plane (no GT seed; "
      "anchor matches first GT pose). semi_dense_total=" +
      std::to_string(semi_dense_total);
  return res;
}

MethodResult runDLO(const std::vector<std::string>& pcd_dirs,
                    const std::vector<Eigen::Matrix4d>& gt,
                    const DLODofeedingOptions& options) {
  using namespace localization_zoo::dlo;
  MethodResult res;
  res.name = "DLO";

  DLOParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.registration_voxel_size = options.registration_voxel_size;
  params.map_voxel_size = options.map_voxel_size;
  params.keyframe_translation_threshold = options.keyframe_translation_threshold;
  params.keyframe_rotation_threshold_rad = options.keyframe_rotation_threshold_rad;
  params.max_keyframes_in_map = options.max_keyframes_in_map;
  params.gicp.k_neighbors = options.gicp_k_neighbors;
  params.gicp.max_correspondence_distance = options.gicp_max_correspondence_distance;
  params.gicp.max_iterations = options.gicp_max_iterations;
  params.gicp.rotation_epsilon = options.gicp_rotation_epsilon;
  params.gicp.translation_epsilon = options.gicp_translation_epsilon;
  params.gicp.covariance_regularization = options.gicp_covariance_regularization;
  params.gicp.fitness_epsilon = options.gicp_fitness_epsilon;

  DLO pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud =
        toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [DLO] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " map_pts=" << result.map_points;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Keyframe scan-to-map odometry with GICP alignment (no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runDLIO(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const std::vector<double>& frame_timestamps,
                     const std::vector<ImuSampleCsv>& imu_samples,
                     const DLIODogfoodingOptions& options) {
  using namespace localization_zoo::dlio;
  MethodResult res;
  res.name = "DLIO";

  DLIOParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.registration_voxel_size = options.registration_voxel_size;
  params.map_voxel_size = options.map_voxel_size;
  params.keyframe_translation_threshold = options.keyframe_translation_threshold;
  params.keyframe_rotation_threshold_rad = options.keyframe_rotation_threshold_rad;
  params.max_keyframes_in_map = options.max_keyframes_in_map;
  params.gicp.k_neighbors = options.gicp_k_neighbors;
  params.gicp.max_correspondence_distance = options.gicp_max_correspondence_distance;
  params.gicp.max_iterations = options.gicp_max_iterations;
  params.gicp.rotation_epsilon = options.gicp_rotation_epsilon;
  params.gicp.translation_epsilon = options.gicp_translation_epsilon;
  params.gicp.covariance_regularization = options.gicp_covariance_regularization;
  params.gicp.fitness_epsilon = options.gicp_fitness_epsilon;
  params.imu_rotation_fusion_weight = options.imu_rotation_fusion_weight;
  params.imu_translation_fusion_weight = options.imu_translation_fusion_weight;
  params.imu_velocity_fusion_weight = options.imu_velocity_fusion_weight;
  params.lidar_confidence_correspondence_scale =
      options.lidar_confidence_correspondence_scale;

  DLIO pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud =
        toPclXYZICloud(pts);

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(cloud, imu_batch);
    res.poses.push_back(anchorRelativePose(world_anchor, result.state.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [DLIO] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " imu=" << (result.imu_used ? "y" : "n")
                << " corr=" << result.num_correspondences;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Direct LiDAR-inertial odometry: GICP scan-to-map plus IMU preintegration "
      "prior between scans when imu.csv and per-frame timestamps align; otherwise "
      "LiDAR motion prior only (no GT seed).";
  return res;
}

// CT-ICP with the upstream pipeline (jedeschaud/ct_icp, driving_config.yaml),
// for comparison with the paper numbers. Differences from runCTICP:
// full-resolution input with per-point time (sweep angle when the scan has no
// time field), one random point per 0.5 m voxel (0.2 m for the first 20
// frames) and no point cap, constant-velocity initialisation of both poses,
// rigid frames 0 and 1, a persistent 0.8 m voxel map (30 points, 0.1 m
// spacing, voxels beyond 100 m pruned, insertion skipped on > 3 deg in-scan
// rotation), 20 neighbours within 0.75 m with the farthest as the plane point,
// a2D on standard deviations, upstream weights, the first 900 residuals,
// 5 x 5 iterations (15 outer while starting up), Cauchy 0.1 and the
// mid-scan pose as output.
MethodResult runCTICPUpstream(const std::vector<std::string>& pcd_dirs,
                              const std::vector<Eigen::Matrix4d>& gt,
                              const CTICPDogfoodingOptions& options) {
  using namespace localization_zoo::ct_icp;
  MethodResult res;
  res.name = "CT-ICP";

  auto disabled = [&](const std::string& name) {
    std::stringstream ss(options.upstream_disable);
    std::string item;
    while (std::getline(ss, item, ',')) {
      if (item == name) return true;
    }
    return false;
  };
  const bool use_startup = !disabled("startup");
  const bool use_cv_init = !disabled("cv-init");
  const bool use_rigid_start = !disabled("rigid-start");
  const bool use_prune = !disabled("prune");
  const bool use_insert_gate = !disabled("insert-gate");
  const bool use_mid_pose = !disabled("mid-pose");
  const bool use_azimuth_time = !disabled("azimuth-time");
  // "persistent-map": 20-frame sliding window as in runCTICP instead.
  const bool use_persistent_map = !disabled("persistent-map");

  CTICPParams params;
  params.voxel_resolution = 0.8;
  params.max_points_per_voxel = 30;
  params.min_distance_between_points = 0.1;
  params.max_frames_in_map = use_persistent_map ? 0 : 20;
  params.knn = 20;
  params.pca_neighbor_count = 0;
  params.neighbor_search_radius = disabled("radius") ? 0.0 : 0.75;
  params.max_correspondence_dist = 1e12;
  params.multi_scale_correspondences = false;
  params.planarity_threshold = 0.0;
  params.min_planarity_floor = 0.0;
  params.a2d_from_std = !disabled("std-a2d");
  params.power_planarity = 2.0;
  params.weight_alpha = 0.9;
  params.weight_neighborhood = disabled("nb-weight") ? 0.0 : 0.1;
  params.neighborhood_weight_scale = 0.3 * 20;
  params.farthest_neighbor_reference = !disabled("farthest-ref");
  params.max_num_residuals = disabled("residual-cap") ? 0 : 900;
  params.cauchy_loss_param = 0.1;
  params.location_consistency_weight = 0.001;
  params.orientation_consistency_weight = 0.0;
  params.constant_velocity_weight = 0.001;
  params.flat_regularizer_weight = false;
  params.regularizer_n_cap = 0;
  params.max_iterations = 5;
  params.ceres_max_iterations = 5;
  params.upstream_convergence = !disabled("stop");
  params.keypoint_voxel_size = 1.5;
  params.truncate_voxel_coords = true;
  CTICPRegistration reg(params);

  constexpr int kInitNumFrames = 20;
  constexpr double kFrameVoxel = 0.5, kInitFrameVoxel = 0.2;
  constexpr double kKeypointVoxel = 1.5, kInitKeypointVoxel = 1.0;
  constexpr double kMinZ = -5.0;
  constexpr double kMaxDistance = 100.0;
  constexpr double kInsertionEgoRotationDeg = 3.0;
  constexpr int kInsertionSkippedFrames = 5;
  constexpr double kRadToDeg = 180.0 / M_PI;

  auto to_se3 = [](const Eigen::Matrix4d& T) {
    SE3 p;
    p.quat = Eigen::Quaterniond(T.block<3, 3>(0, 0)).normalized();
    p.trans = T.block<3, 1>(0, 3);
    return p;
  };
  auto to_matrix = [](const SE3& p) {
    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    T.block<3, 3>(0, 0) = p.quat.normalized().toRotationMatrix();
    T.block<3, 1>(0, 3) = p.trans;
    return T;
  };
  // Constant-velocity extrapolation X1 * X2^-1 * X1, as in upstream.
  auto extrapolate = [&](const SE3& x1, const SE3& x2) {
    return to_se3(to_matrix(x1) * to_matrix(x2).inverse() * to_matrix(x1));
  };

  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  std::mt19937 rng(42);
  std::vector<TrajectoryFrame> trajectory;
  size_t failures = 0, skipped_insertions = 0;
  int total_insertions = 0, skipped_since_insert = 0;

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    const bool startup = use_startup && static_cast<int>(i) < kInitNumFrames;
    LoadedScan scan = loadTimedPCD(pcd_dirs[i] + "/cloud.pcd", 0.0);
    if (!scan.has_per_point_time) {
      if (use_azimuth_time) {
        assignAzimuthTimes(&scan);
      } else {
        // Previous fallback: point index over the stored order.
        scan.relative_times.assign(scan.points.size(), 0.0);
      }
    }
    normalizeRelativeTimes(scan.relative_times);

    std::vector<TimedPoint> frame;
    frame.reserve(scan.points.size());
    for (size_t j = 0; j < scan.points.size(); j++) {
      if (scan.points[j].z() <= kMinZ) continue;
      TimedPoint tp;
      tp.raw_point = scan.points[j];
      tp.timestamp = scan.relative_times[j];
      frame.push_back(tp);
    }

    // One random point per voxel (upstream sub_sample_frame truncates the
    // voxel coordinates toward zero).
    std::shuffle(frame.begin(), frame.end(), rng);
    {
      const double voxel = startup ? kInitFrameVoxel : kFrameVoxel;
      std::unordered_set<Voxel, VoxelHash> seen;
      std::vector<TimedPoint> sub;
      sub.reserve(frame.size() / 4);
      for (const auto& tp : frame) {
        Voxel v{static_cast<short>(tp.raw_point.x() / voxel),
                static_cast<short>(tp.raw_point.y() / voxel),
                static_cast<short>(tp.raw_point.z() / voxel)};
        if (seen.insert(v).second) sub.push_back(tp);
      }
      frame.swap(sub);
    }
    if (use_rigid_start && i <= 1) {
      for (auto& tp : frame) tp.timestamp = 1.0;
    }
    std::shuffle(frame.begin(), frame.end(), rng);

    TrajectoryFrame init;
    if (i <= 1) {
      init.begin_pose = init.end_pose = to_se3(world_anchor);
    } else if (!use_cv_init) {
      init.begin_pose = init.end_pose = trajectory[i - 1].end_pose;
    } else if (i == 2) {
      init.begin_pose = trajectory[1].end_pose;
      init.end_pose = extrapolate(trajectory[1].end_pose, trajectory[0].end_pose);
    } else {
      init.begin_pose =
          extrapolate(trajectory[i - 1].begin_pose, trajectory[i - 2].begin_pose);
      init.end_pose =
          extrapolate(trajectory[i - 1].end_pose, trajectory[i - 2].end_pose);
    }

    reg.mutableParams().keypoint_voxel_size =
        startup ? kInitKeypointVoxel : kKeypointVoxel;
    reg.mutableParams().max_iterations = startup ? 15 : 5;

    TrajectoryFrame registered = init;
    if (i > 0) {
      auto result = reg.registerFrame(frame, init, &trajectory[i - 1]);
      registered = result.frame;
      const double ego_rot_deg =
          kRadToDeg * registered.begin_pose.quat.angularDistance(
                          registered.end_pose.quat);
      const double rel_rot_deg =
          kRadToDeg * trajectory[i - 1].end_pose.quat.angularDistance(
                          registered.end_pose.quat);
      // Upstream stops the sequence on these; count them instead.
      if (result.num_residuals < 20 ||
          (registered.end_pose.trans - registered.begin_pose.trans).norm() > 5.0 ||
          ego_rot_deg > 30.0 || rel_rot_deg > 30.0) {
        ++failures;
      }
    }
    trajectory.push_back(registered);

    bool add_points = true;
    if (use_insert_gate && total_insertions > 0) {
      const double ego_rot_deg =
          kRadToDeg * registered.begin_pose.quat.angularDistance(
                          registered.end_pose.quat);
      if (ego_rot_deg > kInsertionEgoRotationDeg) {
        add_points = skipped_since_insert > kInsertionSkippedFrames;
      }
    }
    if (use_prune) reg.removeVoxelsFarFrom(registered.end_pose.trans, kMaxDistance);
    if (add_points) {
      std::vector<Eigen::Vector3d> world;
      world.reserve(frame.size());
      for (const auto& tp : frame)
        world.push_back(registered.transformPoint(tp.raw_point, tp.timestamp));
      if (use_persistent_map) {
        reg.insertPoints(world);
      } else {
        reg.addPointsToMap(world);
      }
      ++total_insertions;
      skipped_since_insert = 0;
    } else {
      ++skipped_since_insert;
      ++skipped_insertions;
    }

    res.poses.push_back(
        to_matrix(use_mid_pose ? SE3::interpolate(registered.begin_pose,
                                                  registered.end_pose, 0.5)
                               : registered.end_pose));
    if (i % 10 == 0)
      std::cerr << "\r  [CT-ICP upstream] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  std::ostringstream note;
  note << "Upstream mechanics (jedeschaud/ct_icp driving_config); anchor matches "
          "the first GT pose. "
       << failures << " frames would have stopped upstream; "
       << skipped_insertions << " map insertions skipped.";
  if (!options.upstream_disable.empty())
    note << " Disabled: " << options.upstream_disable << ".";
  res.note = note.str();
  return res;
}

MethodResult runCTICP(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const CTICPDogfoodingOptions& options,
                      bool gt_seed = false) {
  using namespace localization_zoo::ct_icp;
  if (options.upstream_mechanics && !gt_seed) {
    return runCTICPUpstream(pcd_dirs, gt, options);
  }
  MethodResult res;
  res.name = "CT-ICP";

  CTICPParams params;
  params.voxel_resolution = options.voxel_resolution;
  params.max_iterations = options.max_iterations;
  params.ceres_max_iterations = options.ceres_max_iterations;
  params.planarity_threshold = options.planarity_threshold;
  params.keypoint_voxel_size = options.keypoint_voxel_size;
  params.max_frames_in_map = options.max_frames_in_map;
  if (options.max_correspondence_dist > 0.0) {
    params.max_correspondence_dist = options.max_correspondence_dist;
  }
  if (options.knn > 0) {
    params.knn = options.knn;
  }
  params.multi_scale_correspondences = options.multi_scale_correspondences;
  params.use_normal_cholesky_solver = options.use_normal_cholesky_solver;
  params.power_planarity = options.power_planarity;
  params.weight_alpha = options.weight_alpha;
  params.weight_neighborhood = options.weight_neighborhood;
  params.min_planarity_floor = options.min_planarity_floor;
  params.flat_regularizer_weight = options.flat_regularizer_weight;
  if (options.cauchy_loss_param > 0.0) {
    params.cauchy_loss_param = options.cauchy_loss_param;
  }
  params.regularizer_n_cap = options.regularizer_n_cap;
  params.use_closest_neighbor_reference = options.use_closest_neighbor_reference;
  params.pca_neighbor_count = options.pca_neighbor_count;
  params.min_distance_between_points = options.min_distance_between_points;
  params.coarse_to_fine = options.coarse_to_fine;
  params.coarse_iterations = options.coarse_iterations;
  params.coarse_search_radius = options.coarse_search_radius;
  params.coarse_planarity_threshold = options.coarse_planarity_threshold;
  params.coarse_cauchy_sigma_mult = options.coarse_cauchy_sigma_mult;
  if (options.location_consistency_weight >= 0.0) {
    params.location_consistency_weight = options.location_consistency_weight;
  }
  if (options.orientation_consistency_weight >= 0.0) {
    params.orientation_consistency_weight = options.orientation_consistency_weight;
  }
  if (options.constant_velocity_weight >= 0.0) {
    params.constant_velocity_weight = options.constant_velocity_weight;
  }
  CTICPRegistration reg(params);

  auto frame_to_matrix = [](const TrajectoryFrame& f) {
    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    T.block<3, 3>(0, 0) = f.end_pose.quat.toRotationMatrix();
    T.block<3, 1>(0, 3) = f.end_pose.trans;
    return T;
  };
  auto pose_to_matrix = [](const auto& p) {
    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    T.block<3, 3>(0, 0) = p.quat.toRotationMatrix();
    T.block<3, 1>(0, 3) = p.trans;
    return T;
  };

  TrajectoryFrame prev;
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  prev.begin_pose.trans = world_anchor.block<3, 1>(0, 3);
  prev.begin_pose.quat = Eigen::Quaterniond(world_anchor.block<3, 3>(0, 0));
  prev.end_pose = prev.begin_pose;
  res.poses.push_back(world_anchor);
  Eigen::Matrix4d T_prev_world = world_anchor;
  Eigen::Matrix4d T_prev_prev_world = world_anchor;

  size_t gated_rollbacks = 0;
  size_t auto_regularizer_cap_frames = 0;
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto scan = limitLoadedScan(loadTimedPCD(pcd_dirs[i] + "/cloud.pcd",
                                             options.source_voxel_size),
                                options.max_source_points);
    if (scan.points.empty()) continue;

    std::vector<TimedPoint> timed;
    const size_t denom = scan.points.size() > 1 ? scan.points.size() - 1 : 1;
    for (size_t j = 0; j < scan.points.size(); j++) {
      TimedPoint tp;
      tp.raw_point = scan.points[j];
      tp.timestamp = scan.has_per_point_time ? scan.relative_times[j]
                                             : static_cast<double>(j) / denom;
      timed.push_back(tp);
    }

    if (i == 0) {
      std::vector<Eigen::Vector3d> world;
      for (auto& tp : timed) world.push_back(prev.transformPoint(tp.raw_point, tp.timestamp));
      reg.addPointsToMap(world);
      continue;
    }

    TrajectoryFrame init;
    Eigen::Matrix4d T_seed_world = T_prev_world;
    if (gt_seed && i < gt.size()) {
      // Seed begin from previous GT end (i-1) and end from current GT (i).
      const Eigen::Matrix4d& T_begin =
          (i - 1 < gt.size()) ? gt[i - 1] : gt[i];
      const Eigen::Matrix4d& T_end = gt[i];
      init.begin_pose.trans = T_begin.block<3, 1>(0, 3);
      init.begin_pose.quat = Eigen::Quaterniond(T_begin.block<3, 3>(0, 0));
      init.end_pose.trans = T_end.block<3, 1>(0, 3);
      init.end_pose.quat = Eigen::Quaterniond(T_end.block<3, 3>(0, 0));
      T_seed_world = T_end;
    } else if (options.refinement_gate && i >= 2) {
      Eigen::Matrix4d T_pred;
      if (options.native_ct_icp_seed) {
        // Extrapolate from CT-ICP's own intra-scan motion: the body delta
        // estimated during the previous scan (begin_pose -> end_pose) is
        // re-applied for one more scan period. This adapts to the actual
        // per-frame motion rather than a constant inter-frame velocity.
        const Eigen::Matrix4d T_prev_begin = pose_to_matrix(prev.begin_pose);
        const Eigen::Matrix4d T_prev_end = pose_to_matrix(prev.end_pose);
        const Eigen::Matrix4d T_motion = T_prev_begin.inverse() * T_prev_end;
        T_pred = T_prev_end * T_motion;
      } else {
        // Velocity-model bootstrap: extend prev inter-frame body-motion once more.
        T_pred = velocityModelPrediction(T_prev_world, T_prev_prev_world);
      }
      init.begin_pose = prev.end_pose;
      init.end_pose.trans = T_pred.block<3, 1>(0, 3);
      init.end_pose.quat = Eigen::Quaterniond(T_pred.block<3, 3>(0, 0));
      T_seed_world = T_pred;
    } else {
      init.begin_pose = init.end_pose = prev.end_pose;
      T_seed_world = T_prev_world;
    }

    int active_regularizer_cap = options.regularizer_n_cap;
    if (options.auto_regularizer_cap &&
        i >= static_cast<size_t>(options.auto_regularizer_warmup_frames)) {
      const double prev_step_m =
          poseTranslationDelta(T_prev_world, T_prev_prev_world);
      const double prev_rot_rad =
          poseRotationDelta(T_prev_world, T_prev_prev_world);
      const double rot_per_meter =
          prev_rot_rad / std::max(prev_step_m, 1e-6);
      const bool turn_like =
          prev_step_m <= options.auto_regularizer_max_step &&
          rot_per_meter >= options.auto_regularizer_min_rot_per_meter;
      if (turn_like) {
        active_regularizer_cap = options.auto_regularizer_low_cap;
        ++auto_regularizer_cap_frames;
      }
    }
    reg.setRegularizerNCap(active_regularizer_cap);

    auto result = reg.registerFrame(timed, init, &prev);

    Eigen::Matrix4d T_refined = frame_to_matrix(result.frame);
    bool accepted = true;
    if (options.refinement_gate && !gt_seed && i >= 2) {
      // Reject if the refined end pose drifts unreasonably far from the
      // velocity-model seed (e.g. correspondence collapse at sharp turns).
      if (!isReasonableRefinement(T_refined, T_seed_world,
                                  options.max_seed_translation_delta,
                                  options.max_seed_rotation_delta_rad)) {
        accepted = false;
        ++gated_rollbacks;
        // Fall back to the velocity-model seed and rebuild a TrajectoryFrame
        // around it so the next frame's bootstrap stays stable.
        TrajectoryFrame fallback;
        fallback.begin_pose = prev.end_pose;
        fallback.end_pose.trans = T_seed_world.block<3, 1>(0, 3);
        fallback.end_pose.quat =
            Eigen::Quaterniond(T_seed_world.block<3, 3>(0, 0));
        result.frame = fallback;
        T_refined = T_seed_world;
      }
    }

    // Skip map update on rollback: deskewing along an untrusted trajectory
    // pollutes the voxel map and breaks subsequent correspondence search.
    if (accepted) {
      std::vector<Eigen::Vector3d> world;
      for (auto& tp : timed)
        world.push_back(result.frame.transformPoint(tp.raw_point, tp.timestamp));
      reg.addPointsToMap(world);
    }

    res.poses.push_back(T_refined);
    prev = result.frame;
    T_prev_prev_world = T_prev_world;
    T_prev_world = T_refined;

    if (i % 10 == 0)
      std::cerr << "\r  [CT-ICP] " << i << "/" << pcd_dirs.size();
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  if (gt_seed) {
    res.note = "Seeds CT-ICP TrajectoryFrame with GT begin/end pose per scan. "
               "Symmetric of the GT-seeded Policy A path for dogfooding-style "
               "fair-prior comparison.";
  } else if (options.refinement_gate) {
    std::ostringstream oss;
    oss << "Anchor matches first GT pose; subsequent frames use "
        << (options.native_ct_icp_seed ? "CT-ICP native (begin->end) "
                                        : "velocity-model ")
        << "bootstrap with LiTAMIN2-style acceptance gate (trans<="
        << options.max_seed_translation_delta
        << "m, rot<=" << options.max_seed_rotation_delta_rad
        << "rad). " << gated_rollbacks << " rollbacks to seed.";
    res.note = oss.str();
  } else {
    res.note = "Anchor matches first GT pose; subsequent frames rely on CT-ICP's "
               "own continuous-time motion prior (no GT seed).";
  }
  if (options.auto_regularizer_cap) {
    std::ostringstream oss;
    oss << res.note << " Auto regularizer cap enabled: low_cap="
        << options.auto_regularizer_low_cap
        << ", warmup_frames=" << options.auto_regularizer_warmup_frames
        << ", step<=" << options.auto_regularizer_max_step
        << "m, rot/m>=" << options.auto_regularizer_min_rot_per_meter
        << ", capped_frames=" << auto_regularizer_cap_frames << ".";
    res.note = oss.str();
  }
  return res;
}

MethodResult runCTICPNDT(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const CTICPDogfoodingOptions& ct_icp_options,
                         const NDTDogfoodingOptions& ndt_options) {
  MethodResult prior = runCTICP(pcd_dirs, gt, ct_icp_options, false);
  const double prior_ate = computeATE(prior.poses, gt);

  std::ostringstream note;
  note << "Hybrid: CT-ICP no-GT odometry prior feeds NDT scan-to-map initial "
          "guess; first frame remains anchored to GT for dogfooding alignment. "
       << "CT-ICP prior ATE=";
  if (std::isfinite(prior_ate)) {
    note << std::fixed << std::setprecision(3) << prior_ate << "m";
  } else {
    note << "nonfinite";
  }
  note << ". Runtime is CT-ICP+NDT combined.";

  MethodResult hybrid =
      runNDT(pcd_dirs, gt, ndt_options, false, &prior.poses, note.str());
  hybrid.name = "CT-ICP+NDT";
  hybrid.time_ms += prior.time_ms;
  return hybrid;
}

MethodResult runCTICPNDTKeyframe(
    const std::vector<std::string>& pcd_dirs,
    const std::vector<Eigen::Matrix4d>& gt,
    const CTICPDogfoodingOptions& ct_icp_options,
    const NDTDogfoodingOptions& ndt_options,
    const CTICPNDTHybridOptions& hybrid_options) {
  using namespace localization_zoo::ndt;

  MethodResult prior = runCTICP(pcd_dirs, gt, ct_icp_options, false);
  const double prior_ate = computeATE(prior.poses, gt);

  MethodResult res;
  res.name = "CT-ICP+NDT-KF";

  NDTParams params;
  params.resolution = ndt_options.resolution;
  params.max_iterations = ndt_options.max_iterations;
  params.step_size = ndt_options.step_size;
  params.convergence_threshold = ndt_options.convergence_threshold;
  params.min_points_per_cell = ndt_options.min_points_per_cell;
  NDTRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt.empty() ? Eigen::Matrix4d::Identity() : gt[0];
  res.poses.push_back(T_est);

  size_t attempted = 0;
  size_t accepted = 0;
  size_t rejected = 0;
  size_t fallback_prior = 0;

  const int interval = std::max(1, hybrid_options.keyframe_interval);
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         ndt_options.source_voxel_size),
                                 ndt_options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, ndt_options.map_max_points,
                     ndt_options.map_radius);
      reg.setTarget(map_points);
      continue;
    }

    Eigen::Matrix4d T_prior = T_est;
    if (i < prior.poses.size() && isFiniteMatrix(prior.poses[i])) {
      T_prior = prior.poses[i];
    } else {
      ++fallback_prior;
    }

    T_est = T_prior;
    const bool should_correct = (i % static_cast<size_t>(interval)) == 0;
    if (should_correct) {
      ++attempted;
      const auto result = reg.align(pts_local, T_prior);
      bool score_ok = true;
      if (hybrid_options.max_ndt_score > 0.0) {
        score_ok = std::isfinite(result.score) &&
                   result.score <= hybrid_options.max_ndt_score;
      }
      const bool accepted_correction =
          (result.converged || result.iterations >= 2) &&
          score_ok &&
          isFiniteMatrix(result.transformation) &&
          isReasonableRefinement(
              result.transformation, T_prior,
              hybrid_options.max_correction_translation_delta,
              hybrid_options.max_correction_rotation_delta_rad);
      if (accepted_correction) {
        T_est = result.transformation;
        ++accepted;
      } else {
        ++rejected;
      }
      if (i % 10 == 0) {
        std::cerr << "\r  [CT-ICP+NDT-KF] " << i << "/" << pcd_dirs.size()
                  << " score=" << std::fixed << std::setprecision(3)
                  << result.score
                  << " accepted=" << accepted << "/" << attempted;
      }
    } else if (i % 10 == 0) {
      std::cerr << "\r  [CT-ICP+NDT-KF] " << i << "/" << pcd_dirs.size()
                << " accepted=" << accepted << "/" << attempted;
    }

    res.poses.push_back(T_est);
    addPointsToMap(map_points, pts_local, T_est, ndt_options.map_max_points,
                   ndt_options.map_radius);
    if (shouldRefreshTargetMap(i, ndt_options.refresh_interval)) {
      reg.setTarget(map_points);
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count() +
      prior.time_ms;

  std::ostringstream note;
  note << "Hybrid keyframe correction: CT-ICP no-GT odometry is the base "
          "trajectory; NDT T1 correction is attempted every "
       << interval << " frames and accepted only when correction delta is <= "
       << hybrid_options.max_correction_translation_delta << "m / "
       << hybrid_options.max_correction_rotation_delta_rad << "rad";
  if (hybrid_options.max_ndt_score > 0.0) {
    note << " and score <= " << hybrid_options.max_ndt_score;
  }
  note << ". accepted=" << accepted << "/" << attempted
       << ", rejected=" << rejected
       << ", finite-prior fallbacks=" << fallback_prior
       << ", CT-ICP prior ATE=";
  if (std::isfinite(prior_ate)) {
    note << std::fixed << std::setprecision(3) << prior_ate << "m";
  } else {
    note << "nonfinite";
  }
  note << ". Runtime is CT-ICP+NDT combined.";
  res.note = note.str();
  return res;
}

MethodResult runCTLIO(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      bool estimate_imu_bias,
                      int fixed_lag_state_window,
                      double fixed_lag_velocity_prior_weight,
                      double fixed_lag_gyro_bias_weight_scale,
                      double fixed_lag_accel_bias_weight_scale,
                      double fixed_lag_history_decay,
                      int fixed_lag_outer_iterations,
                      bool fixed_lag_optimize_history,
                      bool multi_scale_correspondences,
                      bool coarse_to_fine,
                      int coarse_iterations,
                      int coarse_search_radius,
                      double coarse_planarity_threshold,
                      double coarse_cauchy_mult,
                      int max_frames_in_map,
                      int max_iterations,
                      bool use_bspline_trajectory,
                      double bspline_anchor_weight) {
  using namespace localization_zoo::ct_lio;
  MethodResult res;
  res.name = "CT-LIO";
  if (multi_scale_correspondences) {
    res.name += "+ms";
  }
  if (coarse_to_fine) {
    res.name += "+c2f";
  }
  if (use_bspline_trajectory) {
    res.name += "+bspline";
  }
  if (estimate_imu_bias) {
    res.name += "+bias";
  }
  if (fixed_lag_state_window > 1) {
    res.name += "+lag";
  }
  if (fixed_lag_optimize_history) {
    res.name += "+smooth";
  }

  CTLIOParams params;
  params.voxel_resolution = 1.0;
  params.max_iterations = max_iterations;
  params.ceres_max_iterations = 2;
  params.planarity_threshold = 0.1;
  params.keypoint_voxel_size = 1.0;
  params.max_frames_in_map = max_frames_in_map;
  params.multi_scale_correspondences = multi_scale_correspondences;
  params.coarse_to_fine = coarse_to_fine;
  params.coarse_iterations = coarse_iterations;
  params.coarse_search_radius = coarse_search_radius;
  params.coarse_planarity_threshold = coarse_planarity_threshold;
  params.coarse_cauchy_sigma_mult = coarse_cauchy_mult;
  params.use_bspline_trajectory = use_bspline_trajectory;
  params.bspline_anchor_weight = bspline_anchor_weight;
  params.estimate_imu_bias = estimate_imu_bias;
  if (fixed_lag_state_window > 1) {
    params.fixed_lag_state_window = fixed_lag_state_window;
    params.fixed_lag_velocity_prior_weight = fixed_lag_velocity_prior_weight;
    params.fixed_lag_gyro_bias_weight_scale = fixed_lag_gyro_bias_weight_scale;
    params.fixed_lag_accel_bias_weight_scale = fixed_lag_accel_bias_weight_scale;
    params.fixed_lag_history_decay = fixed_lag_history_decay;
    params.fixed_lag_outer_iterations = fixed_lag_outer_iterations;
    params.fixed_lag_optimize_history = fixed_lag_optimize_history;
  }
  CTLIORegistration reg(params);

  CTLIOState state;
  state.frame.begin_pose.trans = gt[0].block<3, 1>(0, 3);
  state.frame.begin_pose.quat = Eigen::Quaterniond(gt[0].block<3, 3>(0, 0));
  state.frame.end_pose = state.frame.begin_pose;
  res.poses.push_back(gt[0]);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto scan = limitLoadedScan(loadTimedPCD(pcd_dirs[i] + "/cloud.pcd", 1.0), 1200);
    if (scan.points.empty()) continue;

    std::vector<localization_zoo::ct_icp::TimedPoint> timed;
    timed.reserve(scan.points.size());
    const size_t denom = scan.points.size() > 1 ? scan.points.size() - 1 : 1;
    for (size_t j = 0; j < scan.points.size(); j++) {
      localization_zoo::ct_icp::TimedPoint tp;
      tp.raw_point = scan.points[j];
      tp.timestamp = scan.has_per_point_time ? scan.relative_times[j]
                                             : static_cast<double>(j) / denom;
      timed.push_back(tp);
    }

    if (i == 0) {
      std::vector<Eigen::Vector3d> world;
      world.reserve(timed.size());
      for (const auto& tp : timed) {
        world.push_back(state.frame.transformPoint(tp.raw_point, tp.timestamp));
      }
      reg.addPointsToMap(world);
      continue;
    }

    double dt = std::max(frame_timestamps[i] - frame_timestamps[i - 1], 1e-3);
    Eigen::Vector3d gt_velocity =
        (gt[i].block<3, 1>(0, 3) - gt[i - 1].block<3, 1>(0, 3)) / dt;
    CTLIOState init = state;
    init.frame.begin_pose = state.frame.end_pose;
    init.frame.end_pose.trans = gt[i].block<3, 1>(0, 3);
    init.frame.end_pose.quat = Eigen::Quaterniond(gt[i].block<3, 3>(0, 0));
    init.begin_velocity = gt_velocity;
    init.end_velocity = gt_velocity;

    auto imu_window =
        selectImuWindow(imu_samples, frame_timestamps[i - 1], frame_timestamps[i]);
    auto result = reg.registerFrame(timed, init, imu_window);

    std::vector<Eigen::Vector3d> world;
    world.reserve(timed.size());
    for (const auto& tp : timed) {
      world.push_back(
          result.state.frame.transformPoint(tp.raw_point, tp.timestamp));
    }
    reg.addPointsToMap(world);

    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    T.block<3, 3>(0, 0) = result.state.frame.end_pose.quat.toRotationMatrix();
    T.block<3, 1>(0, 3) = result.state.frame.end_pose.trans;
    res.poses.push_back(T);
    state = result.state;

    if (i % 1 == 0) {
      std::cerr << "\r  [CT-LIO] " << i << "/" << pcd_dirs.size()
                << " corr=" << result.num_correspondences;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  return res;
}

MethodResult runXICP(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const XICPDogfoodingOptions& options,
                     bool no_gt_seed = false) {
  using namespace localization_zoo::xicp;
  MethodResult res;
  res.name = "X-ICP";

  XICPParams params;
  params.max_iterations = options.max_iterations;
  params.convergence_threshold = options.convergence_threshold;
  params.kappa_f = options.kappa_f;
  params.kappa_s = options.kappa_s;
  XICPRegistration reg(params);

  std::vector<Eigen::Vector3d> map_points;
  Eigen::Matrix4d T_est = gt[0];
  Eigen::Matrix4d T_prev_prev_est = gt[0];
  res.poses.push_back(T_est);

  // KdTree for NN search in map
  pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
  pcl::PointCloud<pcl::PointXYZ>::Ptr map_cloud(new pcl::PointCloud<pcl::PointXYZ>);

  auto rebuildKdTree = [&]() {
    map_cloud->clear();
    map_cloud->reserve(map_points.size());
    for (const auto& p : map_points) {
      pcl::PointXYZ pt;
      pt.x = static_cast<float>(p.x());
      pt.y = static_cast<float>(p.y());
      pt.z = static_cast<float>(p.z());
      map_cloud->push_back(pt);
    }
    if (!map_cloud->empty()) {
      kdtree.setInputCloud(map_cloud);
    }
  };

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts_local = limitPoints(loadPCD(pcd_dirs[i] + "/cloud.pcd",
                                         options.source_voxel_size),
                                 options.max_source_points);
    if (pts_local.empty()) continue;

    if (i == 0) {
      addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                     options.map_radius);
      rebuildKdTree();
      continue;
    }

    const Eigen::Matrix4d T_init_guess =
        no_gt_seed
            ? (i >= 2 ? velocityModelPrediction(T_est, T_prev_prev_est) : T_est)
            : gt[i];
    const Eigen::Matrix4d T_prev_est_snapshot = T_est;

    // Transform source points to world frame using initial guess
    Eigen::Matrix3d R_init = T_init_guess.block<3, 3>(0, 0);
    Eigen::Vector3d t_init = T_init_guess.block<3, 1>(0, 3);

    // Build correspondences: for each source point, find nearest map point
    // and compute normal from neighborhood
    std::vector<Correspondence> correspondences;
    if (!map_cloud->empty()) {
      const int K = options.k_neighbors;
      std::vector<int> nn_indices(K);
      std::vector<float> nn_dists(K);
      const double max_dist_sq =
          options.max_correspondence_distance * options.max_correspondence_distance;

      for (const auto& p_local : pts_local) {
        Eigen::Vector3d p_world = R_init * p_local + t_init;
        pcl::PointXYZ query;
        query.x = static_cast<float>(p_world.x());
        query.y = static_cast<float>(p_world.y());
        query.z = static_cast<float>(p_world.z());

        if (kdtree.nearestKSearch(query, K, nn_indices, nn_dists) < 3) continue;
        if (nn_dists[0] > max_dist_sq) continue;

        // Compute normal from neighborhood covariance
        Eigen::Vector3d centroid = Eigen::Vector3d::Zero();
        int valid_nn = std::min(K, static_cast<int>(nn_indices.size()));
        for (int k = 0; k < valid_nn; k++) {
          centroid += map_points[nn_indices[k]];
        }
        centroid /= valid_nn;

        Eigen::Matrix3d cov = Eigen::Matrix3d::Zero();
        for (int k = 0; k < valid_nn; k++) {
          Eigen::Vector3d d = map_points[nn_indices[k]] - centroid;
          cov += d * d.transpose();
        }
        cov /= valid_nn;

        Eigen::SelfAdjointEigenSolver<Eigen::Matrix3d> solver(cov);
        Eigen::Vector3d normal = solver.eigenvectors().col(0);  // smallest eigenvalue

        // Ensure consistent normal orientation (pointing toward sensor)
        if (normal.dot(p_world - map_points[nn_indices[0]]) > 0) {
          normal = -normal;
        }

        Correspondence corr;
        corr.source = p_local;
        corr.target = map_points[nn_indices[0]];
        corr.normal = normal;
        correspondences.push_back(corr);
      }
    }

    bool accepted = false;
    if (correspondences.size() >= 64) {
      const auto result = reg.align(correspondences, T_init_guess);
      if ((result.converged || correspondences.size() >= 128) &&
          isReasonableRefinement(result.transformation, T_init_guess,
                                 options.max_seed_translation_delta,
                                 options.max_seed_rotation_delta_rad)) {
        T_est = result.transformation;
        accepted = true;
      }
    }
    if (!accepted) {
      T_est = T_init_guess;
    }
    T_prev_prev_est = T_prev_est_snapshot;
    res.poses.push_back(T_est);

    addPointsToMap(map_points, pts_local, T_est, options.map_max_points,
                   options.map_radius);
    if (shouldRefreshTargetMap(i, options.refresh_interval)) {
      rebuildKdTree();
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [X-ICP] " << i << "/" << pcd_dirs.size()
                << " corr=" << correspondences.size();
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = no_gt_seed
      ? "Uses velocity-model prediction as scan-to-map initial guess (no GT seed)."
      : "Uses GT-seeded scan-to-map initialization with weak-update fallback "
        "in this dogfooding tool.";
  return res;
}

MethodResult runFastLio2(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const std::vector<double>& frame_timestamps,
                         const std::vector<ImuSampleCsv>& imu_samples,
                         const FastLio2DogfoodingOptions& options) {
  using namespace localization_zoo::fast_lio2;
  MethodResult res;
  res.name = "FAST-LIO2";

  FastLio2Params params;
  params.max_iterations = options.max_iterations;
  params.ceres_max_iterations = options.ceres_max_iterations;
  params.voxel_resolution = options.voxel_resolution;
  params.keypoint_voxel_size = options.keypoint_voxel_size;
  params.knn = options.knn;
  params.max_correspondence_distance = options.max_correspondence_distance;
  params.planarity_threshold = options.planarity_threshold;
  params.max_frames_in_map = options.max_frames_in_map;

  FastLio2 pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    // Filter by range
    std::vector<Eigen::Vector3d> filtered;
    filtered.reserve(pts.size());
    for (const auto& p : pts) {
      double r = p.norm();
      if (r >= options.min_range && r <= options.max_range) {
        filtered.push_back(p);
      }
    }

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(filtered, imu_batch);

    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.state.quat.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.state.trans;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [FAST-LIO2] " << i << "/" << pcd_dirs.size()
                << " imu=" << (result.imu_used ? "y" : "n")
                << " corr=" << result.num_correspondences
                << " map=" << result.map_size;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "LiDAR-inertial odometry with iterated Kalman filter and voxel map "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runHdlGraphSlam(const std::vector<std::string>& pcd_dirs,
                             const std::vector<Eigen::Matrix4d>& gt,
                             const HdlGraphSlamDogfoodingOptions& options) {
  using namespace localization_zoo::hdl_graph_slam;
  MethodResult res;
  res.name = "HDL-Graph-SLAM";

  HdlGraphSlamParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.registration_voxel_size = options.registration_voxel_size;
  params.map_voxel_size = options.map_voxel_size;
  params.keyframe_stride = options.keyframe_stride;
  params.max_keyframes_in_submap = options.max_keyframes_in_submap;
  params.loop_stride = options.loop_stride;
  params.enable_loop_closure = options.enable_loop_closure;
  params.enable_floor_constraint = options.enable_floor_constraint;

  HdlGraphSlam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud =
        toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [HDL-Graph-SLAM] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " loops=" << result.num_loop_edges
                << " submap=" << result.submap_points;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "NDT odometry with pose-graph optimization and ScanContext loop closure "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runVgicpSlam(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const VgicpSlamDogfoodingOptions& options) {
  using namespace localization_zoo::vgicp_slam;
  MethodResult res;
  res.name = "VGICP-SLAM";

  VgicpSlamParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.registration_voxel_size = options.registration_voxel_size;
  params.map_voxel_size = options.map_voxel_size;
  params.keyframe_stride = options.keyframe_stride;
  params.max_keyframes_in_submap = options.max_keyframes_in_submap;
  params.loop_stride = options.loop_stride;
  params.enable_loop_closure = options.enable_loop_closure;

  VgicpSlam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud =
        toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    res.poses.push_back(anchorRelativePose(world_anchor, result.pose));

    if (i % 10 == 0) {
      std::cerr << "\r  [VGICP-SLAM] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " loops=" << result.num_loop_edges
                << " submap=" << result.submap_points;
    }
  }
  std::cerr << std::endl;
  res.time_ms =
      std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Voxel-GICP odometry with pose-graph optimization and ScanContext loop closure "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runSuMa(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const SuMaDogfoodingOptions& options) {
  using namespace localization_zoo::suma;
  MethodResult res;
  res.name = "SuMa";
  if (options.paper) {
    SuMaPaperParams pp;
    for (const auto& kv : options.paper_overrides) {
      const std::string& k = kv.first;
      const double v = kv.second;
      if (k == "normalize_bilinear") pp.normalize_bilinear = v != 0.0;
      else if (k == "bilinear_sampling") pp.bilinear_sampling = v != 0.0;
      else if (k == "fallback_mode") pp.fallback_mode = v != 0.0;
      else if (k == "use_stability") pp.use_stability = v != 0.0;
      else if (k == "max_iterations") pp.max_iterations = static_cast<int>(v);
      else if (k == "active_timestamps") pp.active_timestamps = static_cast<int>(v);
      else if (k == "width") pp.width = static_cast<int>(v);
      else if (k == "icp_max_distance") pp.icp_max_distance = v;
      else if (k == "icp_max_angle_deg") pp.icp_max_angle_deg = v;
      else if (k == "huber_factor") pp.huber_factor = v;
      else if (k == "map_max_distance") pp.map_max_distance = v;
      else if (k == "map_max_angle_deg") pp.map_max_angle_deg = v;
      else if (k == "max_depth") pp.max_depth = v;
      else if (k == "fov_up_deg") pp.fov_up_deg = v;
      else if (k == "fov_down_deg") pp.fov_down_deg = v;
      else if (k == "height") pp.height = static_cast<int>(v);
      else if (k == "initialize_identity") pp.initialize_identity = v != 0.0;
      else if (k == "degenerate_ratio") pp.degenerate_ratio = v;
      else if (k == "coarse_frames") pp.coarse_frames = static_cast<int>(v);
      else if (k == "coarse_iterations") pp.coarse_iterations = static_cast<int>(v);
      else if (k == "coarse_distance_scale") pp.coarse_distance_scale = v;
      else if (k == "fallback_rot_threshold") pp.fallback_rot_threshold = v;
      else if (k == "fallback_trans_threshold") pp.fallback_trans_threshold = v;
      else std::cerr << "unknown --suma-paper-set key " << k << std::endl;
    }
    SuMaPaper paper(pp);
    const Eigen::Matrix4d anchor = gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
    long fallbacks = 0;
    long coarse_starts = 0;
    auto t_start = Clock::now();
    for (size_t i = 0; i < pcd_dirs.size(); i++) {
      const auto xyzi = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", 0.0);
      if (xyzi.empty()) continue;
      std::vector<Eigen::Vector3d> pts;
      pts.reserve(xyzi.size());
      for (const auto& p : xyzi) pts.push_back(p.point);
      const auto r = paper.process(pts);
      fallbacks += r.fallback ? 1 : 0;
      coarse_starts += r.coarse_start ? 1 : 0;
      res.poses.push_back(anchorRelativePose(anchor, r.pose));
      if (i % 10 == 0) std::cerr << "\r  [SuMa paper] " << i << "/" << pcd_dirs.size();
    }
    std::cerr << std::endl;
    res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t_start).count();
    res.note = "SuMa paper pipeline (SuMaPaper: rendered surfel model, projective frame-to-model ICP, surfel "
               "stability and fusion per RSS 2018 / official default.xml); raw scans, no GT seed, no loop "
               "closure. frame-to-frame fallbacks=" + std::to_string(fallbacks);
    if (pp.degenerate_ratio > 0.0)
      res.note += "; opt-in local translation remap ratio=" + std::to_string(pp.degenerate_ratio) +
                  " (not in the paper)";
    if (pp.coarse_frames > 0 && pp.coarse_iterations > 0)
      res.note += "; opt-in initial coarse registrations=" + std::to_string(coarse_starts) +
                  " frames=" + std::to_string(pp.coarse_frames) +
                  " distance_scale=" + std::to_string(pp.coarse_distance_scale) +
                  " max_iterations=" + std::to_string(pp.coarse_iterations) + " (not in the paper)";
    return res;
  }
  SuMaParams params;
  params.n_scans = options.n_scans;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.surfel_resolution = options.surfel_resolution;
  params.surfel_stride = options.surfel_stride;
  params.max_iterations = options.max_iterations;
  params.max_frames_in_map = options.max_frames_in_map;
  SuMa pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCDXYZI(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitLoadedXYZI(pts, options.max_input_points);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud = toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [SuMa] " << i << "/" << pcd_dirs.size();
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Surfel-based mapping with constant-velocity prediction (no GT seed; "
      "anchor matches first GT pose).";
  return res;
}

MethodResult runBalm2(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const Balm2DogfoodingOptions& options) {
  using namespace localization_zoo::balm2;
  MethodResult res;
  res.name = "BALM2";
  Balm2Params params;
  params.corner_resolution = options.corner_resolution;
  params.surface_resolution = options.surface_resolution;
  params.corner_stride = options.corner_stride;
  params.surface_stride = options.surface_stride;
  params.window_size = options.window_size;
  params.num_outer_iterations = options.num_outer_iterations;
  params.ceres_max_iterations = options.ceres_max_iterations;
  BALM2 pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud = toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [BALM2] " << i << "/" << pcd_dirs.size();
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "Bundle adjustment for lidar mapping (no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runIscLoam(const std::vector<std::string>& pcd_dirs,
                        const std::vector<Eigen::Matrix4d>& gt,
                        const IscLoamDogfoodingOptions& options) {
  using namespace localization_zoo::isc_loam;
  MethodResult res;
  res.name = "ISC-LOAM";
  IscLoamParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.keyframe_stride = options.keyframe_stride;
  params.loop_stride = options.loop_stride;
  params.enable_loop_closure = options.enable_loop_closure;
  IscLoam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud = toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [ISC-LOAM] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " loops=" << result.num_loop_edges;
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Intensity scan context + LOAM with loop closure using preserved PCD "
      "intensity fields (no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runLoamLivox(const std::vector<std::string>& pcd_dirs,
                          const std::vector<Eigen::Matrix4d>& gt,
                          const LoamLivoxDogfoodingOptions& options) {
  using namespace localization_zoo::loam_livox;
  MethodResult res;
  res.name = "LOAM-Livox";
  LivoxLOAMParams params;
  params.scan_registration.less_flat_leaf_size = options.less_flat_leaf_size;
  params.odometry.num_optimization_iters = options.odom_outer_iters;
  params.mapping.num_optimization_iters = options.map_outer_iters;
  params.mapping.line_resolution = options.map_line_resolution;
  params.mapping.plane_resolution = options.map_plane_resolution;
  LivoxLOAM pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud = toPclXYZICloud(pts);
    const auto result = pipeline.process(cloud);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [LOAM-Livox] " << i << "/" << pcd_dirs.size();
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note = "LOAM adapted for Livox LiDAR (no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runLioSam(const std::vector<std::string>& pcd_dirs,
                       const std::vector<Eigen::Matrix4d>& gt,
                       const std::vector<double>& frame_timestamps,
                       const std::vector<ImuSampleCsv>& imu_samples,
                       const LioSamDogfoodingOptions& options) {
  using namespace localization_zoo::lio_sam;
  MethodResult res;
  res.name = "LIO-SAM";
  LioSamParams params;
  params.keyframe_stride = options.keyframe_stride;
  params.enable_loop_closure = options.enable_loop_closure;
  params.enable_imu_rotation_prior = options.enable_imu_rotation_prior;
  LioSam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud = toPclXYZICloud(pts);

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(cloud, imu_batch);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [LIO-SAM] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " loops=" << result.num_loop_edges
                << " imu=" << (result.imu_used ? "y" : "n");
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Tightly-coupled LiDAR-inertial odometry with factor graph and loop closure "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runLINS(const std::vector<std::string>& pcd_dirs,
                     const std::vector<Eigen::Matrix4d>& gt,
                     const std::vector<double>& frame_timestamps,
                     const std::vector<ImuSampleCsv>& imu_samples,
                     const LINSDogfoodingOptions& options) {
  using namespace localization_zoo::lins;
  MethodResult res;
  res.name = "LINS";
  LINSParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.registration_voxel_size = options.registration_voxel_size;
  params.map_voxel_size = options.map_voxel_size;
  params.max_correspondences = options.max_correspondences;
  params.max_keyframes_in_map = options.max_keyframes_in_map;
  LINS pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;
    const pcl::PointCloud<pcl::PointXYZI>::ConstPtr cloud = toPclXYZICloud(pts);

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(cloud, imu_batch);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.state.rotation;
    pose.block<3, 1>(0, 3) = result.state.position;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [LINS] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " corr=" << result.num_correspondences
                << " map=" << result.map_points;
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "LiDAR-inertial navigation with error-state iterated Kalman filter "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runFastLioSlam(const std::vector<std::string>& pcd_dirs,
                            const std::vector<Eigen::Matrix4d>& gt,
                            const std::vector<double>& frame_timestamps,
                            const std::vector<ImuSampleCsv>& imu_samples,
                            const FastLioSlamDogfoodingOptions& options) {
  using namespace localization_zoo::fast_lio_slam;
  MethodResult res;
  res.name = "FAST-LIO-SLAM";
  FastLioSlamParams params;
  params.front_end.max_iterations = options.max_iterations;
  params.front_end.ceres_max_iterations = options.ceres_max_iterations;
  params.front_end.voxel_resolution = options.voxel_resolution;
  params.front_end.keypoint_voxel_size = options.keypoint_voxel_size;
  params.front_end.max_frames_in_map = options.max_frames_in_map;
  params.keyframe_stride = options.keyframe_stride;
  params.loop_stride = options.loop_stride;
  params.enable_loop_closure = options.enable_loop_closure;
  FastLioSlam pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    std::vector<Eigen::Vector3d> filtered;
    filtered.reserve(pts.size());
    for (const auto& p : pts) {
      double r = p.norm();
      if (r >= options.min_range && r <= options.max_range) {
        filtered.push_back(p);
      }
    }

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(filtered, imu_batch);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.q_w_curr.toRotationMatrix();
    pose.block<3, 1>(0, 3) = result.t_w_curr;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [FAST-LIO-SLAM] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " loops=" << result.num_loop_edges
                << " imu=" << (result.imu_used ? "y" : "n");
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "FAST-LIO2 front-end with ScanContext loop closure and pose-graph optimization "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runPointLio(const std::vector<std::string>& pcd_dirs,
                         const std::vector<Eigen::Matrix4d>& gt,
                         const std::vector<double>& frame_timestamps,
                         const std::vector<ImuSampleCsv>& imu_samples,
                         const PointLioDogfoodingOptions& options) {
  using namespace localization_zoo::point_lio;
  MethodResult res;
  res.name = "Point-LIO";
  PointLioParams params;
  params.min_range = options.min_range;
  params.max_range = options.max_range;
  params.registration_voxel_size = options.registration_voxel_size;
  params.map_voxel_size = options.map_voxel_size;
  params.max_correspondences = options.max_correspondences;
  params.max_keyframes_in_map = options.max_keyframes_in_map;
  PointLio pipeline(params);
  const Eigen::Matrix4d world_anchor =
      gt.empty() ? Eigen::Matrix4d::Identity() : gt.front();
  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto pts = loadPCD(pcd_dirs[i] + "/cloud.pcd", options.input_voxel_size);
    if (pts.empty()) continue;
    pts = limitPoints(pts, options.max_input_points);
    if (pts.empty()) continue;

    std::vector<Eigen::Vector3d> filtered;
    filtered.reserve(pts.size());
    for (const auto& p : pts) {
      double r = p.norm();
      if (r >= options.min_range && r <= options.max_range) {
        filtered.push_back(p);
      }
    }

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(filtered, imu_batch);
    Eigen::Matrix4d pose = Eigen::Matrix4d::Identity();
    pose.block<3, 3>(0, 0) = result.state.rotation;
    pose.block<3, 1>(0, 3) = result.state.position;
    res.poses.push_back(anchorRelativePose(world_anchor, pose));
    if (i % 10 == 0) {
      std::cerr << "\r  [Point-LIO] " << i << "/" << pcd_dirs.size()
                << " kf=" << result.num_keyframes
                << " corr=" << result.num_correspondences
                << " imu=" << (result.imu_used ? "y" : "n")
                << " map=" << result.map_points;
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Point-level LiDAR-inertial odometry with error-state iterated Kalman filter "
      "(no GT seed; anchor matches first GT pose).";
  return res;
}

MethodResult runCLINS(const std::vector<std::string>& pcd_dirs,
                      const std::vector<Eigen::Matrix4d>& gt,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<ImuSampleCsv>& imu_samples,
                      const CLINSDogfoodingOptions& options) {
  using namespace localization_zoo::clins;
  using namespace localization_zoo::ct_lio;
  MethodResult res;
  res.name = "CLINS";

  CLINSParams params;
  CLINS pipeline(params);

  CTLIOState state;
  state.frame.begin_pose.trans = gt[0].block<3, 1>(0, 3);
  state.frame.begin_pose.quat = Eigen::Quaterniond(gt[0].block<3, 3>(0, 0));
  state.frame.end_pose = state.frame.begin_pose;
  res.poses.push_back(gt[0]);

  auto t0 = Clock::now();
  for (size_t i = 0; i < pcd_dirs.size(); i++) {
    auto scan = limitLoadedScan(
        loadTimedPCD(pcd_dirs[i] + "/cloud.pcd", options.source_voxel_size),
        options.max_source_points);
    if (scan.points.empty()) continue;

    std::vector<localization_zoo::ct_icp::TimedPoint> timed;
    timed.reserve(scan.points.size());
    const size_t denom = scan.points.size() > 1 ? scan.points.size() - 1 : 1;
    for (size_t j = 0; j < scan.points.size(); j++) {
      localization_zoo::ct_icp::TimedPoint tp;
      tp.raw_point = scan.points[j];
      tp.timestamp = scan.has_per_point_time ? scan.relative_times[j]
                                             : static_cast<double>(j) / denom;
      timed.push_back(tp);
    }

    std::vector<localization_zoo::imu_preintegration::ImuSample> imu_batch;
    if (i > 0 && !imu_samples.empty() && frame_timestamps.size() == pcd_dirs.size() &&
        i < frame_timestamps.size()) {
      imu_batch = selectImuWindow(imu_samples, frame_timestamps[i - 1],
                                  frame_timestamps[i]);
    }

    const auto result = pipeline.process(timed, imu_batch);

    Eigen::Matrix4d T = Eigen::Matrix4d::Identity();
    T.block<3, 3>(0, 0) = result.state.frame.end_pose.quat.toRotationMatrix();
    T.block<3, 1>(0, 3) = result.state.frame.end_pose.trans;
    if (i > 0) {
      res.poses.push_back(T);
    }

    if (i % 10 == 0) {
      std::cerr << "\r  [CLINS] " << i << "/" << pcd_dirs.size()
                << " map=" << result.map_size;
    }
  }
  std::cerr << std::endl;
  res.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
  res.note =
      "Continuous-time LiDAR-inertial SLAM with CT-LIO registration "
      "(GT-seeded initialization).";
  return res;
}

void savePosesKITTI(const std::vector<Eigen::Matrix4d>& poses, const std::string& path) {
  std::ofstream f(path);
  for (auto& T : poses) {
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 4; j++)
        f << std::setprecision(9) << T(i, j) << (i == 2 && j == 3 ? "\n" : " ");
  }
}

std::string sanitizeArtifactStem(std::string stem) {
  for (char& c : stem) {
    const unsigned char uc = static_cast<unsigned char>(c);
    if (!std::isalnum(uc) && c != '_' && c != '-') c = '_';
  }
  if (stem.empty()) return "dataset";
  return stem;
}

std::string artifactStemFromPath(const std::string& path_string) {
  const fs::path path(path_string);
  std::string stem = path.filename().string();
  if (stem.empty()) stem = path.parent_path().filename().string();
  return sanitizeArtifactStem(stem);
}

uint32_t sha256RotateRight(uint32_t value, uint32_t bits) {
  return (value >> bits) | (value << (32U - bits));
}

std::string sha256File(const std::string& path) {
  std::ifstream file(path, std::ios::binary);
  if (!file) {
    throw std::runtime_error("Failed to open file for SHA-256: " + path);
  }

  std::vector<uint8_t> data;
  char ch = 0;
  while (file.get(ch)) {
    data.push_back(static_cast<uint8_t>(ch));
  }
  const uint64_t bit_len = static_cast<uint64_t>(data.size()) * 8ULL;
  data.push_back(0x80U);
  while ((data.size() % 64U) != 56U) {
    data.push_back(0U);
  }
  for (int shift = 56; shift >= 0; shift -= 8) {
    data.push_back(static_cast<uint8_t>((bit_len >> shift) & 0xffU));
  }

  std::array<uint32_t, 8> h = {
      0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
      0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U};
  static const std::array<uint32_t, 64> k = {
      0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
      0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
      0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
      0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
      0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
      0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
      0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
      0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
      0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
      0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
      0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
      0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
      0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
      0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
      0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
      0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U};

  for (size_t offset = 0; offset < data.size(); offset += 64U) {
    std::array<uint32_t, 64> w = {};
    for (size_t i = 0; i < 16; i++) {
      const size_t j = offset + i * 4U;
      w[i] = (static_cast<uint32_t>(data[j]) << 24U) |
             (static_cast<uint32_t>(data[j + 1]) << 16U) |
             (static_cast<uint32_t>(data[j + 2]) << 8U) |
             static_cast<uint32_t>(data[j + 3]);
    }
    for (size_t i = 16; i < 64; i++) {
      const uint32_t s0 = sha256RotateRight(w[i - 15], 7U) ^
                          sha256RotateRight(w[i - 15], 18U) ^
                          (w[i - 15] >> 3U);
      const uint32_t s1 = sha256RotateRight(w[i - 2], 17U) ^
                          sha256RotateRight(w[i - 2], 19U) ^
                          (w[i - 2] >> 10U);
      w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }

    uint32_t a = h[0];
    uint32_t b = h[1];
    uint32_t c = h[2];
    uint32_t d = h[3];
    uint32_t e = h[4];
    uint32_t f = h[5];
    uint32_t g = h[6];
    uint32_t hh = h[7];

    for (size_t i = 0; i < 64; i++) {
      const uint32_t s1 = sha256RotateRight(e, 6U) ^
                          sha256RotateRight(e, 11U) ^
                          sha256RotateRight(e, 25U);
      const uint32_t ch_bits = (e & f) ^ ((~e) & g);
      const uint32_t temp1 = hh + s1 + ch_bits + k[i] + w[i];
      const uint32_t s0 = sha256RotateRight(a, 2U) ^
                          sha256RotateRight(a, 13U) ^
                          sha256RotateRight(a, 22U);
      const uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
      const uint32_t temp2 = s0 + maj;

      hh = g;
      g = f;
      f = e;
      e = d + temp1;
      d = c;
      c = b;
      b = a;
      a = temp1 + temp2;
    }

    h[0] += a;
    h[1] += b;
    h[2] += c;
    h[3] += d;
    h[4] += e;
    h[5] += f;
    h[6] += g;
    h[7] += hh;
  }

  std::ostringstream out;
  out << std::hex << std::setfill('0');
  for (const uint32_t word : h) {
    out << std::setw(8) << word;
  }
  return out.str();
}

std::string readFirstLineTrimmed(const fs::path& path) {
  std::ifstream file(path);
  std::string line;
  if (!std::getline(file, line)) return "";
  return trimCsvToken(line);
}

std::string readPackedGitRef(const fs::path& git_dir,
                             const std::string& ref_name) {
  std::ifstream file(git_dir / "packed-refs");
  std::string line;
  while (std::getline(file, line)) {
    line = trimCsvToken(line);
    if (line.empty() || line[0] == '#' || line[0] == '^') continue;
    std::istringstream ss(line);
    std::string commit;
    std::string ref;
    ss >> commit >> ref;
    if (ref == ref_name) return commit;
  }
  return "";
}

std::string evaluatorGitCommit() {
  std::error_code ec;
  fs::path dir = fs::current_path(ec);
  if (ec) return "";

  while (true) {
    const fs::path marker = dir / ".git";
    fs::path git_dir;
    if (fs::is_directory(marker, ec) && !ec) {
      git_dir = marker;
    } else if (fs::is_regular_file(marker, ec) && !ec) {
      const std::string gitdir_line = readFirstLineTrimmed(marker);
      const std::string prefix = "gitdir:";
      if (gitdir_line.rfind(prefix, 0) == 0) {
        git_dir = trimCsvToken(gitdir_line.substr(prefix.size()));
        if (git_dir.is_relative()) git_dir = dir / git_dir;
      }
    }

    if (!git_dir.empty()) {
      const std::string head = readFirstLineTrimmed(git_dir / "HEAD");
      const std::string ref_prefix = "ref:";
      if (head.rfind(ref_prefix, 0) == 0) {
        const std::string ref_name = trimCsvToken(head.substr(ref_prefix.size()));
        std::string commit = readFirstLineTrimmed(git_dir / ref_name);
        if (commit.empty()) commit = readPackedGitRef(git_dir, ref_name);
        return commit;
      }
      return head;
    }

    if (dir == dir.parent_path()) break;
    dir = dir.parent_path();
  }
  return "";
}

void writeJsonNumberOrNull(std::ostream& out, double value) {
  if (std::isfinite(value)) {
    out << std::fixed << std::setprecision(6) << value;
  } else {
    out << "null";
  }
}

void writeJsonStringOrNull(std::ostream& out, const std::string& value) {
  if (value.empty()) {
    out << "null";
  } else {
    out << "\"" << jsonEscape(value) << "\"";
  }
}

void writeJsonRangeOrNull(std::ostream& out, double first, double last) {
  if (std::isfinite(first) && std::isfinite(last)) {
    out << "[";
    writeJsonNumberOrNull(out, first);
    out << ", ";
    writeJsonNumberOrNull(out, last);
    out << "]";
  } else {
    out << "null";
  }
}

void writeSummaryJson(const std::string& path,
                      const std::string& pcd_dir,
                      const std::string& gt_csv,
                      const std::string& gt_sha256,
                      const std::string& evaluated_gt_path,
                      const std::string& legacy_gt_path,
                      bool legacy_gt_written,
                      const std::string& evaluation_manifest_path,
                      const std::string& evaluator_git_commit,
                      size_t total_pcd_frames,
                      size_t num_frames,
                      size_t raw_gt_pose_count,
                      const std::vector<double>& frame_timestamps,
                      const std::vector<GTPose>& gt_poses_raw,
                      const GTAssociation& gt_association,
                      double trajectory_length_m,
                      FrameTimestampSource frame_timestamp_source,
                      const std::string& gt_format,
                      TimeDomain gt_time_domain,
                      double association_max_dt,
                      const std::vector<MethodResult>& results) {
  std::ofstream out(path);
  const size_t used_gt_pose_count =
      gt_association.gt_indices.empty() ? gt_association.poses.size()
                                        : gt_association.gt_indices.size();
  const bool has_frame_timestamps = !frame_timestamps.empty();
  const bool has_raw_gt = !gt_poses_raw.empty();
  const bool has_associated_indices = !gt_association.gt_indices.empty();
  double associated_first_ts = std::numeric_limits<double>::quiet_NaN();
  double associated_last_ts = std::numeric_limits<double>::quiet_NaN();
  size_t associated_first_index = 0;
  size_t associated_last_index = 0;
  if (has_associated_indices) {
    associated_first_index = gt_association.gt_indices.front();
    associated_last_index = gt_association.gt_indices.back();
    associated_first_ts = gt_poses_raw[associated_first_index].timestamp;
    associated_last_ts = gt_poses_raw[associated_last_index].timestamp;
  }
  const double rpe_segment_length_m = rpeSegmentLengthM(trajectory_length_m);

  out << "{\n";
  out << "  \"schema_version\": 2,\n";
  out << "  \"pcd_dir\": \"" << jsonEscape(pcd_dir) << "\",\n";
  out << "  \"gt_csv\": \"" << jsonEscape(gt_csv) << "\",\n";
  out << "  \"gt_sha256\": \"" << jsonEscape(gt_sha256) << "\",\n";
  out << "  \"input_max_range_m\": " << g_input_max_range_m << ",\n";
  if (g_input_min_range_m > 0.0) {
    out << "  \"input_min_range_m\": " << g_input_min_range_m << ",\n";
  }
  out << "  \"input_vertical_angle_correction_deg\": "
      << g_input_vertical_angle_correction_rad * (180.0 / std::acos(-1.0))
      << ",\n";
  out << "  \"input_azimuth_time\": "
      << (g_input_azimuth_time ? "true" : "false") << ",\n";
  if (g_input_sensor_pose_set) {
    out << "  \"input_sensor_pose\": [";
    for (int r = 0; r < 3; ++r) {
      for (int c = 0; c < 4; ++c) {
        out << (r || c ? ", " : "") << g_input_sensor_pose(r, c);
      }
    }
    out << "],\n";
  }
  out << "  \"total_pcd_frames\": " << total_pcd_frames << ",\n";
  out << "  \"num_frames\": " << num_frames << ",\n";
  out << "  \"raw_gt_pose_count\": " << raw_gt_pose_count << ",\n";
  out << "  \"used_gt_pose_count\": " << used_gt_pose_count << ",\n";
  out << "  \"trajectory_length_m\": " << std::fixed << std::setprecision(6)
      << trajectory_length_m << ",\n";
  out << "  \"timestamp_source\": \""
      << jsonEscape(frameTimestampSourceName(frame_timestamp_source)) << "\",\n";
  out << "  \"gt_format\": \"" << jsonEscape(gt_format) << "\",\n";
  out << "  \"gt_time_domain\": \""
      << jsonEscape(timeDomainName(gt_time_domain)) << "\",\n";
  out << "  \"association_mode\": \""
      << jsonEscape(gt_association.mode) << "\",\n";
  out << "  \"association_max_dt_s\": ";
  writeJsonNumberOrNull(out, association_max_dt);
  out << ",\n";
  out << "  \"evaluator_git_commit\": ";
  writeJsonStringOrNull(out, evaluator_git_commit);
  out << ",\n";
  out << "  \"artifacts\": {\n";
  out << "    \"evaluated_gt_path\": \""
      << jsonEscape(evaluated_gt_path) << "\",\n";
  out << "    \"legacy_gt_path\": \"" << jsonEscape(legacy_gt_path) << "\",\n";
  out << "    \"legacy_gt_written\": "
      << (legacy_gt_written ? "true" : "false") << ",\n";
  out << "    \"evaluation_manifest_path\": \""
      << jsonEscape(evaluation_manifest_path) << "\"\n";
  out << "  },\n";
  out << "  \"frames\": {\n";
  out << "    \"timestamp_source\": \""
      << jsonEscape(frameTimestampSourceName(frame_timestamp_source)) << "\",\n";
  out << "    \"timestamp_count\": " << frame_timestamps.size() << ",\n";
  out << "    \"timestamp_all_integer\": "
      << (allFiniteIntegers(frame_timestamps) ? "true" : "false") << ",\n";
  out << "    \"timestamp_range\": ";
  if (has_frame_timestamps) {
    writeJsonRangeOrNull(out, frame_timestamps.front(), frame_timestamps.back());
  } else {
    out << "null";
  }
  out << "\n";
  out << "  },\n";
  out << "  \"gt\": {\n";
  out << "    \"source\": \"" << jsonEscape(gt_csv) << "\",\n";
  out << "    \"sha256\": \"" << jsonEscape(gt_sha256) << "\",\n";
  out << "    \"format\": \"" << jsonEscape(gt_format) << "\",\n";
  out << "    \"time_domain\": \""
      << jsonEscape(timeDomainName(gt_time_domain)) << "\",\n";
  out << "    \"raw_pose_count\": " << raw_gt_pose_count << ",\n";
  out << "    \"raw_timestamp_range\": ";
  if (has_raw_gt) {
    writeJsonRangeOrNull(out, gt_poses_raw.front().timestamp,
                         gt_poses_raw.back().timestamp);
  } else {
    out << "null";
  }
  out << "\n";
  out << "  },\n";
  out << "  \"association\": {\n";
  out << "    \"mode\": \"" << jsonEscape(gt_association.mode) << "\",\n";
  out << "    \"max_dt_s\": ";
  writeJsonNumberOrNull(out, association_max_dt);
  out << ",\n";
  out << "    \"used_gt_pose_count\": " << used_gt_pose_count << ",\n";
  out << "    \"associated_gt_index_range\": ";
  if (has_associated_indices) {
    out << "[" << associated_first_index << ", " << associated_last_index << "]";
  } else {
    out << "null";
  }
  out << ",\n";
  out << "    \"associated_gt_timestamp_range\": ";
  writeJsonRangeOrNull(out, associated_first_ts, associated_last_ts);
  out << ",\n";
  out << "    \"gt_normalization\": \"first_associated_gt_inverse_applied_before_metrics\"\n";
  out << "  },\n";
  out << "  \"metric_config\": {\n";
  out << "    \"ate\": {\n";
  out << "      \"alignment\": \"none\",\n";
  out << "      \"definition\": \"absolute_position_rmse_m\"\n";
  out << "    },\n";
  out << "    \"rpe\": {\n";
  out << "      \"alignment\": \"none\",\n";
  out << "      \"segment_length_m\": ";
  writeJsonNumberOrNull(out, rpe_segment_length_m);
  out << ",\n";
  out << "      \"translation_unit\": \"percent\",\n";
  out << "      \"rotation_unit\": \"deg_per_m\"\n";
  out << "    }\n";
  out << "  },\n";
  out << "  \"methods\": [\n";
  for (size_t i = 0; i < results.size(); i++) {
    const auto& r = results[i];
    out << "    {\n";
    out << "      \"name\": \"" << jsonEscape(r.name) << "\",\n";
    out << "      \"status\": \"" << jsonEscape(r.status) << "\",\n";
    if (r.skipped) {
      out << "      \"ate_m\": null,\n";
      out << "      \"rpe_trans_pct\": null,\n";
      out << "      \"rpe_rot_deg_per_m\": null,\n";
      out << "      \"kitti_rte_trans_pct\": null,\n";
      out << "      \"kitti_rte_rot_deg_per_100m\": null,\n";
      out << "      \"frames\": 0,\n";
      out << "      \"time_ms\": null,\n";
      out << "      \"fps\": null,\n";
      out << "      \"algorithm_time_ms\": null,\n";
      out << "      \"algorithm_fps\": null,\n";
      out << "      \"seed_fallback_rate_pct\": null,\n";
    } else {
      const double fps =
          r.time_ms > 0.0 ? r.poses.size() / (r.time_ms / 1000.0) : 0.0;
      out << "      \"ate_m\": ";
      writeJsonNumberOrNull(out, r.ate);
      out << ",\n";
      if (r.has_rpe) {
        out << "      \"rpe_trans_pct\": ";
        writeJsonNumberOrNull(out, r.rpe_trans_pct);
        out << ",\n";
        out << "      \"rpe_rot_deg_per_m\": ";
        writeJsonNumberOrNull(out, r.rpe_rot_deg_per_m);
        out << ",\n";
      } else {
        out << "      \"rpe_trans_pct\": null,\n";
        out << "      \"rpe_rot_deg_per_m\": null,\n";
      }
      if (r.kitti_rte.available) {
        out << "      \"kitti_rte_trans_pct\": ";
        writeJsonNumberOrNull(out, r.kitti_rte.trans_pct);
        out << ",\n";
        out << "      \"kitti_rte_rot_deg_per_100m\": ";
        writeJsonNumberOrNull(out, r.kitti_rte.rot_deg_per_100m);
        out << ",\n";
      } else {
        out << "      \"kitti_rte_trans_pct\": null,\n";
        out << "      \"kitti_rte_rot_deg_per_100m\": null,\n";
      }
      out << "      \"frames\": " << r.poses.size() << ",\n";
      out << "      \"time_ms\": ";
      writeJsonNumberOrNull(out, r.time_ms);
      out << ",\n";
      out << "      \"fps\": ";
      writeJsonNumberOrNull(out, fps);
      out << ",\n";
      out << "      \"algorithm_time_ms\": ";
      writeJsonNumberOrNull(
          out, r.algorithm_time_ms > 0.0
                   ? r.algorithm_time_ms
                   : std::numeric_limits<double>::quiet_NaN());
      out << ",\n";
      out << "      \"algorithm_fps\": ";
      writeJsonNumberOrNull(
          out, r.algorithm_time_ms > 0.0
                   ? r.poses.size() / (r.algorithm_time_ms / 1000.0)
                   : std::numeric_limits<double>::quiet_NaN());
      out << ",\n";
      out << "      \"seed_fallback_rate_pct\": ";
      if (r.seed_fallback_rate_pct >= 0.0) {
        writeJsonNumberOrNull(out, r.seed_fallback_rate_pct);
      } else {
        out << "null";
      }
      out << ",\n";
    }
    out << "      \"note\": \"" << jsonEscape(r.note) << "\"\n";
    out << "    }" << (i + 1 == results.size() ? "\n" : ",\n");
  }
  out << "  ]\n";
  out << "}\n";
}

int main(int argc, char** argv) {
  if (argc < 3) {
    std::cerr << "Usage: " << argv[0]
              << " <pcd_dir> <gt_csv> [max_frames] [--force-ct-lio]"
              << " [--methods litamin2,gicp,small_gicp,voxel_gicp,ndt,kiss_icp,kiss_multi_horizon,kiss_pose_graph,kiss_pose_graph_causal,genz_icp,lf_gicp,l_lo,adaptive_icp,d2lio,ct_voxelmap,cube_lio,r_voxelmap,degen_sense,vibration_lio,id_lio,rf_lio,bievr_lio,ua_lio,damm_loam,lodestar,terrain_rbf_lio,lidar_iba,dali_slam,intensity_flow,svn_icp,pcr_dat,small_mighty,m_gclo,quadric_lo,dilo,nhc_lio,student_t_lo,spectral_lo,gmm_lo,gnc_lo,mcc_lo,imls_slam,mesh_loam,elo,tc_lvgf,opl_lvio,v_loam15,tc_vlo,ad_vlo,tc_mvlo,tricp_lo,kc_lo,i_loam,pl_loam,inten_loam,mcgicp,icpsc,vlom,odonet,nhc_net,nn_zupt,imu_dead_reckoning,dlo,dlio,aloam,floam,"
              << "lego_loam,mulls,ct_lio,ct_icp,ct_icp_ndt,ct_icp_ndt_keyframe,fixed_map_ndt,suma,balm2,isc_loam,loam_livox,lio_sam,lins,"
              << "fast_lio_slam,point_lio,clins]"
              << " [--summary-json path]"
              << " [--inten-loam-paper-trace-jsonl new_file.jsonl]"
              << " [--paper-pipeline-accelerated]"
              << " [--association-mode strict|legacy-auto]"
              << " [--association-max-dt seconds]"
              << " [--allow-legacy-gt-artifact]"
              << " [--litamin2-paper-profile]"
              << " [--litamin2-icp-only]"
              << " [--litamin2-covariance-gradient]"
              << " [--litamin2-covariance-gradient-weight X]"
              << " [--litamin2-line-search]"
              << " [--litamin2-line-search-min-step X]"
              << " [--litamin2-scan-to-scan]"
              << " [--litamin2-coarse-to-fine-voxels csv]"
              << " [--litamin2-coarse-to-fine-iterations csv]"
              << " [--litamin2-voxel-resolution X]"
              << " [--litamin2-max-iterations N]"
              << " [--litamin2-max-source-points N]"
              << " [--litamin2-refresh-interval N]"
              << " [--litamin2-map-max-points N]"
              << " [--litamin2-map-radius X]"
              << " [--litamin2-local-map-policy refresh|accumulate|keyframe]"
              << " [--litamin2-keyframe-translation X]"
              << " [--litamin2-keyframe-rotation X]"
              << " [--litamin2-max-seed-translation-delta X]"
              << " [--litamin2-max-seed-rotation-delta X]"
              << " [--litamin2-max-motion-translation-delta X]"
              << " [--litamin2-max-motion-rotation-delta X]"
              << " [--litamin2-min-cov-eigenvalue X]"
              << " [--litamin2-correspondence-search-radius N]"
              << " [--litamin2-max-correspondence-distance X]"
              << " [--litamin2-num-threads N]"
              << " [--gicp-fast-profile]"
              << " [--gicp-dense-profile]"
              << " [--gicp-k-neighbors N]"
              << " [--gicp-max-iterations N]"
              << " [--aloam-kitti-profile]"
              << " [--aloam-fast-profile]"
              << " [--aloam-dense-profile]"
              << " [--floam-kitti-profile]"
              << " [--floam-fast-profile]"
              << " [--floam-dense-profile]"
              << " [--lego-loam-kitti-profile]"
              << " [--lego-loam-fast-profile]"
              << " [--lego-loam-dense-profile]"
              << " [--mulls-kitti-profile] [--mulls-lo] [--mulls-lo-disable a,b] [--mulls-lo-highway]"
              << " [--mulls-fast-profile]"
              << " [--mulls-dense-profile]"
              << " [--dlo-kitti-profile]"
              << " [--dlo-fast-profile]"
              << " [--dlo-dense-profile]"
              << " [--dlio-kitti-profile]"
              << " [--dlio-fast-profile]"
              << " [--dlio-dense-profile]"
              << " [--small-gicp-fast-profile]"
              << " [--small-gicp-dense-profile]"
              << " [--voxel-gicp-fast-profile]"
              << " [--voxel-gicp-dense-profile]"
              << " [--voxel-gicp-voxel-resolution X]"
              << " [--voxel-gicp-min-points-per-voxel N]"
              << " [--voxel-gicp-max-correspondence-distance X]"
              << " [--voxel-gicp-max-iterations N]"
              << " [--small-gicp-voxel-resolution X]"
              << " [--small-gicp-k-neighbors N]"
              << " [--small-gicp-max-correspondence-distance X]"
              << " [--small-gicp-max-correspondences N]"
              << " [--small-gicp-max-iterations N]"
              << " [--small-gicp-max-seed-translation-delta M]"
              << " [--small-gicp-max-seed-rotation-delta-rad R]"
              << " [--ndt-fast-profile]"
              << " [--ndt-dense-profile]"
              << " [--ndt-resolution X]"
              << " [--ndt-max-iterations N]"
              << " [--fixed-map-ndt-seed-source gt|velocity|ct_icp|scan_context]"
              << " [--fixed-map-ndt-map-ply path]"
              << " [--fixed-map-ndt-map-stride N]"
              << " [--fixed-map-ndt-scan-context-threshold X]"
              << " [--fixed-map-ndt-scan-context-top-k N]"
              << " [--fixed-map-ndt-trace-json path]"
              << " [--fixed-map-ndt-publish-min-stable-frames N]"
              << " [--fixed-map-ndt-publish-max-hold-frames N]"
              << " [--fixed-map-ndt-scan-context-relock-min-confirmations N]"
              << " [--fixed-map-ndt-scan-context-relock-max-distance X]"
              << " [--fixed-map-ndt-scan-context-relock-max-ndt-score X]"
              << " [--fixed-map-ndt-scan-context-relock-max-score-delta X]"
              << " [--kiss-fast-profile] [--kiss-upstream-profile]"
              << " [--kiss-dense-profile]"
              << " [--kiss-legacy-27-neighborhood]"
              << " [--lf-gicp-no-mitigation] [--lf-gicp-beta X] [--lf-gicp-field-beta X] [--l-lo-set key=value]..."
               << " [--kiss-pg-scan-context-threshold X]"
               << " [--kiss-pg-correction-gain X]"
               << " [--kiss-pg-external-poses KITTI_POSES]"
              << " [--kiss-voxel-size X]"
              << " [--kiss-max-iterations N]"
              << " [--kiss-model-deviation-threshold]"
              << " [--kiss-geman-mcclure-kernel] [--kiss-map-min-point-distance X]"
              << " [--kiss-model-deviation-correspondence-multiplier X]"
              << " [--kiss-vertical-angle-correction-deg X]"
              << " [--input-vertical-angle-correction-deg X]"
              << " [--input-max-range-m X] [--input-azimuth-time]"
              << " [--kiss-deskew-mulran]"
              << " [--kiss-motion-guard]"
              << " [--kiss-diverse-voxel-points]"
              << " [--kiss-max-step-translation-m X]"
              << " [--kiss-max-step-rotation-deg X]"
              << " [--ct-icp-fast-profile]"
              << " [--ct-icp-dense-profile] [--ct-icp-upstream-mechanics]"
              << " [--ct-icp-upstream-disable a,b,...]"
              << " [--ct-icp-voxel-resolution X]"
              << " [--ct-icp-max-iterations N]"
              << " [--ct-icp-auto-regularizer-cap]"
              << " [--ct-icp-ndt-keyframe-interval N]"
              << " [--ct-icp-ndt-max-correction-translation M]"
              << " [--ct-icp-ndt-max-correction-rotation-rad R]"
              << " [--ct-icp-ndt-max-score S]"
              << " [--xicp-fast-profile]"
              << " [--xicp-dense-profile]"
              << " [--fast-lio2-fast-profile]"
              << " [--fast-lio2-dense-profile]"
              << " [--hdl-graph-slam-fast-profile]"
              << " [--hdl-graph-slam-dense-profile]"
              << " [--vgicp-slam-fast-profile]"
              << " [--vgicp-slam-dense-profile]"
              << " [--suma-fast-profile]"
              << " [--suma-dense-profile]"
              << " [--balm2-fast-profile]"
              << " [--balm2-dense-profile]"
              << " [--isc-loam-fast-profile]"
              << " [--isc-loam-dense-profile]"
              << " [--loam-livox-fast-profile]"
              << " [--loam-livox-dense-profile]"
              << " [--lio-sam-fast-profile]"
              << " [--lio-sam-dense-profile]"
              << " [--lins-fast-profile]"
              << " [--lins-dense-profile]"
               << " [--fast-lio-slam-fast-profile]"
               << " [--fast-lio-slam-dense-profile]"
               << " [--point-lio-fast-profile]"
               << " [--point-lio-dense-profile]"
               << " [--clins-fast-profile]"
               << " [--clins-dense-profile]"
               << " [--ct-lio-estimate-bias]"
               << " [--ct-lio-fixed-lag-window N]"
              << " [--ct-lio-fixed-lag-velocity-weight W]"
              << " [--ct-lio-fixed-lag-gyro-bias-scale W]"
              << " [--ct-lio-fixed-lag-accel-bias-scale W]"
              << " [--ct-lio-fixed-lag-history-decay W]"
              << " [--ct-lio-fixed-lag-outer-iterations N]"
              << " [--ct-lio-fixed-lag-smoother]"
              << " [--pl-loam-depth-pseudo-image]"
              << " [--pl-loam-intensity-dilation N]"
              << " [--vlom-enable-bootstrap]"
              << " [--vlom-no-bootstrap]"
              << " [--vlom-no-scale]"
              << " [--vlom-depth-pseudo-image]"
              << " [--vlom-intensity-dilation N]"
              << " [--seed-perturb-x M] [--seed-perturb-y M]"
              << " [--seed-perturb-z M] [--seed-perturb-yaw-deg DEG]"
              << " [--no-gt-seed] [--ct-icp-gt-seed]" << std::endl;
    return 1;
  }

  std::string pcd_dir = argv[1];
  std::string gt_csv = argv[2];
  int max_frames = -1;
  bool force_ct_lio = false;
  bool no_gt_seed = false;
  bool ct_icp_gt_seed = false;
  SeedPerturbation seed_perturbation;
  bool ct_lio_estimate_bias = false;
  bool ct_lio_multi_scale = false;
  bool ct_lio_coarse_to_fine = false;
  int ct_lio_coarse_iterations = 2;
  int ct_lio_coarse_search_radius = 2;
  double ct_lio_coarse_planarity_threshold = 0.02;
  double ct_lio_coarse_cauchy_mult = 2.0;
  bool ct_lio_bspline = false;
  double ct_lio_bspline_anchor_weight = 500.0;
  int ct_lio_max_frames_in_map = 10;
  int ct_lio_max_iterations = 6;
  std::string summary_json_path;
  bool legacy_auto_association = false;
  bool allow_legacy_gt_artifact = false;
  double association_max_dt = 0.05;
  int ct_lio_fixed_lag_window = 1;
  double ct_lio_fixed_lag_velocity_weight = 0.0;
  double ct_lio_fixed_lag_gyro_bias_scale = 0.25;
  double ct_lio_fixed_lag_accel_bias_scale = 0.25;
  double ct_lio_fixed_lag_history_decay = 1.0;
  int ct_lio_fixed_lag_outer_iterations = 3;
  bool ct_lio_fixed_lag_smoother = false;
  LiTAMIN2DogfoodingOptions litamin2_options;
  GICPDogfoodingOptions gicp_options;
  SmallGICPDogfoodingOptions small_gicp_options;
  VoxelGICPDogfoodingOptions voxel_gicp_options;
  ALOAMDogfoodingOptions aloam_options;
  FLOAMDogfoodingOptions floam_options;
  ILoamDogfoodingOptions i_loam_options;
  PlLoamDogfoodingOptions pl_loam_options;
  InTenLoamDogfoodingOptions inten_loam_options;
  McGicpLoDogfoodingOptions mcgicp_options;
  IcpscLoDogfoodingOptions icpsc_options;
  VlomDogfoodingOptions vlom_options;
  OdoNetDogfoodingOptions odonet_options;
  NhcNetDogfoodingOptions nhc_net_options;
  NnZuptDogfoodingOptions nn_zupt_options;
  ImuDeadReckoningDogfoodingOptions imu_dead_reckoning_options;
  LeGOLOAMDogfoodingOptions lego_loam_options;
  MULLSDogfoodingOptions mulls_options;
  NDTDogfoodingOptions ndt_options;
  FixedMapNDTOptions fixed_map_ndt_options;
  KISSICPDogfoodingOptions kiss_icp_options;
  KISSMultiHorizonDogfoodingOptions kiss_multi_horizon_options;
  double kiss_pose_graph_scan_context_threshold = 0.18;
  double kiss_pose_graph_correction_gain = 0.05;
  std::string kiss_pose_graph_external_pose_path;
  GenZICPDogfoodingOptions genz_icp_options;
  LFGICPDogfoodingOptions lf_gicp_options;
  localization_zoo::l_lo::LLOParams l_lo_params;
  AdaptiveICPDogfoodingOptions adaptive_icp_options;
  D2LIODogfoodingOptions d2lio_options;
  CTVoxelMapDogfoodingOptions ct_voxelmap_options;
  RVoxelMapDogfoodingOptions r_voxelmap_options;
  DammLoamDogfoodingOptions damm_loam_options;
  LodestarDogfoodingOptions lodestar_options;
  TerrainRbfDogfoodingOptions terrain_rbf_options;
  LidarIbaDogfoodingOptions lidar_iba_options;
  DaliSlamDogfoodingOptions dali_slam_options;
  IntensityFlowDogfoodingOptions intensity_flow_options;
  SvnIcpDogfoodingOptions svn_icp_options;
  PcrDatDogfoodingOptions pcr_dat_options;
  SmallMightyDogfoodingOptions small_mighty_options;
  MGcloDogfoodingOptions m_gclo_options;
  QuadricLoDogfoodingOptions quadric_lo_options;
  DiloDogfoodingOptions dilo_options;
  NhcLioDogfoodingOptions nhc_lio_options;
  StudentTLoDogfoodingOptions student_t_lo_options;
  SpectralLoDogfoodingOptions spectral_lo_options;
  GmmLoDogfoodingOptions gmm_lo_options;
  GncLoDogfoodingOptions gnc_lo_options;
  MccLoDogfoodingOptions mcc_lo_options;
  ImlsSlamDogfoodingOptions imls_slam_options;
  MeshLoamDogfoodingOptions mesh_loam_options;
  EloDogfoodingOptions elo_options;
  TcLvgfDogfoodingOptions tc_lvgf_options;
  OplLvioDogfoodingOptions opl_lvio_options;
  VisualLidarAdapterDogfoodingOptions v_loam15_options;
  VisualLidarAdapterDogfoodingOptions tc_vlo_options;
  VisualLidarAdapterDogfoodingOptions ad_vlo_options;
  VisualLidarAdapterDogfoodingOptions tc_mvlo_options;
  TricpLoDogfoodingOptions tricp_lo_options;
  KcLoDogfoodingOptions kc_lo_options;
  DegenSenseDogfoodingOptions degen_sense_options;
  VibrationLIODogfoodingOptions vibration_lio_options;
  IDLIODogfoodingOptions id_lio_options;
  RFLIODogfoodingOptions rf_lio_options;
  BievrLIODogfoodingOptions bievr_lio_options;
  UALIODogfoodingOptions ua_lio_options;
  CubeLIODogfoodingOptions cube_lio_options;
  RKOLIODogfoodingOptions rko_lio_options;
  FRLIODogfoodingOptions fr_lio_options;
  PGLIODogfoodingOptions pg_lio_options;
  CTICPDogfoodingOptions ct_icp_options;
  CTICPNDTHybridOptions ct_icp_ndt_options;
  DLODofeedingOptions dlo_options;
  DLIODogfoodingOptions dlio_options;
  XICPDogfoodingOptions xicp_options;
  FastLio2DogfoodingOptions fast_lio2_options;
  HdlGraphSlamDogfoodingOptions hdl_graph_slam_options;
  VgicpSlamDogfoodingOptions vgicp_slam_options;
  SuMaDogfoodingOptions suma_options;
  Balm2DogfoodingOptions balm2_options;
  IscLoamDogfoodingOptions isc_loam_options;
  LoamLivoxDogfoodingOptions loam_livox_options;
  LioSamDogfoodingOptions lio_sam_options;
  LINSDogfoodingOptions lins_options;
  FastLioSlamDogfoodingOptions fast_lio_slam_options;
  PointLioDogfoodingOptions point_lio_options;
  CLINSDogfoodingOptions clins_options;
  std::vector<std::string> selected_methods = {
      "litamin2", "gicp", "small_gicp", "aloam", "floam", "ndt", "kiss_icp",
      "ct_lio"};
  for (int i = 3; i < argc; i++) {
    std::string arg = argv[i];
    if (arg == "--force-ct-lio") {
      force_ct_lio = true;
      continue;
    }
    if (arg == "--no-gt-seed") {
      no_gt_seed = true;
      continue;
    }
    if (arg == "--input-max-range-m") {
      if (i + 1 >= argc) {
        std::cerr << "--input-max-range-m requires a value" << std::endl;
        return 1;
      }
      g_input_max_range_m = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--input-min-range-m") {
      if (i + 1 >= argc) {
        std::cerr << "--input-min-range-m requires a value" << std::endl;
        return 1;
      }
      g_input_min_range_m = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--input-azimuth-time") {
      g_input_azimuth_time = true;
      continue;
    }
    if (arg == "--input-sensor-pose") {
      if (i + 6 >= argc) {
        std::cerr << "--input-sensor-pose requires x y z roll pitch yaw "
                     "(m, deg)" << std::endl;
        return 1;
      }
      GTPose pose{};
      const double deg = std::acos(-1.0) / 180.0;
      pose.x = std::stod(argv[++i]);
      pose.y = std::stod(argv[++i]);
      pose.z = std::stod(argv[++i]);
      pose.roll = std::stod(argv[++i]) * deg;
      pose.pitch = std::stod(argv[++i]) * deg;
      pose.yaw = std::stod(argv[++i]) * deg;
      g_input_sensor_pose = pose.toMatrix();
      g_input_sensor_pose_set = true;
      continue;
    }
    if (arg == "--input-vertical-angle-correction-deg") {
      if (i + 1 >= argc) {
        std::cerr << "--input-vertical-angle-correction-deg requires a value"
                  << std::endl;
        return 1;
      }
      g_input_vertical_angle_correction_rad =
          std::stod(argv[++i]) * (std::acos(-1.0) / 180.0);
      continue;
    }
    if (arg == "--ct-icp-gt-seed") {
      ct_icp_gt_seed = true;
      continue;
    }
    if (arg == "--allow-legacy-gt-artifact") {
      allow_legacy_gt_artifact = true;
      continue;
    }
    if (arg == "--association-mode") {
      if (i + 1 >= argc) {
        std::cerr << "--association-mode requires strict or legacy-auto"
                  << std::endl;
        return 1;
      }
      const std::string mode = argv[++i];
      if (mode == "strict") {
        legacy_auto_association = false;
      } else if (mode == "legacy-auto") {
        legacy_auto_association = true;
      } else {
        std::cerr << "Unsupported --association-mode: " << mode
                  << " (supported: strict, legacy-auto)" << std::endl;
        return 1;
      }
      continue;
    }
    if (arg.rfind("--association-mode=", 0) == 0) {
      const std::string mode =
          arg.substr(std::string("--association-mode=").size());
      if (mode == "strict") {
        legacy_auto_association = false;
      } else if (mode == "legacy-auto") {
        legacy_auto_association = true;
      } else {
        std::cerr << "Unsupported --association-mode: " << mode
                  << " (supported: strict, legacy-auto)" << std::endl;
        return 1;
      }
      continue;
    }
    if (arg == "--association-max-dt") {
      if (i + 1 >= argc) {
        std::cerr << "--association-max-dt requires seconds" << std::endl;
        return 1;
      }
      association_max_dt = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--association-max-dt=", 0) == 0) {
      association_max_dt =
          std::stod(arg.substr(std::string("--association-max-dt=").size()));
      continue;
    }
    if (arg == "--seed-perturb-x") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      seed_perturbation.x = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--seed-perturb-x=", 0) == 0) {
      seed_perturbation.x =
          std::stod(arg.substr(std::string("--seed-perturb-x=").size()));
      continue;
    }
    if (arg == "--seed-perturb-y") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      seed_perturbation.y = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--seed-perturb-y=", 0) == 0) {
      seed_perturbation.y =
          std::stod(arg.substr(std::string("--seed-perturb-y=").size()));
      continue;
    }
    if (arg == "--seed-perturb-z") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      seed_perturbation.z = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--seed-perturb-z=", 0) == 0) {
      seed_perturbation.z =
          std::stod(arg.substr(std::string("--seed-perturb-z=").size()));
      continue;
    }
    if (arg == "--seed-perturb-yaw-deg") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      seed_perturbation.yaw_rad = std::stod(argv[++i]) * M_PI / 180.0;
      continue;
    }
    if (arg.rfind("--seed-perturb-yaw-deg=", 0) == 0) {
      seed_perturbation.yaw_rad = std::stod(arg.substr(
          std::string("--seed-perturb-yaw-deg=").size())) * M_PI / 180.0;
      continue;
    }
    if (arg == "--ct-lio-multi-scale") {
      ct_lio_multi_scale = true;
      continue;
    }
    if (arg == "--ct-lio-coarse-to-fine") {
      ct_lio_coarse_to_fine = true;
      continue;
    }
    if (arg == "--ct-lio-coarse-iterations") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_coarse_iterations = std::max(0, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-lio-coarse-search-radius") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_coarse_search_radius = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-lio-coarse-planarity-threshold") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_coarse_planarity_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-lio-coarse-cauchy-mult") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_coarse_cauchy_mult = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-lio-bspline") {
      ct_lio_bspline = true;
      continue;
    }
    if (arg == "--ct-lio-bspline-anchor-weight") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_bspline_anchor_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-lio-max-frames-in-map") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_max_frames_in_map = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-lio-max-iterations") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_lio_max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-lio-estimate-bias") {
      ct_lio_estimate_bias = true;
      continue;
    }
    if (arg == "--paper-pipeline-accelerated") {
      imls_slam_options.paper_accelerated = true;
      inten_loam_options.paper_accelerated = true;
      continue;
    }
    if (arg == "--summary-json") {
      if (i + 1 >= argc) {
        std::cerr << "--summary-json requires a path" << std::endl;
        return 1;
      }
      summary_json_path = argv[++i];
      continue;
    }
    if (arg.rfind("--summary-json=", 0) == 0) {
      summary_json_path = arg.substr(std::string("--summary-json=").size());
      continue;
    }
    if (arg == "--litamin2-paper-profile") {
      litamin2_options.voxel_resolution = 3.0;
      litamin2_options.max_iterations = 8;
      litamin2_options.use_cov_cost = true;
      litamin2_options.map_max_points = 25000;
      litamin2_options.refresh_interval = 2;
      litamin2_options.map_radius = 35.0;
      continue;
    }
    if (arg == "--litamin2-icp-only") {
      litamin2_options.use_cov_cost = false;
      continue;
    }
    if (arg == "--litamin2-covariance-gradient") {
      litamin2_options.optimize_covariance_cost = true;
      continue;
    }
    if (arg == "--litamin2-covariance-gradient-weight") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-covariance-gradient-weight requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.covariance_gradient_weight =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-covariance-gradient-weight=", 0) == 0) {
      litamin2_options.covariance_gradient_weight = std::max(
          0.0, std::stod(arg.substr(
                     std::string("--litamin2-covariance-gradient-weight=").size())));
      continue;
    }
    if (arg == "--litamin2-line-search") {
      litamin2_options.enable_line_search = true;
      continue;
    }
    if (arg == "--litamin2-line-search-min-step") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-line-search-min-step requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.line_search_min_step =
          std::clamp(std::stod(argv[++i]), 1e-4, 1.0);
      continue;
    }
    if (arg.rfind("--litamin2-line-search-min-step=", 0) == 0) {
      litamin2_options.line_search_min_step = std::clamp(
          std::stod(arg.substr(
              std::string("--litamin2-line-search-min-step=").size())),
          1e-4, 1.0);
      continue;
    }
    if (arg == "--litamin2-paper-odometry") {
      litamin2_options.paper_odometry = true;
      continue;
    }
    if (arg == "--litamin2-paper-voxel-size" && i + 1 < argc) {
      litamin2_options.paper_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--litamin2-paper-min-points" && i + 1 < argc) {
      litamin2_options.paper_min_points = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--litamin2-paper-max-iterations" && i + 1 < argc) {
      litamin2_options.paper_max_iterations = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--litamin2-paper-map-radius" && i + 1 < argc) {
      litamin2_options.paper_map_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--litamin2-paper-map-mode" && i + 1 < argc) {
      litamin2_options.paper_map_mode = argv[++i];
      continue;
    }
    if (arg == "--litamin2-scan-to-scan") {
      litamin2_options.scan_to_scan = true;
      continue;
    }
    if (arg == "--litamin2-coarse-to-fine-voxels") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-coarse-to-fine-voxels requires a comma-separated list"
                  << std::endl;
        return 1;
      }
      litamin2_options.coarse_to_fine_voxel_resolutions =
          parsePositiveDoubleList(argv[++i]);
      continue;
    }
    if (arg.rfind("--litamin2-coarse-to-fine-voxels=", 0) == 0) {
      litamin2_options.coarse_to_fine_voxel_resolutions =
          parsePositiveDoubleList(arg.substr(
              std::string("--litamin2-coarse-to-fine-voxels=").size()));
      continue;
    }
    if (arg == "--litamin2-coarse-to-fine-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-coarse-to-fine-iterations requires a comma-separated list"
                  << std::endl;
        return 1;
      }
      litamin2_options.coarse_to_fine_iterations =
          parsePositiveIntList(argv[++i]);
      continue;
    }
    if (arg.rfind("--litamin2-coarse-to-fine-iterations=", 0) == 0) {
      litamin2_options.coarse_to_fine_iterations =
          parsePositiveIntList(arg.substr(
              std::string("--litamin2-coarse-to-fine-iterations=").size()));
      continue;
    }
    if (arg == "--litamin2-voxel-resolution") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-voxel-resolution requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.voxel_resolution = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--litamin2-voxel-resolution=", 0) == 0) {
      litamin2_options.voxel_resolution = std::stod(
          arg.substr(std::string("--litamin2-voxel-resolution=").size()));
      continue;
    }
    if (arg == "--litamin2-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-max-iterations=", 0) == 0) {
      litamin2_options.max_iterations = std::max(
          1, std::stoi(arg.substr(std::string("--litamin2-max-iterations=").size())));
      continue;
    }
    if (arg == "--litamin2-max-source-points") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-source-points requires an integer value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_source_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--litamin2-max-source-points=", 0) == 0) {
      litamin2_options.max_source_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--litamin2-max-source-points=").size()))));
      continue;
    }
    if (arg == "--litamin2-refresh-interval") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-refresh-interval requires an integer value"
                  << std::endl;
        return 1;
      }
      litamin2_options.refresh_interval =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--litamin2-refresh-interval=", 0) == 0) {
      litamin2_options.refresh_interval = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--litamin2-refresh-interval=").size()))));
      continue;
    }
    if (arg == "--litamin2-map-max-points") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-map-max-points requires an integer value"
                  << std::endl;
        return 1;
      }
      litamin2_options.map_max_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--litamin2-map-max-points=", 0) == 0) {
      litamin2_options.map_max_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--litamin2-map-max-points=").size()))));
      continue;
    }
    if (arg == "--litamin2-map-radius") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-map-radius requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.map_radius = std::max(1.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-map-radius=", 0) == 0) {
      litamin2_options.map_radius = std::max(
          1.0, std::stod(arg.substr(
                   std::string("--litamin2-map-radius=").size())));
      continue;
    }
    if (arg == "--litamin2-local-map-policy") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-local-map-policy requires refresh, accumulate, or keyframe"
                  << std::endl;
        return 1;
      }
      if (!parseLitamin2LocalMapPolicy(argv[++i],
                                       &litamin2_options.local_map_policy)) {
        std::cerr << "Unsupported --litamin2-local-map-policy value"
                  << std::endl;
        return 1;
      }
      continue;
    }
    if (arg.rfind("--litamin2-local-map-policy=", 0) == 0) {
      if (!parseLitamin2LocalMapPolicy(
              arg.substr(std::string("--litamin2-local-map-policy=").size()),
              &litamin2_options.local_map_policy)) {
        std::cerr << "Unsupported --litamin2-local-map-policy value"
                  << std::endl;
        return 1;
      }
      continue;
    }
    if (arg == "--litamin2-keyframe-translation") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-keyframe-translation requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.keyframe_translation =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-keyframe-translation=", 0) == 0) {
      litamin2_options.keyframe_translation = std::max(
          0.0, std::stod(arg.substr(
                   std::string("--litamin2-keyframe-translation=").size())));
      continue;
    }
    if (arg == "--litamin2-keyframe-rotation") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-keyframe-rotation requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.keyframe_rotation_rad =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-keyframe-rotation=", 0) == 0) {
      litamin2_options.keyframe_rotation_rad = std::max(
          0.0, std::stod(arg.substr(
                   std::string("--litamin2-keyframe-rotation=").size())));
      continue;
    }
    if (arg == "--litamin2-max-seed-translation-delta") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-seed-translation-delta requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_seed_translation_delta =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-max-seed-translation-delta=", 0) == 0) {
      litamin2_options.max_seed_translation_delta = std::max(
          0.0, std::stod(arg.substr(
                   std::string("--litamin2-max-seed-translation-delta=").size())));
      continue;
    }
    if (arg == "--litamin2-max-seed-rotation-delta") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-seed-rotation-delta requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_seed_rotation_delta_rad =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-max-seed-rotation-delta=", 0) == 0) {
      litamin2_options.max_seed_rotation_delta_rad = std::max(
          0.0, std::stod(arg.substr(
                   std::string("--litamin2-max-seed-rotation-delta=").size())));
      continue;
    }
    if (arg == "--litamin2-max-motion-translation-delta") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-motion-translation-delta requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_motion_translation_delta = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--litamin2-max-motion-translation-delta=", 0) == 0) {
      litamin2_options.max_motion_translation_delta = std::stod(arg.substr(
          std::string("--litamin2-max-motion-translation-delta=").size()));
      continue;
    }
    if (arg == "--litamin2-max-motion-rotation-delta") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-motion-rotation-delta requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_motion_rotation_delta_rad = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--litamin2-max-motion-rotation-delta=", 0) == 0) {
      litamin2_options.max_motion_rotation_delta_rad = std::stod(arg.substr(
          std::string("--litamin2-max-motion-rotation-delta=").size()));
      continue;
    }
    if (arg == "--litamin2-min-cov-eigenvalue") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-min-cov-eigenvalue requires a numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.min_cov_eigenvalue =
          std::max(1e-12, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-min-cov-eigenvalue=", 0) == 0) {
      litamin2_options.min_cov_eigenvalue = std::max(
          1e-12, std::stod(arg.substr(
                     std::string("--litamin2-min-cov-eigenvalue=").size())));
      continue;
    }
    if (arg == "--litamin2-correspondence-search-radius") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-correspondence-search-radius requires an "
                     "integer value"
                  << std::endl;
        return 1;
      }
      litamin2_options.correspondence_search_radius =
          std::max(0, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-correspondence-search-radius=", 0) == 0) {
      litamin2_options.correspondence_search_radius = std::max(
          0, std::stoi(arg.substr(
                 std::string("--litamin2-correspondence-search-radius=").size())));
      continue;
    }
    if (arg == "--litamin2-max-correspondence-distance") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-max-correspondence-distance requires a "
                     "numeric value"
                  << std::endl;
        return 1;
      }
      litamin2_options.max_correspondence_distance =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-max-correspondence-distance=", 0) == 0) {
      litamin2_options.max_correspondence_distance = std::max(
          0.0, std::stod(arg.substr(
                   std::string("--litamin2-max-correspondence-distance=").size())));
      continue;
    }
    if (arg == "--litamin2-num-threads") {
      if (i + 1 >= argc) {
        std::cerr << "--litamin2-num-threads requires an integer value"
                  << std::endl;
        return 1;
      }
      litamin2_options.num_threads = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--litamin2-num-threads=", 0) == 0) {
      litamin2_options.num_threads = std::max(
          1, std::stoi(arg.substr(std::string("--litamin2-num-threads=").size())));
      continue;
    }
    if (arg == "--gicp-fast-profile") {
      gicp_options.source_voxel_size = 1.25;
      gicp_options.max_source_points = 1800;
      gicp_options.k_neighbors = 6;
      gicp_options.max_correspondence_distance = 2.0;
      gicp_options.max_iterations = 6;
      gicp_options.map_max_points = 30000;
      gicp_options.refresh_interval = 6;
      gicp_options.map_radius = 35.0;
      continue;
    }
    if (arg == "--gicp-dense-profile") {
      gicp_options.source_voxel_size = 0.75;
      gicp_options.max_source_points = 3200;
      gicp_options.k_neighbors = 12;
      gicp_options.max_correspondence_distance = 3.0;
      gicp_options.max_iterations = 10;
      gicp_options.map_max_points = 55000;
      gicp_options.refresh_interval = 3;
      gicp_options.map_radius = 55.0;
      continue;
    }
    if (arg == "--gicp-source-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-source-voxel-size requires a numeric value"
                  << std::endl;
        return 1;
      }
      gicp_options.source_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--gicp-source-voxel-size=", 0) == 0) {
      gicp_options.source_voxel_size =
          std::stod(arg.substr(std::string("--gicp-source-voxel-size=").size()));
      continue;
    }
    if (arg == "--gicp-max-source-points") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-max-source-points requires an integer value"
                  << std::endl;
        return 1;
      }
      gicp_options.max_source_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--gicp-max-source-points=", 0) == 0) {
      gicp_options.max_source_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--gicp-max-source-points=").size()))));
      continue;
    }
    if (arg == "--gicp-k-neighbors") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-k-neighbors requires an integer value"
                  << std::endl;
        return 1;
      }
      gicp_options.k_neighbors = std::max(3, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--gicp-k-neighbors=", 0) == 0) {
      gicp_options.k_neighbors =
          std::max(3, std::stoi(arg.substr(std::string("--gicp-k-neighbors=").size())));
      continue;
    }
    if (arg == "--gicp-max-correspondence-distance") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-max-correspondence-distance requires a numeric value"
                  << std::endl;
        return 1;
      }
      gicp_options.max_correspondence_distance = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--gicp-max-correspondence-distance=", 0) == 0) {
      gicp_options.max_correspondence_distance = std::stod(
          arg.substr(std::string("--gicp-max-correspondence-distance=").size()));
      continue;
    }
    if (arg == "--gicp-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      gicp_options.max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--gicp-max-iterations=", 0) == 0) {
      gicp_options.max_iterations = std::max(
          1, std::stoi(arg.substr(std::string("--gicp-max-iterations=").size())));
      continue;
    }
    if (arg == "--gicp-map-max-points") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-map-max-points requires an integer value"
                  << std::endl;
        return 1;
      }
      gicp_options.map_max_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--gicp-map-max-points=", 0) == 0) {
      gicp_options.map_max_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(std::string("--gicp-map-max-points=").size()))));
      continue;
    }
    if (arg == "--gicp-refresh-interval") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-refresh-interval requires an integer value"
                  << std::endl;
        return 1;
      }
      gicp_options.refresh_interval =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--gicp-refresh-interval=", 0) == 0) {
      gicp_options.refresh_interval = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(std::string("--gicp-refresh-interval=").size()))));
      continue;
    }
    if (arg == "--gicp-map-radius") {
      if (i + 1 >= argc) {
        std::cerr << "--gicp-map-radius requires a numeric value" << std::endl;
        return 1;
      }
      gicp_options.map_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--gicp-map-radius=", 0) == 0) {
      gicp_options.map_radius =
          std::stod(arg.substr(std::string("--gicp-map-radius=").size()));
      continue;
    }
    if (arg == "--aloam-kitti-profile") {
      aloam_options.n_scans = 64;
      aloam_options.scan_period = 0.1f;
      aloam_options.minimum_range = 1.0f;
      aloam_options.curvature_threshold = 0.1f;
      aloam_options.less_flat_leaf_size = 0.2f;
      aloam_options.odom_outer_iters = 2;
      aloam_options.odom_ceres_iters = 4;
      aloam_options.map_outer_iters = 2;
      aloam_options.map_ceres_iters = 4;
      aloam_options.map_line_resolution = 0.4;
      aloam_options.map_plane_resolution = 0.8;
      aloam_options.map_knn = 5;
      aloam_options.map_knn_max_dist_sq = 1.0;
      aloam_options.map_edge_eigenvalue_ratio = 3.0;
      aloam_options.map_plane_threshold = 0.2;
      continue;
    }
    if (arg == "--aloam-fast-profile") {
      aloam_options.curvature_threshold = 0.15f;
      aloam_options.less_flat_leaf_size = 0.35f;
      aloam_options.odom_outer_iters = 1;
      aloam_options.odom_ceres_iters = 3;
      aloam_options.map_outer_iters = 1;
      aloam_options.map_ceres_iters = 3;
      aloam_options.map_line_resolution = 0.6;
      aloam_options.map_plane_resolution = 1.2;
      aloam_options.map_knn = 5;
      aloam_options.map_knn_max_dist_sq = 1.5;
      aloam_options.map_plane_threshold = 0.25;
      continue;
    }
    if (arg == "--aloam-dense-profile") {
      aloam_options.curvature_threshold = 0.08f;
      aloam_options.less_flat_leaf_size = 0.15f;
      aloam_options.odom_outer_iters = 2;
      aloam_options.odom_ceres_iters = 6;
      aloam_options.map_outer_iters = 2;
      aloam_options.map_ceres_iters = 6;
      aloam_options.map_line_resolution = 0.3;
      aloam_options.map_plane_resolution = 0.6;
      aloam_options.map_knn = 7;
      aloam_options.map_knn_max_dist_sq = 1.0;
      aloam_options.map_plane_threshold = 0.18;
      continue;
    }
    if (arg == "--floam-kitti-profile") {
      floam_options.n_scans = 64;
      floam_options.scan_period = 0.1f;
      floam_options.minimum_range = 1.0f;
      floam_options.input_point_stride = 2;
      floam_options.mapping_update_interval = 2;
      floam_options.enable_mapping = true;
      continue;
    }
    if (arg == "--i-loam-no-intensity") {
      // 強度経路を無効化し、純幾何 LOAM ベースラインとして走らせる(ablation)。
      i_loam_options.use_intensity_weight = false;
      i_loam_options.use_intensity_correspondence = false;
      continue;
    }
    if (arg == "--i-loam-no-mapping") {
      i_loam_options.enable_mapping = false;
      continue;
    }
    if (arg == "--i-loam-dense-profile") {
      i_loam_options.curvature_threshold = 0.08f;
      i_loam_options.less_flat_leaf_size = 0.15f;
      i_loam_options.odom_outer_iters = 2;
      i_loam_options.odom_ceres_iters = 6;
      i_loam_options.map_outer_iters = 2;
      i_loam_options.map_ceres_iters = 6;
      i_loam_options.map_line_resolution = 0.3;
      i_loam_options.map_plane_resolution = 0.6;
      i_loam_options.map_knn_max_dist_sq = 0.8;
      i_loam_options.map_plane_threshold = 0.15;
      continue;
    }
    if (arg == "--i-loam-intensity-sigma" && i + 1 < argc) {
      i_loam_options.intensity_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--i-loam-corr-weight" && i + 1 < argc) {
      i_loam_options.intensity_corr_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--i-loam-stride" && i + 1 < argc) {
      i_loam_options.input_point_stride =
          static_cast<size_t>(std::stoul(argv[++i]));
      continue;
    }
    if (arg == "--pl-loam-fast-profile") {
      pl_loam_options.input_stride = 3;
      pl_loam_options.max_point_features = 200;
      pl_loam_options.max_line_features = 48;
      pl_loam_options.ceres_max_iterations = 8;
      continue;
    }
    if (arg == "--pl-loam-dense-profile") {
      pl_loam_options.input_stride = 1;
      pl_loam_options.max_point_features = 320;
      pl_loam_options.max_line_features = 80;
      pl_loam_options.patch_radius = 5;
      pl_loam_options.ceres_max_iterations = 15;
      continue;
    }
    if (arg == "--pl-loam-no-depth-prior") {
      pl_loam_options.use_depth_prior = false;
      continue;
    }
    if (arg == "--pl-loam-no-lines") {
      pl_loam_options.use_line_features = false;
      continue;
    }
    if (arg == "--pl-loam-no-scale") {
      pl_loam_options.use_scale_correction = false;
      continue;
    }
    if (arg == "--pl-loam-depth-pseudo-image") {
      pl_loam_options.use_intensity_pseudo_image = false;
      continue;
    }
    if (arg == "--pl-loam-intensity-dilation" && i + 1 < argc) {
      pl_loam_options.intensity_dilation_radius = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--pl-loam-stride" && i + 1 < argc) {
      pl_loam_options.input_stride = static_cast<size_t>(std::stoul(argv[++i]));
      continue;
    }
    if (arg == "--pl-loam-rgb-root" && i + 1 < argc) {
      pl_loam_options.rgb_image_root = argv[++i];
      pl_loam_options.use_rgb = true;
      continue;
    }
    if (arg == "--pl-loam-rgb-camera" && i + 1 < argc) {
      pl_loam_options.rgb_camera_subdir = argv[++i];
      continue;
    }
    if (arg == "--pl-loam-rgb-full-res") {
      pl_loam_options.rgb_half_res = false;
      continue;
    }
    if (arg == "--inten-loam-fast-profile") {
      inten_loam_options.input_stride = 3;
      inten_loam_options.cyl_width = 720;
      inten_loam_options.cyl_height = 48;
      inten_loam_options.max_edge_features = 150;
      inten_loam_options.max_surface_features = 300;
      continue;
    }
    if (arg == "--inten-loam-dense-profile") {
      inten_loam_options.input_stride = 1;
      inten_loam_options.cyl_width = 1024;
      inten_loam_options.cyl_height = 64;
      inten_loam_options.max_edge_features = 220;
      inten_loam_options.max_surface_features = 500;
      inten_loam_options.max_reflector_features = 150;
      continue;
    }
    if (arg == "--inten-loam-paper-odometry") {
      inten_loam_options.paper_odometry = true;
      continue;
    }
    if (arg == "--inten-loam-paper-trace-jsonl") {
      if (i + 1 >= argc || argv[i + 1][0] == '-' || argv[i + 1][0] == '\0') {
        std::cerr << "--inten-loam-paper-trace-jsonl requires a new .jsonl path" << std::endl;
        return 1;
      }
      inten_loam_options.paper_trace_jsonl = argv[++i];
      continue;
    }
    if (arg == "--inten-loam-paper-no-intensity") {
      inten_loam_options.paper_intensity = false;
      continue;
    }
    if (arg == "--inten-loam-paper-no-mapping") {
      inten_loam_options.paper_mapping = false;
      continue;
    }
    if (arg == "--inten-loam-paper-no-dor") {
      inten_loam_options.paper_dor = false;
      continue;
    }
    if (arg == "--inten-loam-paper-set") {
      // key=value for a free parameter of InTenLoamPaperParams.
      if (i + 1 >= argc) { std::cerr << "--inten-loam-paper-set requires key=value" << std::endl; return 1; }
      const std::string kv = argv[++i];
      const auto eq = kv.find('=');
      if (eq == std::string::npos) { std::cerr << "--inten-loam-paper-set requires key=value" << std::endl; return 1; }
      inten_loam_options.paper_overrides.emplace_back(kv.substr(0, eq), std::stod(kv.substr(eq + 1)));
      continue;
    }
    if (arg == "--inten-loam-paper-s2m-interval") {
      if (i + 1 >= argc) { std::cerr << "--inten-loam-paper-s2m-interval requires a value" << std::endl; return 1; }
      inten_loam_options.paper_s2m_interval = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--inten-loam-no-intensity") {
      inten_loam_options.use_intensity_registration = false;
      continue;
    }
    if (arg == "--inten-loam-no-tvf") {
      inten_loam_options.enable_tvf = false;
      continue;
    }
    if (arg == "--inten-loam-no-dor") {
      inten_loam_options.enable_dor = false;
      continue;
    }
    if (arg == "--inten-loam-no-mapping") {
      inten_loam_options.enable_mapping = false;
      continue;
    }
    if (arg == "--inten-loam-stride" && i + 1 < argc) {
      inten_loam_options.input_stride = static_cast<size_t>(std::stoul(argv[++i]));
      continue;
    }
    // --- mcgicp ---
    if (arg == "--mcgicp-fast-profile") {
      mcgicp_options.source_voxel_size = 0.5;
      mcgicp_options.max_source_points = 4000;
      mcgicp_options.voxel_size = 1.0;
      mcgicp_options.max_iterations = 15;
      mcgicp_options.local_map_radius = 45.0;
      mcgicp_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--mcgicp-dense-profile") {
      mcgicp_options.source_voxel_size = 0.35;
      mcgicp_options.max_source_points = 6000;
      mcgicp_options.voxel_size = 0.8;
      mcgicp_options.max_iterations = 20;
      mcgicp_options.local_map_radius = 80.0;
      mcgicp_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--mcgicp-no-intensity") {
      mcgicp_options.enable_intensity = false;
      continue;
    }
    if (arg == "--mcgicp-intensity-scale" && i + 1 < argc) {
      mcgicp_options.intensity_scale = std::stod(argv[++i]);
      continue;
    }
    // --- icpsc ---
    if (arg == "--icpsc-fast-profile") {
      icpsc_options.source_voxel_size = 0.5;
      icpsc_options.max_source_points = 4000;
      icpsc_options.cyl_width = 720;
      icpsc_options.cyl_height = 48;
      icpsc_options.voxel_size = 1.0;
      icpsc_options.max_iterations = 12;
      icpsc_options.local_map_radius = 45.0;
      icpsc_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--icpsc-dense-profile") {
      icpsc_options.source_voxel_size = 0.35;
      icpsc_options.max_source_points = 6000;
      icpsc_options.cyl_width = 1024;
      icpsc_options.cyl_height = 64;
      icpsc_options.voxel_size = 0.8;
      icpsc_options.max_iterations = 15;
      icpsc_options.local_map_radius = 80.0;
      icpsc_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--icpsc-no-intensity") {
      icpsc_options.enable_intensity = false;
      continue;
    }
    // --- vlom ---
    if (arg == "--vlom-fast-profile") {
      vlom_options.input_point_stride = 3;
      vlom_options.visual_input_stride = 3;
      vlom_options.max_point_features = 200;
      vlom_options.max_line_features = 48;
      vlom_options.scale_correction_interval = 8;
      continue;
    }
    if (arg == "--vlom-dense-profile") {
      vlom_options.input_point_stride = 1;
      vlom_options.visual_input_stride = 1;
      vlom_options.max_point_features = 320;
      vlom_options.max_line_features = 80;
      vlom_options.scale_correction_interval = 5;
      continue;
    }
    if (arg == "--vlom-no-bootstrap") {
      vlom_options.enable_visual_bootstrap = false;
      continue;
    }
    if (arg == "--vlom-enable-bootstrap") {
      vlom_options.enable_visual_bootstrap = true;
      continue;
    }
    if (arg == "--vlom-no-scale") {
      vlom_options.enable_scale_correction = false;
      continue;
    }
    if (arg == "--vlom-depth-pseudo-image") {
      vlom_options.use_intensity_pseudo_image = false;
      continue;
    }
    if (arg == "--vlom-intensity-dilation" && i + 1 < argc) {
      vlom_options.intensity_dilation_radius = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--vlom-rgb-root" && i + 1 < argc) {
      vlom_options.rgb_image_root = argv[++i];
      vlom_options.use_rgb = true;
      continue;
    }
    if (arg == "--vlom-rgb-camera" && i + 1 < argc) {
      vlom_options.rgb_camera_subdir = argv[++i];
      continue;
    }
    if (arg == "--vlom-rgb-full-res") {
      vlom_options.rgb_half_res = false;
      continue;
    }
    // --- odonet ---
    if (arg == "--odonet-weights" && i + 1 < argc) {
      odonet_options.weights_path = argv[++i];
      continue;
    }
    if (arg == "--odonet-no-nhc") {
      odonet_options.enable_nhc = false;
      continue;
    }
    if (arg == "--odonet-no-zupt") {
      odonet_options.enable_zupt = false;
      continue;
    }
    if (arg == "--odonet-nhc-only") {
      odonet_options.enable_cnn_speed = false;
      continue;
    }
    // --- nhc_net ---
    if (arg == "--nhc-net-weights" && i + 1 < argc) {
      nhc_net_options.weights_path = argv[++i];
      continue;
    }
    if (arg == "--nhc-net-no-zupt") {
      nhc_net_options.enable_zupt = false;
      continue;
    }
    if (arg == "--nhc-net-fixed-gain") {
      nhc_net_options.adaptive_gain = false;
      continue;
    }
    if (arg == "--nhc-net-gain" && i + 1 < argc) {
      nhc_net_options.nhc_gain = std::stod(argv[++i]);
      continue;
    }
    // --- nn_zupt ---
    if (arg == "--nn-zupt-weights" && i + 1 < argc) {
      nn_zupt_options.weights_path = argv[++i];
      continue;
    }
    if (arg == "--nn-zupt-no-zupt") {
      nn_zupt_options.enable_zupt = false;
      continue;
    }
    if (arg == "--nn-zupt-no-nhc") {
      nn_zupt_options.enable_nhc = false;
      continue;
    }
    if (arg == "--nn-zupt-threshold-only") {
      nn_zupt_options.use_threshold_detector = true;
      continue;
    }
    if (arg == "--nn-zupt-prob" && i + 1 < argc) {
      nn_zupt_options.stop_prob_threshold = std::stod(argv[++i]);
      continue;
    }
    // --- imu_dead_reckoning ---
    if (arg == "--imu-dr-static-init-sec" && i + 1 < argc) {
      imu_dead_reckoning_options.static_init_duration_s = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-no-gyro-bias") {
      imu_dead_reckoning_options.estimate_gyro_bias = false;
      continue;
    }
    if (arg == "--imu-dr-accel-bias") {
      imu_dead_reckoning_options.estimate_accel_bias = true;
      continue;
    }
    if (arg == "--imu-dr-motion-gated-init") {
      imu_dead_reckoning_options.motion_gated_static_init = true;
      continue;
    }
    if (arg == "--imu-dr-min-static-samples" && i + 1 < argc) {
      imu_dead_reckoning_options.min_static_samples = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-static-accel-std-gate" && i + 1 < argc) {
      imu_dead_reckoning_options.static_accel_std_gate = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-euler") {
      imu_dead_reckoning_options.midpoint_integration = false;
      continue;
    }
    if (arg == "--imu-dr-rk4") {
      imu_dead_reckoning_options.rk4_integration = true;
      continue;
    }
    if (arg == "--imu-dr-zupt") {
      imu_dead_reckoning_options.enable_zupt = true;
      continue;
    }
    if (arg == "--imu-dr-zupt-gyro-threshold" && i + 1 < argc) {
      imu_dead_reckoning_options.zupt_gyro_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-zupt-accel-tolerance" && i + 1 < argc) {
      imu_dead_reckoning_options.zupt_accel_tolerance = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-leveling") {
      imu_dead_reckoning_options.enable_leveling = true;
      continue;
    }
    if (arg == "--imu-dr-leveling-gain" && i + 1 < argc) {
      imu_dead_reckoning_options.leveling_gain = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-zaru") {
      imu_dead_reckoning_options.enable_zaru = true;
      continue;
    }
    if (arg == "--imu-dr-zaru-gain" && i + 1 < argc) {
      imu_dead_reckoning_options.zaru_gain = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-eskf") {
      imu_dead_reckoning_options.enable_eskf = true;
      continue;
    }
    if (arg == "--imu-dr-eskf-sigma-accel" && i + 1 < argc) {
      imu_dead_reckoning_options.eskf_sigma_accel = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-eskf-sigma-gyro" && i + 1 < argc) {
      imu_dead_reckoning_options.eskf_sigma_gyro = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-eskf-zupt-sigma" && i + 1 < argc) {
      imu_dead_reckoning_options.eskf_zupt_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-eskf-nhc-sigma" && i + 1 < argc) {
      imu_dead_reckoning_options.eskf_nhc_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-eskf-leveling-sigma" && i + 1 < argc) {
      imu_dead_reckoning_options.eskf_leveling_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-nhc") {
      imu_dead_reckoning_options.enable_nhc = true;
      continue;
    }
    if (arg == "--imu-dr-nhc-gain" && i + 1 < argc) {
      imu_dead_reckoning_options.nhc_gain = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imu-dr-forward-axis" && i + 1 < argc) {
      imu_dead_reckoning_options.forward_axis = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--floam-fast-profile") {
      floam_options.input_point_stride = 4;
      floam_options.mapping_update_interval = 3;
      floam_options.curvature_threshold = 0.12f;
      floam_options.less_flat_leaf_size = 0.4f;
      floam_options.odom_outer_iters = 1;
      floam_options.odom_ceres_iters = 2;
      floam_options.map_outer_iters = 1;
      floam_options.map_ceres_iters = 2;
      floam_options.map_line_resolution = 0.8;
      floam_options.map_plane_resolution = 1.4;
      floam_options.map_knn_max_dist_sq = 5.0;
      continue;
    }
    if (arg == "--floam-dense-profile") {
      floam_options.input_point_stride = 1;
      floam_options.mapping_update_interval = 1;
      floam_options.curvature_threshold = 0.06f;
      floam_options.less_flat_leaf_size = 0.2f;
      floam_options.odom_outer_iters = 2;
      floam_options.odom_ceres_iters = 4;
      floam_options.map_outer_iters = 2;
      floam_options.map_ceres_iters = 4;
      floam_options.map_line_resolution = 0.5;
      floam_options.map_plane_resolution = 0.9;
      floam_options.map_knn_max_dist_sq = 3.0;
      continue;
    }
    if (arg == "--lego-loam-kitti-profile") {
      lego_loam_options.n_scans = 64;
      lego_loam_options.scan_period = 0.1f;
      lego_loam_options.minimum_range = 1.0f;
      lego_loam_options.maximum_range = 100.0f;
      lego_loam_options.ground_scan_limit = 6;
      lego_loam_options.sensor_height = 1.73f;
      lego_loam_options.ground_height_tolerance = 0.4f;
      lego_loam_options.curvature_threshold = 0.1f;
      lego_loam_options.less_flat_leaf_size = 0.2f;
      lego_loam_options.odom_distance_sq_threshold = 25.0;
      lego_loam_options.odom_outer_iters = 2;
      lego_loam_options.odom_ceres_iters = 4;
      lego_loam_options.map_outer_iters = 2;
      lego_loam_options.map_ceres_iters = 4;
      lego_loam_options.map_line_resolution = 0.4;
      lego_loam_options.map_plane_resolution = 0.8;
      lego_loam_options.map_knn = 5;
      lego_loam_options.map_knn_max_dist_sq = 1.0;
      lego_loam_options.map_edge_eigenvalue_ratio = 3.0;
      lego_loam_options.map_plane_threshold = 0.2;
      continue;
    }
    if (arg == "--lego-loam-fast-profile") {
      lego_loam_options.curvature_threshold = 0.15f;
      lego_loam_options.less_flat_leaf_size = 0.35f;
      lego_loam_options.odom_outer_iters = 1;
      lego_loam_options.odom_ceres_iters = 3;
      lego_loam_options.map_outer_iters = 1;
      lego_loam_options.map_ceres_iters = 3;
      lego_loam_options.map_line_resolution = 0.6;
      lego_loam_options.map_plane_resolution = 1.2;
      lego_loam_options.map_knn_max_dist_sq = 1.5;
      lego_loam_options.map_plane_threshold = 0.25;
      continue;
    }
    if (arg == "--lego-loam-dense-profile") {
      lego_loam_options.curvature_threshold = 0.08f;
      lego_loam_options.less_flat_leaf_size = 0.15f;
      lego_loam_options.odom_outer_iters = 2;
      lego_loam_options.odom_ceres_iters = 6;
      lego_loam_options.map_outer_iters = 2;
      lego_loam_options.map_ceres_iters = 6;
      lego_loam_options.map_line_resolution = 0.3;
      lego_loam_options.map_plane_resolution = 0.6;
      lego_loam_options.map_knn = 7;
      lego_loam_options.map_knn_max_dist_sq = 1.0;
      lego_loam_options.map_plane_threshold = 0.18;
      continue;
    }
    if (arg == "--mulls-lo") {
      mulls_options.lo = true;
      continue;
    }
    if (arg == "--mulls-lo-highway") {
      mulls_options.lo = true;
      mulls_options.lo_highway = true;
      continue;
    }
    if (arg == "--mulls-lo-disable") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      mulls_options.lo_disable = argv[++i];
      continue;
    }
    if (arg == "--mulls-kitti-profile") {
      mulls_options.n_scans = 64;
      mulls_options.scan_period = 0.1f;
      mulls_options.minimum_range = 1.0f;
      mulls_options.curvature_threshold = 0.1f;
      mulls_options.less_flat_leaf_size = 0.2f;
      mulls_options.odom_distance_sq_threshold = 25.0;
      mulls_options.odom_outer_iters = 2;
      mulls_options.odom_ceres_iters = 4;
      mulls_options.line_resolution = 0.4;
      mulls_options.plane_resolution = 0.8;
      mulls_options.point_resolution = 1.0;
      mulls_options.mulls_map_iters = 2;
      mulls_options.mulls_ceres_iters = 4;
      mulls_options.mulls_knn = 5;
      mulls_options.mulls_knn_max_dist_sq = 1.0;
      mulls_options.mulls_point_neighbor_max_dist_sq = 4.0;
      mulls_options.mulls_point_weight = 0.3;
      mulls_options.mulls_full_downsample_rate = 5;
      mulls_options.mulls_max_frames_in_map = 30;
      continue;
    }
    if (arg == "--mulls-fast-profile") {
      mulls_options.curvature_threshold = 0.15f;
      mulls_options.less_flat_leaf_size = 0.35f;
      mulls_options.odom_outer_iters = 1;
      mulls_options.odom_ceres_iters = 3;
      mulls_options.line_resolution = 0.55;
      mulls_options.plane_resolution = 1.0;
      mulls_options.point_resolution = 1.2;
      mulls_options.mulls_map_iters = 1;
      mulls_options.mulls_ceres_iters = 3;
      mulls_options.mulls_knn_max_dist_sq = 1.5;
      mulls_options.mulls_point_neighbor_max_dist_sq = 5.0;
      mulls_options.mulls_point_weight = 0.2;
      mulls_options.mulls_full_downsample_rate = 8;
      mulls_options.mulls_max_frames_in_map = 20;
      continue;
    }
    if (arg == "--mulls-dense-profile") {
      mulls_options.curvature_threshold = 0.08f;
      mulls_options.less_flat_leaf_size = 0.15f;
      mulls_options.odom_outer_iters = 2;
      mulls_options.odom_ceres_iters = 6;
      mulls_options.line_resolution = 0.3;
      mulls_options.plane_resolution = 0.6;
      mulls_options.point_resolution = 0.85;
      mulls_options.mulls_map_iters = 2;
      mulls_options.mulls_ceres_iters = 6;
      mulls_options.mulls_knn = 7;
      mulls_options.mulls_knn_max_dist_sq = 1.0;
      mulls_options.mulls_plane_threshold = 0.18;
      mulls_options.mulls_max_frames_in_map = 40;
      continue;
    }
    if (arg == "--dlo-kitti-profile") {
      dlo_options.input_voxel_size = 0.5;
      dlo_options.max_input_points = 6000;
      dlo_options.min_range = 1.0;
      dlo_options.max_range = 100.0;
      dlo_options.registration_voxel_size = 0.5;
      dlo_options.map_voxel_size = 0.8;
      dlo_options.keyframe_translation_threshold = 0.6;
      dlo_options.keyframe_rotation_threshold_rad =
          8.0 * 3.14159265358979323846 / 180.0;
      dlo_options.max_keyframes_in_map = 30;
      dlo_options.gicp_k_neighbors = 15;
      dlo_options.gicp_max_correspondence_distance = 4.0;
      dlo_options.gicp_max_iterations = 25;
      continue;
    }
    if (arg == "--dlo-fast-profile") {
      dlo_options.input_voxel_size = 0.65;
      dlo_options.max_input_points = 4000;
      dlo_options.registration_voxel_size = 0.85;
      dlo_options.map_voxel_size = 1.1;
      dlo_options.keyframe_translation_threshold = 0.75;
      dlo_options.max_keyframes_in_map = 20;
      dlo_options.gicp_k_neighbors = 12;
      dlo_options.gicp_max_correspondence_distance = 5.5;
      dlo_options.gicp_max_iterations = 14;
      continue;
    }
    if (arg == "--dlo-dense-profile") {
      dlo_options.input_voxel_size = 0.35;
      dlo_options.max_input_points = 9000;
      dlo_options.registration_voxel_size = 0.35;
      dlo_options.map_voxel_size = 0.55;
      dlo_options.keyframe_translation_threshold = 0.45;
      dlo_options.max_keyframes_in_map = 40;
      dlo_options.gicp_k_neighbors = 18;
      dlo_options.gicp_max_correspondence_distance = 3.5;
      dlo_options.gicp_max_iterations = 35;
      continue;
    }
    if (arg == "--dlio-kitti-profile") {
      dlio_options.input_voxel_size = 0.5;
      dlio_options.max_input_points = 6000;
      dlio_options.min_range = 1.0;
      dlio_options.max_range = 100.0;
      dlio_options.registration_voxel_size = 0.5;
      dlio_options.map_voxel_size = 0.8;
      dlio_options.keyframe_translation_threshold = 0.6;
      dlio_options.keyframe_rotation_threshold_rad =
          8.0 * 3.14159265358979323846 / 180.0;
      dlio_options.max_keyframes_in_map = 30;
      dlio_options.gicp_k_neighbors = 15;
      dlio_options.gicp_max_correspondence_distance = 4.0;
      dlio_options.gicp_max_iterations = 25;
      dlio_options.imu_rotation_fusion_weight = 0.15;
      dlio_options.imu_translation_fusion_weight = 0.2;
      dlio_options.imu_velocity_fusion_weight = 0.2;
      dlio_options.lidar_confidence_correspondence_scale = 100.0;
      continue;
    }
    if (arg == "--dlio-fast-profile") {
      dlio_options.input_voxel_size = 0.65;
      dlio_options.max_input_points = 4000;
      dlio_options.registration_voxel_size = 0.85;
      dlio_options.map_voxel_size = 1.1;
      dlio_options.keyframe_translation_threshold = 0.75;
      dlio_options.max_keyframes_in_map = 20;
      dlio_options.gicp_k_neighbors = 12;
      dlio_options.gicp_max_correspondence_distance = 5.5;
      dlio_options.gicp_max_iterations = 14;
      dlio_options.imu_rotation_fusion_weight = 0.08;
      dlio_options.imu_translation_fusion_weight = 0.12;
      dlio_options.imu_velocity_fusion_weight = 0.12;
      dlio_options.lidar_confidence_correspondence_scale = 80.0;
      continue;
    }
    if (arg == "--dlio-dense-profile") {
      dlio_options.input_voxel_size = 0.35;
      dlio_options.max_input_points = 9000;
      dlio_options.registration_voxel_size = 0.35;
      dlio_options.map_voxel_size = 0.55;
      dlio_options.keyframe_translation_threshold = 0.45;
      dlio_options.max_keyframes_in_map = 40;
      dlio_options.gicp_k_neighbors = 18;
      dlio_options.gicp_max_correspondence_distance = 3.5;
      dlio_options.gicp_max_iterations = 35;
      dlio_options.imu_rotation_fusion_weight = 0.2;
      dlio_options.imu_translation_fusion_weight = 0.25;
      dlio_options.imu_velocity_fusion_weight = 0.25;
      dlio_options.lidar_confidence_correspondence_scale = 120.0;
      continue;
    }
    if (arg == "--small-gicp-fast-profile") {
      small_gicp_options.source_voxel_size = 1.5;
      small_gicp_options.max_source_points = 1600;
      small_gicp_options.voxel_resolution = 1.5;
      small_gicp_options.k_neighbors = 10;
      small_gicp_options.max_correspondence_distance = 3.0;
      small_gicp_options.max_correspondences = 160;
      small_gicp_options.max_iterations = 10;
      small_gicp_options.map_max_points = 25000;
      small_gicp_options.refresh_interval = 6;
      small_gicp_options.map_radius = 35.0;
      continue;
    }
    if (arg == "--small-gicp-dense-profile") {
      small_gicp_options.source_voxel_size = 0.75;
      small_gicp_options.max_source_points = 3200;
      small_gicp_options.voxel_resolution = 0.9;
      small_gicp_options.k_neighbors = 14;
      small_gicp_options.max_correspondence_distance = 4.5;
      small_gicp_options.max_correspondences = 320;
      small_gicp_options.max_iterations = 24;
      small_gicp_options.map_max_points = 50000;
      small_gicp_options.refresh_interval = 3;
      small_gicp_options.map_radius = 55.0;
      continue;
    }
    if (arg == "--small-gicp-source-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-source-voxel-size requires a numeric value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.source_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--small-gicp-source-voxel-size=", 0) == 0) {
      small_gicp_options.source_voxel_size = std::stod(
          arg.substr(std::string("--small-gicp-source-voxel-size=").size()));
      continue;
    }
    if (arg == "--small-gicp-max-source-points") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-max-source-points requires an integer value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.max_source_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--small-gicp-max-source-points=", 0) == 0) {
      small_gicp_options.max_source_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--small-gicp-max-source-points=").size()))));
      continue;
    }
    if (arg == "--small-gicp-voxel-resolution") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-voxel-resolution requires a numeric value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.voxel_resolution = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--small-gicp-voxel-resolution=", 0) == 0) {
      small_gicp_options.voxel_resolution = std::stod(
          arg.substr(std::string("--small-gicp-voxel-resolution=").size()));
      continue;
    }
    if (arg == "--small-gicp-k-neighbors") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-k-neighbors requires an integer value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.k_neighbors = std::max(3, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--small-gicp-k-neighbors=", 0) == 0) {
      small_gicp_options.k_neighbors = std::max(
          3, std::stoi(arg.substr(std::string("--small-gicp-k-neighbors=").size())));
      continue;
    }
    if (arg == "--small-gicp-max-correspondence-distance") {
      if (i + 1 >= argc) {
        std::cerr
            << "--small-gicp-max-correspondence-distance requires a numeric value"
            << std::endl;
        return 1;
      }
      small_gicp_options.max_correspondence_distance = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--small-gicp-max-correspondence-distance=", 0) == 0) {
      small_gicp_options.max_correspondence_distance = std::stod(
          arg.substr(
              std::string("--small-gicp-max-correspondence-distance=").size()));
      continue;
    }
    if (arg == "--small-gicp-max-correspondences") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-max-correspondences requires an integer value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.max_correspondences = std::max(16, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--small-gicp-max-correspondences=", 0) == 0) {
      small_gicp_options.max_correspondences = std::max(
          16, std::stoi(arg.substr(
                  std::string("--small-gicp-max-correspondences=").size())));
      continue;
    }
    if (arg == "--small-gicp-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--small-gicp-max-iterations=", 0) == 0) {
      small_gicp_options.max_iterations = std::max(
          1, std::stoi(arg.substr(std::string("--small-gicp-max-iterations=").size())));
      continue;
    }
    if (arg == "--small-gicp-max-seed-translation-delta") {
      if (i + 1 >= argc) {
        std::cerr
            << "--small-gicp-max-seed-translation-delta requires a numeric value"
            << std::endl;
        return 1;
      }
      small_gicp_options.max_seed_translation_delta = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--small-gicp-max-seed-translation-delta=", 0) == 0) {
      small_gicp_options.max_seed_translation_delta = std::stod(arg.substr(
          std::string("--small-gicp-max-seed-translation-delta=").size()));
      continue;
    }
    if (arg == "--small-gicp-max-seed-rotation-delta-rad") {
      if (i + 1 >= argc) {
        std::cerr
            << "--small-gicp-max-seed-rotation-delta-rad requires a numeric value"
            << std::endl;
        return 1;
      }
      small_gicp_options.max_seed_rotation_delta_rad = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--small-gicp-max-seed-rotation-delta-rad=", 0) == 0) {
      small_gicp_options.max_seed_rotation_delta_rad = std::stod(arg.substr(
          std::string("--small-gicp-max-seed-rotation-delta-rad=").size()));
      continue;
    }
    if (arg == "--small-gicp-map-max-points") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-map-max-points requires an integer value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.map_max_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--small-gicp-map-max-points=", 0) == 0) {
      small_gicp_options.map_max_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--small-gicp-map-max-points=").size()))));
      continue;
    }
    if (arg == "--small-gicp-refresh-interval") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-refresh-interval requires an integer value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.refresh_interval =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--small-gicp-refresh-interval=", 0) == 0) {
      small_gicp_options.refresh_interval = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--small-gicp-refresh-interval=").size()))));
      continue;
    }
    if (arg == "--small-gicp-map-radius") {
      if (i + 1 >= argc) {
        std::cerr << "--small-gicp-map-radius requires a numeric value"
                  << std::endl;
        return 1;
      }
      small_gicp_options.map_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--small-gicp-map-radius=", 0) == 0) {
      small_gicp_options.map_radius = std::stod(
          arg.substr(std::string("--small-gicp-map-radius=").size()));
      continue;
    }
    if (arg == "--voxel-gicp-fast-profile") {
      voxel_gicp_options.source_voxel_size = 1.5;
      voxel_gicp_options.max_source_points = 1600;
      voxel_gicp_options.voxel_resolution = 1.5;
      voxel_gicp_options.min_points_per_voxel = 1;
      voxel_gicp_options.max_correspondence_distance = 3.0;
      voxel_gicp_options.max_iterations = 10;
      voxel_gicp_options.map_max_points = 25000;
      voxel_gicp_options.refresh_interval = 6;
      voxel_gicp_options.map_radius = 35.0;
      continue;
    }
    if (arg == "--voxel-gicp-dense-profile") {
      voxel_gicp_options.source_voxel_size = 0.75;
      voxel_gicp_options.max_source_points = 3200;
      voxel_gicp_options.voxel_resolution = 0.9;
      voxel_gicp_options.min_points_per_voxel = 3;
      voxel_gicp_options.max_correspondence_distance = 4.5;
      voxel_gicp_options.max_iterations = 24;
      voxel_gicp_options.map_max_points = 50000;
      voxel_gicp_options.refresh_interval = 3;
      voxel_gicp_options.map_radius = 55.0;
      continue;
    }
    if (arg == "--voxel-gicp-voxel-resolution") {
      if (i + 1 >= argc) {
        std::cerr << "--voxel-gicp-voxel-resolution requires a numeric value"
                  << std::endl;
        return 1;
      }
      voxel_gicp_options.voxel_resolution = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--voxel-gicp-voxel-resolution=", 0) == 0) {
      voxel_gicp_options.voxel_resolution = std::stod(
          arg.substr(std::string("--voxel-gicp-voxel-resolution=").size()));
      continue;
    }
    if (arg == "--voxel-gicp-min-points-per-voxel") {
      if (i + 1 >= argc) {
        std::cerr << "--voxel-gicp-min-points-per-voxel requires an integer value"
                  << std::endl;
        return 1;
      }
      voxel_gicp_options.min_points_per_voxel =
          std::max(2, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--voxel-gicp-min-points-per-voxel=", 0) == 0) {
      voxel_gicp_options.min_points_per_voxel = std::max(
          2, std::stoi(
                 arg.substr(std::string("--voxel-gicp-min-points-per-voxel=").size())));
      continue;
    }
    if (arg == "--voxel-gicp-max-correspondence-distance") {
      if (i + 1 >= argc) {
        std::cerr << "--voxel-gicp-max-correspondence-distance requires a value"
                  << std::endl;
        return 1;
      }
      voxel_gicp_options.max_correspondence_distance = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--voxel-gicp-max-correspondence-distance=", 0) == 0) {
      voxel_gicp_options.max_correspondence_distance = std::stod(
          arg.substr(
              std::string("--voxel-gicp-max-correspondence-distance=").size()));
      continue;
    }
    if (arg == "--voxel-gicp-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--voxel-gicp-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      voxel_gicp_options.max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--voxel-gicp-max-iterations=", 0) == 0) {
      voxel_gicp_options.max_iterations = std::max(
          1, std::stoi(
                 arg.substr(std::string("--voxel-gicp-max-iterations=").size())));
      continue;
    }
    if (arg == "--ndt-fast-profile") {
      ndt_options.source_voxel_size = 1.0;
      ndt_options.max_source_points = 1600;
      ndt_options.resolution = 2.0;
      ndt_options.max_iterations = 4;
      ndt_options.step_size = 0.25;
      ndt_options.map_max_points = 18000;
      ndt_options.refresh_interval = 10;
      ndt_options.map_radius = 30.0;
      continue;
    }
    if (arg == "--ndt-dense-profile") {
      ndt_options.source_voxel_size = 0.6;
      ndt_options.max_source_points = 2600;
      ndt_options.resolution = 1.2;
      ndt_options.max_iterations = 7;
      ndt_options.step_size = 0.15;
      ndt_options.map_max_points = 30000;
      ndt_options.refresh_interval = 6;
      ndt_options.map_radius = 40.0;
      continue;
    }
    if (arg == "--ndt-source-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-source-voxel-size requires a numeric value"
                  << std::endl;
        return 1;
      }
      ndt_options.source_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ndt-source-voxel-size=", 0) == 0) {
      ndt_options.source_voxel_size =
          std::stod(arg.substr(std::string("--ndt-source-voxel-size=").size()));
      continue;
    }
    if (arg == "--ndt-max-source-points") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-max-source-points requires an integer value"
                  << std::endl;
        return 1;
      }
      ndt_options.max_source_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--ndt-max-source-points=", 0) == 0) {
      ndt_options.max_source_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--ndt-max-source-points=").size()))));
      continue;
    }
    if (arg == "--ndt-resolution") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-resolution requires a numeric value" << std::endl;
        return 1;
      }
      ndt_options.resolution = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ndt-resolution=", 0) == 0) {
      ndt_options.resolution =
          std::stod(arg.substr(std::string("--ndt-resolution=").size()));
      continue;
    }
    if (arg == "--ndt-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      ndt_options.max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ndt-max-iterations=", 0) == 0) {
      ndt_options.max_iterations = std::max(
          1, std::stoi(arg.substr(std::string("--ndt-max-iterations=").size())));
      continue;
    }
    if (arg == "--ndt-step-size") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-step-size requires a numeric value" << std::endl;
        return 1;
      }
      ndt_options.step_size = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ndt-step-size=", 0) == 0) {
      ndt_options.step_size =
          std::stod(arg.substr(std::string("--ndt-step-size=").size()));
      continue;
    }
    if (arg == "--ndt-map-max-points") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-map-max-points requires an integer value"
                  << std::endl;
        return 1;
      }
      ndt_options.map_max_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--ndt-map-max-points=", 0) == 0) {
      ndt_options.map_max_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(std::string("--ndt-map-max-points=").size()))));
      continue;
    }
    if (arg == "--ndt-refresh-interval") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-refresh-interval requires an integer value"
                  << std::endl;
        return 1;
      }
      ndt_options.refresh_interval =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--ndt-refresh-interval=", 0) == 0) {
      ndt_options.refresh_interval = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(std::string("--ndt-refresh-interval=").size()))));
      continue;
    }
    if (arg == "--ndt-map-radius") {
      if (i + 1 >= argc) {
        std::cerr << "--ndt-map-radius requires a numeric value" << std::endl;
        return 1;
      }
      ndt_options.map_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ndt-map-radius=", 0) == 0) {
      ndt_options.map_radius =
          std::stod(arg.substr(std::string("--ndt-map-radius=").size()));
      continue;
    }
    if (arg == "--fixed-map-ndt-map-ply") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-map-ply requires a path" << std::endl;
        return 1;
      }
      fixed_map_ndt_options.map_ply_path = argv[++i];
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-map-ply=", 0) == 0) {
      fixed_map_ndt_options.map_ply_path =
          arg.substr(std::string("--fixed-map-ndt-map-ply=").size());
      continue;
    }
    if (arg == "--fixed-map-ndt-seed-source") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-seed-source requires gt, velocity, ct_icp, or scan_context"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.seed_source = normalizeMethodId(argv[++i]);
      if (fixed_map_ndt_options.seed_source != "gt" &&
          fixed_map_ndt_options.seed_source != "velocity" &&
          fixed_map_ndt_options.seed_source != "ct_icp" &&
          fixed_map_ndt_options.seed_source != "scan_context") {
        std::cerr << "--fixed-map-ndt-seed-source must be gt, velocity, ct_icp, or scan_context"
                  << std::endl;
        return 1;
      }
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-seed-source=", 0) == 0) {
      fixed_map_ndt_options.seed_source = normalizeMethodId(
          arg.substr(std::string("--fixed-map-ndt-seed-source=").size()));
      if (fixed_map_ndt_options.seed_source != "gt" &&
          fixed_map_ndt_options.seed_source != "velocity" &&
          fixed_map_ndt_options.seed_source != "ct_icp" &&
          fixed_map_ndt_options.seed_source != "scan_context") {
        std::cerr << "--fixed-map-ndt-seed-source must be gt, velocity, ct_icp, or scan_context"
                  << std::endl;
        return 1;
      }
      continue;
    }
    if (arg == "--fixed-map-ndt-map-stride") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-map-stride requires an integer value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.map_stride = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-map-stride=", 0) == 0) {
      fixed_map_ndt_options.map_stride = std::max(
          1, std::stoi(arg.substr(
                 std::string("--fixed-map-ndt-map-stride=").size())));
      continue;
    }
    if (arg == "--fixed-map-ndt-scan-context-threshold") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-scan-context-threshold requires a numeric value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.scan_context_distance_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-scan-context-threshold=", 0) == 0) {
      fixed_map_ndt_options.scan_context_distance_threshold = std::stod(
          arg.substr(std::string(
                         "--fixed-map-ndt-scan-context-threshold=").size()));
      continue;
    }
    if (arg == "--fixed-map-ndt-scan-context-top-k") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-scan-context-top-k requires an integer value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.scan_context_top_k = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-scan-context-top-k=", 0) == 0) {
      fixed_map_ndt_options.scan_context_top_k = std::max(
          1, std::stoi(arg.substr(
                 std::string("--fixed-map-ndt-scan-context-top-k=").size())));
      continue;
    }
    if (arg == "--fixed-map-ndt-trace-json") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-trace-json requires a path"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.trace_json_path = argv[++i];
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-trace-json=", 0) == 0) {
      fixed_map_ndt_options.trace_json_path =
          arg.substr(std::string("--fixed-map-ndt-trace-json=").size());
      continue;
    }
    if (arg == "--fixed-map-ndt-publish-min-stable-frames") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-publish-min-stable-frames requires an integer value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.publish_min_stable_frames =
          std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-publish-min-stable-frames=", 0) == 0) {
      fixed_map_ndt_options.publish_min_stable_frames =
          std::max(1, std::stoi(arg.substr(
                          std::string("--fixed-map-ndt-publish-min-stable-frames=").size())));
      continue;
    }
    if (arg == "--fixed-map-ndt-publish-max-hold-frames") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-publish-max-hold-frames requires an integer value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.publish_max_hold_frames =
          std::max(0, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-publish-max-hold-frames=", 0) == 0) {
      fixed_map_ndt_options.publish_max_hold_frames =
          std::max(0, std::stoi(arg.substr(
                          std::string("--fixed-map-ndt-publish-max-hold-frames=").size())));
      continue;
    }
    if (arg == "--fixed-map-ndt-scan-context-relock-min-confirmations") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-scan-context-relock-min-confirmations requires an integer value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.scan_context_relock_min_confirmations =
          std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-scan-context-relock-min-confirmations=", 0) == 0) {
      fixed_map_ndt_options.scan_context_relock_min_confirmations =
          std::max(1, std::stoi(arg.substr(
                          std::string("--fixed-map-ndt-scan-context-relock-min-confirmations=").size())));
      continue;
    }
    if (arg == "--fixed-map-ndt-scan-context-relock-max-distance") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-scan-context-relock-max-distance requires a numeric value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.scan_context_relock_max_distance =
          std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-scan-context-relock-max-distance=", 0) == 0) {
      fixed_map_ndt_options.scan_context_relock_max_distance =
          std::stod(arg.substr(
              std::string("--fixed-map-ndt-scan-context-relock-max-distance=").size()));
      continue;
    }
    if (arg == "--fixed-map-ndt-scan-context-relock-max-ndt-score") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-scan-context-relock-max-ndt-score requires a numeric value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.scan_context_relock_max_ndt_score =
          std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-scan-context-relock-max-ndt-score=", 0) == 0) {
      fixed_map_ndt_options.scan_context_relock_max_ndt_score =
          std::stod(arg.substr(
              std::string("--fixed-map-ndt-scan-context-relock-max-ndt-score=").size()));
      continue;
    }
    if (arg == "--fixed-map-ndt-scan-context-relock-max-score-delta") {
      if (i + 1 >= argc) {
        std::cerr << "--fixed-map-ndt-scan-context-relock-max-score-delta requires a numeric value"
                  << std::endl;
        return 1;
      }
      fixed_map_ndt_options.scan_context_relock_max_score_delta =
          std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--fixed-map-ndt-scan-context-relock-max-score-delta=", 0) == 0) {
      fixed_map_ndt_options.scan_context_relock_max_score_delta =
          std::stod(arg.substr(
              std::string("--fixed-map-ndt-scan-context-relock-max-score-delta=").size()));
      continue;
    }
    if (arg == "--kiss-fast-profile") {
      kiss_icp_options.source_voxel_size = 0.75;
      kiss_icp_options.max_source_points = 2500;
      kiss_icp_options.voxel_size = 1.25;
      kiss_icp_options.initial_threshold = 1.75;
      kiss_icp_options.max_points_per_voxel = 10;
      kiss_icp_options.max_icp_iterations = 20;
      kiss_icp_options.local_map_radius = 45.0;
      kiss_icp_options.map_cleanup_interval = 2;
      kiss_multi_horizon_options.frontend = kiss_icp_options;
      continue;
    }
    if (arg == "--kiss-upstream-profile") {
      // Upstream KISS-ICP 1.3.0 defaults (max_range 100 -> voxel 1.0 m,
      // 20 points/voxel, initial threshold 2.0, 500 iterations at 1e-4,
      // 27-voxel search, 1.5 * voxel registration subsample, map cropped at
      // max_range every frame). The scan is no longer pre-voxelized or capped;
      // the shared loader still drops returns beyond 80 m unless
      // --input-max-range-m raises it.
      kiss_icp_options.source_voxel_size = 0.0;
      kiss_icp_options.max_source_points =
          std::numeric_limits<std::size_t>::max();
      kiss_icp_options.voxel_size = 1.0;
      kiss_icp_options.initial_threshold = 2.0;
      kiss_icp_options.max_points_per_voxel = 20;
      kiss_icp_options.max_icp_iterations = 500;
      kiss_icp_options.local_map_radius = 100.0;
      kiss_icp_options.map_cleanup_interval = 1;
      kiss_icp_options.neighbor_voxel_radius = 1;
      kiss_icp_options.min_range = 0.0;
      kiss_icp_options.convergence_criterion = 1e-4;
      kiss_icp_options.registration_voxel_multiplier = 1.5;
      continue;
    }
    if (arg == "--kiss-dense-profile") {
      kiss_icp_options.source_voxel_size = 0.35;
      kiss_icp_options.max_source_points = 6000;
      kiss_icp_options.voxel_size = 0.8;
      kiss_icp_options.initial_threshold = 1.25;
      kiss_icp_options.max_points_per_voxel = 16;
      kiss_icp_options.max_icp_iterations = 40;
      kiss_icp_options.local_map_radius = 80.0;
      kiss_icp_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--genz-fast-profile") {
      genz_icp_options.source_voxel_size = 0.75;
      genz_icp_options.max_source_points = 2500;
      genz_icp_options.voxel_size = 1.25;
      genz_icp_options.initial_threshold = 1.75;
      genz_icp_options.max_points_per_voxel = 10;
      genz_icp_options.max_icp_iterations = 20;
      genz_icp_options.planarity_threshold = 0.55;
      genz_icp_options.local_map_radius = 45.0;
      genz_icp_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--genz-dense-profile") {
      genz_icp_options.source_voxel_size = 0.35;
      genz_icp_options.max_source_points = 6000;
      genz_icp_options.voxel_size = 0.8;
      genz_icp_options.initial_threshold = 1.25;
      genz_icp_options.max_points_per_voxel = 16;
      genz_icp_options.max_icp_iterations = 40;
      genz_icp_options.planarity_threshold = 0.5;
      genz_icp_options.local_map_radius = 80.0;
      genz_icp_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--genz-planarity-threshold") {
      if (i + 1 >= argc) {
        std::cerr << "--genz-planarity-threshold requires a numeric value"
                  << std::endl;
        return 1;
      }
      genz_icp_options.planarity_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--genz-planarity-threshold=", 0) == 0) {
      genz_icp_options.planarity_threshold =
          std::stod(arg.substr(std::string("--genz-planarity-threshold=").size()));
      continue;
    }
    if (arg == "--adaptive-icp-fast-profile") {
      adaptive_icp_options.source_voxel_size = 0.75;
      adaptive_icp_options.max_source_points = 2500;
      adaptive_icp_options.voxel_size = 1.25;
      adaptive_icp_options.initial_threshold = 1.75;
      adaptive_icp_options.max_points_per_voxel = 10;
      adaptive_icp_options.max_icp_iterations = 20;
      adaptive_icp_options.coarse_max_iterations = 6;
      adaptive_icp_options.planarity_threshold = 0.55;
      adaptive_icp_options.local_map_radius = 45.0;
      adaptive_icp_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--adaptive-icp-dense-profile") {
      adaptive_icp_options.source_voxel_size = 0.35;
      adaptive_icp_options.max_source_points = 6000;
      adaptive_icp_options.voxel_size = 0.8;
      adaptive_icp_options.initial_threshold = 1.25;
      adaptive_icp_options.max_points_per_voxel = 16;
      adaptive_icp_options.max_icp_iterations = 40;
      adaptive_icp_options.coarse_max_iterations = 10;
      adaptive_icp_options.planarity_threshold = 0.5;
      adaptive_icp_options.local_map_radius = 80.0;
      adaptive_icp_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--adaptive-icp-density-percentile") {
      if (i + 1 >= argc) {
        std::cerr << "--adaptive-icp-density-percentile requires a numeric value"
                  << std::endl;
        return 1;
      }
      adaptive_icp_options.density_percentile = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--adaptive-icp-reliable-tau") {
      if (i + 1 >= argc) {
        std::cerr << "--adaptive-icp-reliable-tau requires a numeric value"
                  << std::endl;
        return 1;
      }
      adaptive_icp_options.reliable_translation_tau = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--d2lio-fast-profile") {
      d2lio_options.source_voxel_size = 0.75;
      d2lio_options.max_source_points = 2500;
      d2lio_options.voxel_size = 1.25;
      d2lio_options.max_points_per_voxel = 10;
      d2lio_options.max_icp_iterations = 20;
      d2lio_options.local_map_radius = 45.0;
      d2lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--d2lio-dense-profile") {
      d2lio_options.source_voxel_size = 0.35;
      d2lio_options.max_source_points = 6000;
      d2lio_options.voxel_size = 0.8;
      d2lio_options.max_points_per_voxel = 16;
      d2lio_options.max_icp_iterations = 40;
      d2lio_options.local_map_radius = 80.0;
      d2lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--d2lio-degeneracy-ratio") {
      if (i + 1 >= argc) {
        std::cerr << "--d2lio-degeneracy-ratio requires a value"
                  << std::endl;
        return 1;
      }
      d2lio_options.degeneracy_ratio = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--d2lio-imu-prior-weight") {
      if (i + 1 >= argc) {
        std::cerr << "--d2lio-imu-prior-weight requires a value" << std::endl;
        return 1;
      }
      d2lio_options.imu_prior_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-voxelmap-fast-profile") {
      ct_voxelmap_options.source_voxel_size = 0.75;
      ct_voxelmap_options.max_source_points = 2500;
      ct_voxelmap_options.voxel_size = 1.25;
      ct_voxelmap_options.voxel_min_points = 5;
      ct_voxelmap_options.max_icp_iterations = 20;
      ct_voxelmap_options.local_map_radius = 45.0;
      ct_voxelmap_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--ct-voxelmap-dense-profile") {
      ct_voxelmap_options.source_voxel_size = 0.35;
      ct_voxelmap_options.max_source_points = 6000;
      ct_voxelmap_options.voxel_size = 0.8;
      ct_voxelmap_options.voxel_min_points = 8;
      ct_voxelmap_options.max_icp_iterations = 40;
      ct_voxelmap_options.local_map_radius = 80.0;
      ct_voxelmap_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--ct-voxelmap-planarity-ratio") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-voxelmap-planarity-ratio requires a value"
                  << std::endl;
        return 1;
      }
      ct_voxelmap_options.planarity_ratio = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--r-voxelmap-fast-profile") {
      // R-VoxelMap は平面ベースなので密な入力が必要 (疎だと平面が形成されない)。
      r_voxelmap_options.source_voxel_size = 0.45;
      r_voxelmap_options.max_source_points = 5000;
      r_voxelmap_options.voxel_size = 1.0;
      r_voxelmap_options.max_icp_iterations = 20;
      r_voxelmap_options.max_depth = 2;
      r_voxelmap_options.local_map_radius = 45.0;
      r_voxelmap_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--r-voxelmap-dense-profile") {
      r_voxelmap_options.source_voxel_size = 0.35;
      r_voxelmap_options.max_source_points = 6000;
      r_voxelmap_options.voxel_size = 0.8;
      r_voxelmap_options.max_icp_iterations = 40;
      r_voxelmap_options.max_depth = 2;
      r_voxelmap_options.max_plane_weight = 100.0;
      r_voxelmap_options.icp_damping = 1e-3;
      r_voxelmap_options.huber_residual = 0.5;
      r_voxelmap_options.max_iteration_translation = 0.5;
      r_voxelmap_options.max_iteration_rotation = 0.1;
      r_voxelmap_options.min_map_matched_ratio = 0.03;
      r_voxelmap_options.max_registration_translation = 1.0;
      r_voxelmap_options.max_registration_rotation = 0.20;
      r_voxelmap_options.max_map_fallback_translation_delta = 0.20;
      r_voxelmap_options.max_map_fallback_rotation_delta = 0.04;
      r_voxelmap_options.enable_scan_to_scan_fallback = true;
      r_voxelmap_options.local_map_radius = 80.0;
      r_voxelmap_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--r-voxelmap-max-depth") {
      if (i + 1 >= argc) { std::cerr << "--r-voxelmap-max-depth requires a value" << std::endl; return 1; }
      r_voxelmap_options.max_depth = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--r-voxelmap-max-registration-translation") {
      if (i + 1 >= argc) { std::cerr << "--r-voxelmap-max-registration-translation requires a value" << std::endl; return 1; }
      r_voxelmap_options.max_registration_translation = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--r-voxelmap-max-registration-rotation") {
      if (i + 1 >= argc) { std::cerr << "--r-voxelmap-max-registration-rotation requires a value" << std::endl; return 1; }
      r_voxelmap_options.max_registration_rotation = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--r-voxelmap-map-fallback-translation-delta") {
      if (i + 1 >= argc) { std::cerr << "--r-voxelmap-map-fallback-translation-delta requires a value" << std::endl; return 1; }
      r_voxelmap_options.max_map_fallback_translation_delta = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--r-voxelmap-map-fallback-rotation-delta") {
      if (i + 1 >= argc) { std::cerr << "--r-voxelmap-map-fallback-rotation-delta requires a value" << std::endl; return 1; }
      r_voxelmap_options.max_map_fallback_rotation_delta = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--damm-loam-fast-profile") {
      damm_loam_options.source_voxel_size = 0.5;
      damm_loam_options.max_source_points = 4000;
      damm_loam_options.voxel_size = 1.0;
      damm_loam_options.max_icp_iterations = 20;
      damm_loam_options.local_map_radius = 45.0;
      damm_loam_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--damm-loam-dense-profile") {
      damm_loam_options.source_voxel_size = 0.35;
      damm_loam_options.max_source_points = 6000;
      damm_loam_options.voxel_size = 0.8;
      damm_loam_options.max_icp_iterations = 40;
      damm_loam_options.local_map_radius = 80.0;
      damm_loam_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--damm-loam-degeneracy-ratio") {
      if (i + 1 >= argc) { std::cerr << "--damm-loam-degeneracy-ratio requires a value" << std::endl; return 1; }
      damm_loam_options.degeneracy_ratio = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--damm-loam-edge-weight") {
      if (i + 1 >= argc) { std::cerr << "--damm-loam-edge-weight requires a value" << std::endl; return 1; }
      damm_loam_options.edge_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--lodestar-fast-profile") {
      lodestar_options.source_voxel_size = 0.5;
      lodestar_options.max_source_points = 4000;
      lodestar_options.voxel_size = 1.0;
      lodestar_options.max_icp_iterations = 20;
      lodestar_options.local_map_radius = 45.0;
      lodestar_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--lodestar-dense-profile") {
      lodestar_options.source_voxel_size = 0.35;
      lodestar_options.max_source_points = 6000;
      lodestar_options.voxel_size = 0.8;
      lodestar_options.max_icp_iterations = 40;
      lodestar_options.local_map_radius = 80.0;
      lodestar_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--lodestar-t-chi") {
      if (i + 1 >= argc) { std::cerr << "--lodestar-t-chi requires a value" << std::endl; return 1; }
      lodestar_options.t_chi = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--lodestar-anchor-strength") {
      if (i + 1 >= argc) { std::cerr << "--lodestar-anchor-strength requires a value" << std::endl; return 1; }
      lodestar_options.anchor_strength = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--lodestar-no-data-exploitation") {
      lodestar_options.enable_data_exploitation = false;
      continue;
    }
    // --- terrain_rbf_lio ---
    if (arg == "--terrain-rbf-fast-profile") {
      terrain_rbf_options.source_voxel_size = 0.5;
      terrain_rbf_options.max_source_points = 4000;
      terrain_rbf_options.voxel_size = 1.0;
      terrain_rbf_options.max_icp_iterations = 20;
      terrain_rbf_options.local_map_radius = 45.0;
      terrain_rbf_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--terrain-rbf-dense-profile") {
      terrain_rbf_options.source_voxel_size = 0.35;
      terrain_rbf_options.max_source_points = 6000;
      terrain_rbf_options.voxel_size = 0.8;
      terrain_rbf_options.max_icp_iterations = 40;
      terrain_rbf_options.local_map_radius = 80.0;
      terrain_rbf_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--terrain-rbf-weight") {
      if (i + 1 >= argc) { std::cerr << "--terrain-rbf-weight requires a value" << std::endl; return 1; }
      terrain_rbf_options.terrain_weight = std::stod(argv[++i]);
      continue;
    }
    // --- lidar_iba ---
    if (arg == "--lidar-iba-fast-profile") {
      lidar_iba_options.source_voxel_size = 0.5;
      lidar_iba_options.max_source_points = 4000;
      lidar_iba_options.voxel_size = 1.0;
      lidar_iba_options.max_icp_iterations = 20;
      lidar_iba_options.local_map_radius = 45.0;
      lidar_iba_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--lidar-iba-dense-profile") {
      lidar_iba_options.source_voxel_size = 0.35;
      lidar_iba_options.max_source_points = 6000;
      lidar_iba_options.voxel_size = 0.8;
      lidar_iba_options.max_icp_iterations = 40;
      lidar_iba_options.local_map_radius = 80.0;
      lidar_iba_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--lidar-iba-no-ba") {
      lidar_iba_options.enable_ba = false;
      continue;
    }
    if (arg == "--lidar-iba-pose-prior-weight") {
      if (i + 1 >= argc) { std::cerr << "--lidar-iba-pose-prior-weight requires a value" << std::endl; return 1; }
      lidar_iba_options.pose_prior_weight = std::stod(argv[++i]);
      continue;
    }
    // --- dali_slam ---
    if (arg == "--dali-slam-fast-profile") {
      dali_slam_options.source_voxel_size = 0.5;
      dali_slam_options.max_source_points = 4000;
      dali_slam_options.voxel_size = 1.0;
      dali_slam_options.max_icp_iterations = 20;
      dali_slam_options.local_map_radius = 45.0;
      dali_slam_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--dali-slam-dense-profile") {
      dali_slam_options.source_voxel_size = 0.35;
      dali_slam_options.max_source_points = 6000;
      dali_slam_options.voxel_size = 0.8;
      dali_slam_options.max_icp_iterations = 40;
      dali_slam_options.local_map_radius = 80.0;
      dali_slam_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--dali-slam-no-deskew") {
      dali_slam_options.enable_deskew = false;
      continue;
    }
    if (arg == "--dali-slam-deskew") {
      dali_slam_options.enable_deskew = true;
      continue;
    }
    if (arg == "--dali-slam-degeneracy-ratio") {
      if (i + 1 >= argc) { std::cerr << "--dali-slam-degeneracy-ratio requires a value" << std::endl; return 1; }
      dali_slam_options.degeneracy_ratio = std::stod(argv[++i]);
      continue;
    }
    // --- intensity_flow ---
    if (arg == "--intensity-flow-fast-profile") {
      intensity_flow_options.source_voxel_size = 0.5;
      intensity_flow_options.max_source_points = 4000;
      intensity_flow_options.voxel_size = 1.0;
      intensity_flow_options.max_icp_iterations = 20;
      intensity_flow_options.local_map_radius = 45.0;
      intensity_flow_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--intensity-flow-dense-profile") {
      intensity_flow_options.source_voxel_size = 0.35;
      intensity_flow_options.max_source_points = 6000;
      intensity_flow_options.voxel_size = 0.8;
      intensity_flow_options.max_icp_iterations = 40;
      intensity_flow_options.local_map_radius = 80.0;
      intensity_flow_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--intensity-flow-keep-ratio") {
      if (i + 1 >= argc) { std::cerr << "--intensity-flow-keep-ratio requires a value" << std::endl; return 1; }
      intensity_flow_options.gf_keep_ratio = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--intensity-flow-no-intensity") {
      intensity_flow_options.enable_intensity = false;
      continue;
    }
    // --- svn_icp ---
    if (arg == "--svn-icp-fast-profile") {
      svn_icp_options.source_voxel_size = 0.5;
      svn_icp_options.max_source_points = 4000;
      svn_icp_options.voxel_size = 1.0;
      svn_icp_options.num_particles = 8;
      svn_icp_options.svn_iterations = 3;
      svn_icp_options.local_map_radius = 45.0;
      svn_icp_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--svn-icp-dense-profile") {
      svn_icp_options.source_voxel_size = 0.35;
      svn_icp_options.max_source_points = 6000;
      svn_icp_options.voxel_size = 0.8;
      svn_icp_options.num_particles = 12;
      svn_icp_options.svn_iterations = 4;
      svn_icp_options.local_map_radius = 80.0;
      svn_icp_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--svn-icp-num-particles") {
      if (i + 1 >= argc) { std::cerr << "--svn-icp-num-particles requires a value" << std::endl; return 1; }
      svn_icp_options.num_particles = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--svn-icp-iterations") {
      if (i + 1 >= argc) { std::cerr << "--svn-icp-iterations requires a value" << std::endl; return 1; }
      svn_icp_options.svn_iterations = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--svn-icp-lidar-sigma") {
      if (i + 1 >= argc) { std::cerr << "--svn-icp-lidar-sigma requires a value" << std::endl; return 1; }
      svn_icp_options.lidar_sigma = std::stod(argv[++i]);
      continue;
    }
    // --- pcr_dat ---
    if (arg == "--pcr-dat-fast-profile") {
      pcr_dat_options.source_voxel_size = 0.5;
      pcr_dat_options.max_source_points = 4000;
      pcr_dat_options.voxel_size = 1.0;
      pcr_dat_options.max_iterations = 15;
      pcr_dat_options.local_map_radius = 45.0;
      pcr_dat_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--pcr-dat-dense-profile") {
      pcr_dat_options.source_voxel_size = 0.35;
      pcr_dat_options.max_source_points = 6000;
      pcr_dat_options.voxel_size = 0.8;
      pcr_dat_options.max_iterations = 20;
      pcr_dat_options.local_map_radius = 80.0;
      pcr_dat_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--pcr-dat-distribution-min-points") {
      if (i + 1 >= argc) { std::cerr << "--pcr-dat-distribution-min-points requires a value" << std::endl; return 1; }
      pcr_dat_options.distribution_min_points = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--pcr-dat-distance-sigma") {
      if (i + 1 >= argc) { std::cerr << "--pcr-dat-distance-sigma requires a value" << std::endl; return 1; }
      pcr_dat_options.distance_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--pcr-dat-robust-scale") {
      if (i + 1 >= argc) { std::cerr << "--pcr-dat-robust-scale requires a value" << std::endl; return 1; }
      pcr_dat_options.robust_scale = std::stod(argv[++i]);
      continue;
    }
    // --- small_mighty ---
    if (arg == "--small-mighty-fast-profile") {
      small_mighty_options.source_voxel_size = 0.5;
      small_mighty_options.max_source_points = 4000;
      small_mighty_options.voxel_size = 1.0;
      small_mighty_options.max_iterations = 15;
      small_mighty_options.local_map_radius = 45.0;
      small_mighty_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--small-mighty-dense-profile") {
      small_mighty_options.source_voxel_size = 0.35;
      small_mighty_options.max_source_points = 6000;
      small_mighty_options.voxel_size = 0.8;
      small_mighty_options.max_iterations = 20;
      small_mighty_options.local_map_radius = 80.0;
      small_mighty_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--small-mighty-contribution-gain") {
      if (i + 1 >= argc) { std::cerr << "--small-mighty-contribution-gain requires a value" << std::endl; return 1; }
      small_mighty_options.contribution_gain = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--small-mighty-edge-weight") {
      if (i + 1 >= argc) { std::cerr << "--small-mighty-edge-weight requires a value" << std::endl; return 1; }
      small_mighty_options.edge_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--small-mighty-planar-min") {
      if (i + 1 >= argc) { std::cerr << "--small-mighty-planar-min requires a value" << std::endl; return 1; }
      small_mighty_options.planar_min = std::stod(argv[++i]);
      continue;
    }
    // --- m_gclo ---
    if (arg == "--m-gclo-fast-profile") {
      m_gclo_options.source_voxel_size = 0.5;
      m_gclo_options.max_source_points = 4000;
      m_gclo_options.voxel_size = 1.0;
      m_gclo_options.max_iterations = 15;
      m_gclo_options.local_map_radius = 45.0;
      m_gclo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--m-gclo-dense-profile") {
      m_gclo_options.source_voxel_size = 0.35;
      m_gclo_options.max_source_points = 6000;
      m_gclo_options.voxel_size = 0.8;
      m_gclo_options.max_iterations = 20;
      m_gclo_options.local_map_radius = 80.0;
      m_gclo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--m-gclo-ground-weight") {
      if (i + 1 >= argc) { std::cerr << "--m-gclo-ground-weight requires a value" << std::endl; return 1; }
      m_gclo_options.ground_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--m-gclo-no-ground") {
      m_gclo_options.ground_constraints = false;
      continue;
    }
    if (arg == "--m-gclo-ground-normal-threshold") {
      if (i + 1 >= argc) { std::cerr << "--m-gclo-ground-normal-threshold requires a value" << std::endl; return 1; }
      m_gclo_options.ground_normal_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--m-gclo-uncertainty-range-ref") {
      if (i + 1 >= argc) { std::cerr << "--m-gclo-uncertainty-range-ref requires a value" << std::endl; return 1; }
      m_gclo_options.uncertainty_range_ref = std::stod(argv[++i]);
      continue;
    }
    // --- quadric_lo ---
    if (arg == "--quadric-lo-fast-profile") {
      quadric_lo_options.source_voxel_size = 0.5;
      quadric_lo_options.max_source_points = 4000;
      quadric_lo_options.voxel_size = 1.0;
      quadric_lo_options.max_iterations = 15;
      quadric_lo_options.local_map_radius = 45.0;
      quadric_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--quadric-lo-dense-profile") {
      quadric_lo_options.source_voxel_size = 0.35;
      quadric_lo_options.max_source_points = 6000;
      quadric_lo_options.voxel_size = 0.8;
      quadric_lo_options.max_iterations = 20;
      quadric_lo_options.local_map_radius = 80.0;
      quadric_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--quadric-lo-quadric-min-neighbors") {
      if (i + 1 >= argc) { std::cerr << "--quadric-lo-quadric-min-neighbors requires a value" << std::endl; return 1; }
      quadric_lo_options.quadric_min_neighbors = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--quadric-lo-quadric-weight") {
      if (i + 1 >= argc) { std::cerr << "--quadric-lo-quadric-weight requires a value" << std::endl; return 1; }
      quadric_lo_options.quadric_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--quadric-lo-no-plane-fallback") {
      quadric_lo_options.allow_plane_fallback = false;
      continue;
    }
    // --- dilo ---
    if (arg == "--dilo-paper-odometry") {
      dilo_options.paper_odometry = true;
      continue;
    }
    if (arg == "--dilo-paper-window" && i + 1 < argc) {
      dilo_options.paper_window = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-update-iterations" && i + 1 < argc) {
      dilo_options.paper_update_iterations = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-keypoints" && i + 1 < argc) {
      dilo_options.paper_keypoints_per_list = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-edges") {
      dilo_options.paper_edges = true;
      continue;
    }
    if (arg == "--dilo-paper-top-elevation") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-top-elevation requires a value" << std::endl; return 1; }
      dilo_options.paper_top_elevation_deg = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-height") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-height requires a value" << std::endl; return 1; }
      dilo_options.paper_height = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-min-planarity") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-min-planarity requires a value" << std::endl; return 1; }
      dilo_options.paper_min_planarity = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-keypoint-cell") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-keypoint-cell requires a value" << std::endl; return 1; }
      dilo_options.paper_keypoint_cell = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-fill-slope") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-fill-slope requires a value" << std::endl; return 1; }
      dilo_options.paper_fill_slope = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-degenerate-ratio") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-degenerate-ratio requires a value" << std::endl; return 1; }
      dilo_options.paper_degenerate_ratio = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-max-fill-gap") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-max-fill-gap requires a value" << std::endl; return 1; }
      dilo_options.paper_max_fill_gap = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-edge-detector") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-edge-detector requires a value" << std::endl; return 1; }
      dilo_options.paper_edge_detector = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-edge-subpixel") {
      dilo_options.paper_edge_subpixel = true;
      continue;
    }
    if (arg == "--dilo-paper-edge-dofs") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-edge-dofs requires a value" << std::endl; return 1; }
      dilo_options.paper_edge_dofs = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-edge-sum-weight") {
      if (i + 1 >= argc) { std::cerr << "--dilo-paper-edge-sum-weight requires a value" << std::endl; return 1; }
      dilo_options.paper_edge_sum_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-paper-causal") {
      dilo_options.paper_causal_output = true;
      continue;
    }
    if (arg == "--dilo-fast-profile") {
      dilo_options.source_voxel_size = 0.0;  // SRI は全点群から
      dilo_options.max_source_points = 200000;
      dilo_options.gn_voxel_size = 0.6;
      dilo_options.sri_width = 900;
      dilo_options.max_iterations = 20;
      continue;
    }
    if (arg == "--dilo-dense-profile") {
      dilo_options.source_voxel_size = 0.0;  // SRI は全点群から
      dilo_options.max_source_points = 200000;
      dilo_options.gn_voxel_size = 0.4;
      dilo_options.sri_width = 1024;
      dilo_options.max_iterations = 30;
      continue;
    }
    if (arg == "--dilo-keyframe-translation") {
      if (i + 1 >= argc) { std::cerr << "--dilo-keyframe-translation requires a value" << std::endl; return 1; }
      dilo_options.keyframe_translation = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-keyframe-rotation-deg") {
      if (i + 1 >= argc) { std::cerr << "--dilo-keyframe-rotation-deg requires a value" << std::endl; return 1; }
      dilo_options.keyframe_rotation_deg = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-sri-width") {
      if (i + 1 >= argc) { std::cerr << "--dilo-sri-width requires a value" << std::endl; return 1; }
      dilo_options.sri_width = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-lookup-radius") {
      if (i + 1 >= argc) { std::cerr << "--dilo-lookup-radius requires a value" << std::endl; return 1; }
      dilo_options.lookup_radius = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--dilo-lookup-max-dist") {
      if (i + 1 >= argc) { std::cerr << "--dilo-lookup-max-dist requires a value" << std::endl; return 1; }
      dilo_options.max_lookup_point_distance = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--dilo-initial-threshold") {
      if (i + 1 >= argc) { std::cerr << "--dilo-initial-threshold requires a value" << std::endl; return 1; }
      dilo_options.initial_threshold = std::stod(argv[++i]);
      continue;
    }
    // --- nhc_lio ---
    if (arg == "--nhc-lio-fast-profile") {
      nhc_lio_options.source_voxel_size = 0.5;
      nhc_lio_options.max_source_points = 4000;
      nhc_lio_options.voxel_size = 1.0;
      nhc_lio_options.max_iterations = 15;
      nhc_lio_options.local_map_radius = 45.0;
      nhc_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--nhc-lio-dense-profile") {
      nhc_lio_options.source_voxel_size = 0.35;
      nhc_lio_options.max_source_points = 6000;
      nhc_lio_options.voxel_size = 0.8;
      nhc_lio_options.max_iterations = 20;
      nhc_lio_options.local_map_radius = 80.0;
      nhc_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--nhc-lio-weight") {
      if (i + 1 >= argc) { std::cerr << "--nhc-lio-weight requires a value" << std::endl; return 1; }
      nhc_lio_options.nhc_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--nhc-lio-yaw-ref") {
      if (i + 1 >= argc) { std::cerr << "--nhc-lio-yaw-ref requires a value" << std::endl; return 1; }
      nhc_lio_options.nhc_yaw_ref = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--nhc-lio-disable") {
      nhc_lio_options.enable_nhc = false;
      continue;
    }
    // --- student_t_lo ---
    if (arg == "--student-t-lo-fast-profile") {
      student_t_lo_options.source_voxel_size = 0.5;
      student_t_lo_options.max_source_points = 4000;
      student_t_lo_options.voxel_size = 1.0;
      student_t_lo_options.max_iterations = 15;
      student_t_lo_options.local_map_radius = 45.0;
      student_t_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--student-t-lo-dense-profile") {
      student_t_lo_options.source_voxel_size = 0.35;
      student_t_lo_options.max_source_points = 6000;
      student_t_lo_options.voxel_size = 0.8;
      student_t_lo_options.max_iterations = 20;
      student_t_lo_options.local_map_radius = 80.0;
      student_t_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--student-t-lo-dof") {
      if (i + 1 >= argc) { std::cerr << "--student-t-lo-dof requires a value" << std::endl; return 1; }
      student_t_lo_options.student_t_dof = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--student-t-lo-scale") {
      if (i + 1 >= argc) { std::cerr << "--student-t-lo-scale requires a value" << std::endl; return 1; }
      student_t_lo_options.scale_init = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--student-t-lo-fixed-scale") {
      student_t_lo_options.estimate_scale = false;
      continue;
    }
    if (arg == "--student-t-lo-gaussian") {
      student_t_lo_options.enable_student_t = false;
      continue;
    }
    // --- spectral_lo ---
    if (arg == "--spectral-lo-bev-size") {
      if (i + 1 >= argc) { std::cerr << "--spectral-lo-bev-size requires a value" << std::endl; return 1; }
      spectral_lo_options.bev_size = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--spectral-lo-bev-range") {
      if (i + 1 >= argc) { std::cerr << "--spectral-lo-bev-range requires a value" << std::endl; return 1; }
      spectral_lo_options.bev_range = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--spectral-lo-max-yaw-deg") {
      if (i + 1 >= argc) { std::cerr << "--spectral-lo-max-yaw-deg requires a value" << std::endl; return 1; }
      spectral_lo_options.max_yaw_deg = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--spectral-lo-keyframe-translation") {
      if (i + 1 >= argc) { std::cerr << "--spectral-lo-keyframe-translation requires a value" << std::endl; return 1; }
      spectral_lo_options.keyframe_translation = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--spectral-lo-translation-refinement-iters") {
      if (i + 1 >= argc) { std::cerr << "--spectral-lo-translation-refinement-iters requires a value" << std::endl; return 1; }
      spectral_lo_options.translation_refinement_iterations = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--spectral-lo-max-translation-refinement") {
      if (i + 1 >= argc) { std::cerr << "--spectral-lo-max-translation-refinement requires a value" << std::endl; return 1; }
      spectral_lo_options.max_translation_refinement_m = std::stod(argv[++i]);
      continue;
    }
    // --- gmm_lo ---
    if (arg == "--gmm-lo-fast-profile") {
      gmm_lo_options.source_voxel_size = 0.5;
      gmm_lo_options.max_source_points = 4000;
      gmm_lo_options.voxel_size = 1.0;
      gmm_lo_options.max_iterations = 15;
      gmm_lo_options.local_map_radius = 45.0;
      gmm_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--gmm-lo-dense-profile") {
      gmm_lo_options.source_voxel_size = 0.35;
      gmm_lo_options.max_source_points = 6000;
      gmm_lo_options.voxel_size = 0.8;
      gmm_lo_options.max_iterations = 20;
      gmm_lo_options.local_map_radius = 80.0;
      gmm_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--gmm-lo-sigma-init") {
      if (i + 1 >= argc) { std::cerr << "--gmm-lo-sigma-init requires a value" << std::endl; return 1; }
      gmm_lo_options.sigma_init = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--gmm-lo-sigma-final") {
      if (i + 1 >= argc) { std::cerr << "--gmm-lo-sigma-final requires a value" << std::endl; return 1; }
      gmm_lo_options.sigma_final = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--gmm-lo-outlier-weight") {
      if (i + 1 >= argc) { std::cerr << "--gmm-lo-outlier-weight requires a value" << std::endl; return 1; }
      gmm_lo_options.outlier_weight = std::stod(argv[++i]);
      continue;
    }
    // --- gnc_lo ---
    if (arg == "--gnc-lo-fast-profile") {
      gnc_lo_options.source_voxel_size = 0.5;
      gnc_lo_options.max_source_points = 4000;
      gnc_lo_options.voxel_size = 1.0;
      gnc_lo_options.max_iterations = 15;
      gnc_lo_options.local_map_radius = 45.0;
      gnc_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--gnc-lo-dense-profile") {
      gnc_lo_options.source_voxel_size = 0.35;
      gnc_lo_options.max_source_points = 6000;
      gnc_lo_options.voxel_size = 0.8;
      gnc_lo_options.max_iterations = 20;
      gnc_lo_options.local_map_radius = 80.0;
      gnc_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--gnc-lo-truncation") {
      if (i + 1 >= argc) { std::cerr << "--gnc-lo-truncation requires a value" << std::endl; return 1; }
      gnc_lo_options.gnc_truncation = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--gnc-lo-factor") {
      if (i + 1 >= argc) { std::cerr << "--gnc-lo-factor requires a value" << std::endl; return 1; }
      gnc_lo_options.gnc_factor = std::stod(argv[++i]);
      continue;
    }
    // --- mcc_lo ---
    if (arg == "--mcc-lo-fast-profile") {
      mcc_lo_options.source_voxel_size = 0.5;
      mcc_lo_options.max_source_points = 4000;
      mcc_lo_options.voxel_size = 1.0;
      mcc_lo_options.max_iterations = 15;
      mcc_lo_options.local_map_radius = 45.0;
      mcc_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--mcc-lo-dense-profile") {
      mcc_lo_options.source_voxel_size = 0.35;
      mcc_lo_options.max_source_points = 6000;
      mcc_lo_options.voxel_size = 0.8;
      mcc_lo_options.max_iterations = 20;
      mcc_lo_options.local_map_radius = 80.0;
      mcc_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--mcc-lo-sigma") {
      if (i + 1 >= argc) { std::cerr << "--mcc-lo-sigma requires a value" << std::endl; return 1; }
      mcc_lo_options.mcc_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mcc-lo-fixed-sigma") {
      mcc_lo_options.mcc_adaptive_sigma = false;
      continue;
    }
    // --- mesh_loam ---
    if (arg == "--mesh-loam-fast-profile") {
      mesh_loam_options.source_voxel_size = 0.5;
      mesh_loam_options.max_source_points = 5000;
      mesh_loam_options.voxel_size = 0.2;
      mesh_loam_options.mesh_update_interval = 8;
      mesh_loam_options.local_map_radius = 60.0;
      continue;
    }
    if (arg == "--mesh-loam-dense-profile") {
      mesh_loam_options.source_voxel_size = 0.25;
      mesh_loam_options.max_source_points = 8000;
      mesh_loam_options.voxel_size = 0.1;
      mesh_loam_options.mesh_update_interval = 5;
      mesh_loam_options.local_map_radius = 80.0;
      continue;
    }
    if (arg == "--mesh-loam-paper-odometry") {
      // Paper input and association: 0.1 m input (the map voxel size), no
      // point cap, normals from 10 NN within 0.5 m cells, nearest facet.
      mesh_loam_options.paper_odometry = true;
      mesh_loam_options.source_voxel_size = 0.1;
      mesh_loam_options.max_source_points = 1000000;
      mesh_loam_options.voxel_size = 0.1;
      mesh_loam_options.mesh_update_interval = 5;
      mesh_loam_options.local_map_radius = 80.0;
      mesh_loam_options.nearest_facet = true;
      mesh_loam_options.normal_neighbors = 10;
      mesh_loam_options.normal_search_radius = 0.5;
      continue;
    }
    if (arg == "--mesh-loam-nearest-facet") {
      mesh_loam_options.nearest_facet = true;
      continue;
    }
    if (arg == "--mesh-loam-marching-cubes") {
      mesh_loam_options.marching_cubes = true;
      continue;
    }
    if (arg == "--mesh-loam-full-block-meshing") {
      mesh_loam_options.dirty_cells = false;
      continue;
    }
    if (arg == "--mesh-loam-freeze-radius") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-freeze-radius requires a value" << std::endl; return 1; }
      mesh_loam_options.freeze_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-keep-mesh") {
      mesh_loam_options.keep_mesh = true;
      continue;
    }
    if (arg == "--mesh-loam-source-voxel") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-source-voxel requires a value" << std::endl; return 1; }
      mesh_loam_options.source_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-max-points") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-max-points requires a value" << std::endl; return 1; }
      mesh_loam_options.max_source_points = static_cast<size_t>(std::stoul(argv[++i]));
      continue;
    }
    if (arg == "--mesh-loam-normal-neighbors") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-normal-neighbors requires a value" << std::endl; return 1; }
      mesh_loam_options.normal_neighbors = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-normal-radius") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-normal-radius requires a value" << std::endl; return 1; }
      mesh_loam_options.normal_search_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-max-range") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-max-range requires a value" << std::endl; return 1; }
      mesh_loam_options.max_range = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-map-radius") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-map-radius requires a value" << std::endl; return 1; }
      mesh_loam_options.local_map_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-voxel-size") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-voxel-size requires a value" << std::endl; return 1; }
      mesh_loam_options.voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-cos-gate") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-cos-gate requires a value" << std::endl; return 1; }
      mesh_loam_options.cos_gate = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--mesh-loam-mesh-interval") {
      if (i + 1 >= argc) { std::cerr << "--mesh-loam-mesh-interval requires a value" << std::endl; return 1; }
      mesh_loam_options.mesh_update_interval = std::stoi(argv[++i]);
      continue;
    }
    // --- elo ---
    if (arg == "--elo-fast-profile") {
      elo_options.source_voxel_size = 0.25;
      elo_options.max_source_points = 35000;
      elo_options.sri_width = 1024;
      elo_options.bev_resolution = 0.3;
      elo_options.max_alignment_points = 8000;
      elo_options.max_iterations = 14;
      elo_options.ground_weight = 5.0;
      continue;
    }
    if (arg == "--elo-dense-profile") {
      elo_options.source_voxel_size = 0.15;
      elo_options.max_source_points = 80000;
      elo_options.sri_width = 2048;
      elo_options.bev_resolution = 0.2;
      elo_options.max_alignment_points = 18000;
      elo_options.max_iterations = 20;
      elo_options.ground_weight = 5.0;
      continue;
    }
    if (arg == "--elo-paper-profile") {
      // Paper mechanics: every raw point, 2048-wide range image, 0.1 m BEV,
      // count-normalised fusion w = 0.7 w2 (eqs. 1-2), two-sided ground test
      // (eq. 13), full-size normal patch (eq. 12), one vertex per BEV cell,
      // single-pixel association and plain Gauss-Newton.
      elo_options.paper_profile = true;
      elo_options.source_voxel_size = 0.0;
      elo_options.max_source_points = std::numeric_limits<size_t>::max();
      elo_options.sri_width = 2048;
      elo_options.bev_resolution = 0.1;
      elo_options.max_alignment_points = 0;
      elo_options.max_iterations = 20;
      elo_options.fusion_mode = 1;
      elo_options.ground_requires_both_sides = true;
      elo_options.normal_patch_full_size = true;
      elo_options.bev_keep_closest = true;
      elo_options.robust_scale = 0.0;
      elo_options.sri_search_radius_px = 0;
      continue;
    }
    if (arg == "--elo-ground-both-sides") {
      elo_options.ground_requires_both_sides = true;
      continue;
    }
    if (arg == "--elo-fov") {
      // up and down elevation limits of the SRI [deg], e.g. 10.67 -30.67 for an HDL-32E
      if (i + 2 >= argc) { std::cerr << "--elo-fov requires two values" << std::endl; return 1; }
      elo_options.sri_fov_up_deg = std::stod(argv[++i]);
      elo_options.sri_fov_down_deg = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--elo-sri-height") {
      if (i + 1 >= argc) { std::cerr << "--elo-sri-height requires a value" << std::endl; return 1; }
      elo_options.sri_height = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--elo-sensor-height") {
      if (i + 1 >= argc) { std::cerr << "--elo-sensor-height requires a value" << std::endl; return 1; }
      elo_options.sensor_height = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--elo-sri-fuse-same-surface") {
      elo_options.sri_fuse_same_surface = true;
      continue;
    }
    if (arg == "--elo-ground-no-forward") {
      elo_options.ground_constrains_forward = false;
      continue;
    }
    if (arg == "--elo-curvature-threshold") {
      if (i + 1 >= argc) { std::cerr << "--elo-curvature-threshold requires a value" << std::endl; return 1; }
      elo_options.curvature_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--elo-normal-full-patch") {
      elo_options.normal_patch_full_size = true;
      continue;
    }
    if (arg == "--elo-bev-keep-closest") {
      elo_options.bev_keep_closest = true;
      continue;
    }
    if (arg == "--elo-raw-input") {
      elo_options.source_voxel_size = 0.0;
      elo_options.max_source_points = std::numeric_limits<size_t>::max();
      elo_options.max_alignment_points = 0;
      continue;
    }
    if (arg == "--elo-fusion-mode") {
      if (i + 1 >= argc) { std::cerr << "--elo-fusion-mode requires a value" << std::endl; return 1; }
      elo_options.fusion_mode = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--elo-sri-search-radius") {
      if (i + 1 >= argc) { std::cerr << "--elo-sri-search-radius requires a value" << std::endl; return 1; }
      elo_options.sri_search_radius_px = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--elo-robust-scale") {
      if (i + 1 >= argc) { std::cerr << "--elo-robust-scale requires a value" << std::endl; return 1; }
      elo_options.robust_scale = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--elo-sri-width") {
      if (i + 1 >= argc) { std::cerr << "--elo-sri-width requires a value" << std::endl; return 1; }
      elo_options.sri_width = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--elo-bev-resolution") {
      if (i + 1 >= argc) { std::cerr << "--elo-bev-resolution requires a value" << std::endl; return 1; }
      elo_options.bev_resolution = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--elo-ground-weight") {
      if (i + 1 >= argc) { std::cerr << "--elo-ground-weight requires a value" << std::endl; return 1; }
      elo_options.ground_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--elo-max-alignment-points") {
      if (i + 1 >= argc) { std::cerr << "--elo-max-alignment-points requires a value" << std::endl; return 1; }
      elo_options.max_alignment_points = std::stoi(argv[++i]);
      continue;
    }
    // --- tc_lvgf ---
    if (arg == "--tc-lvgf-fast-profile") {
      tc_lvgf_options.source_voxel_size = 0.55;
      tc_lvgf_options.max_source_points = 3500;
      tc_lvgf_options.voxel_size = 1.1;
      tc_lvgf_options.registration_voxel_size = 1.0;
      tc_lvgf_options.max_registration_points = 2800;
      tc_lvgf_options.image_width = 768;
      tc_lvgf_options.image_height = 64;
      tc_lvgf_options.max_icp_iterations = 18;
      tc_lvgf_options.max_lidar_lines = 120;
      tc_lvgf_options.max_visual_lines = 80;
      tc_lvgf_options.line_weight = 0.2;
      tc_lvgf_options.direction_weight = 0.05;
      tc_lvgf_options.local_map_radius = 55.0;
      tc_lvgf_options.map_cleanup_interval = 3;
      continue;
    }
    if (arg == "--tc-lvgf-dense-profile") {
      tc_lvgf_options.source_voxel_size = 0.35;
      tc_lvgf_options.max_source_points = 7000;
      tc_lvgf_options.voxel_size = 0.8;
      tc_lvgf_options.registration_voxel_size = 0.7;
      tc_lvgf_options.max_registration_points = 5500;
      tc_lvgf_options.image_width = 1024;
      tc_lvgf_options.image_height = 80;
      tc_lvgf_options.max_icp_iterations = 32;
      tc_lvgf_options.max_lidar_lines = 220;
      tc_lvgf_options.max_visual_lines = 160;
      tc_lvgf_options.line_weight = 0.2;
      tc_lvgf_options.direction_weight = 0.05;
      tc_lvgf_options.local_map_radius = 80.0;
      tc_lvgf_options.map_cleanup_interval = 5;
      continue;
    }
    if (arg == "--tc-lvgf-line-weight") {
      if (i + 1 >= argc) { std::cerr << "--tc-lvgf-line-weight requires a value" << std::endl; return 1; }
      tc_lvgf_options.line_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--tc-lvgf-direction-weight") {
      if (i + 1 >= argc) { std::cerr << "--tc-lvgf-direction-weight requires a value" << std::endl; return 1; }
      tc_lvgf_options.direction_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--tc-lvgf-min-visual-lines") {
      if (i + 1 >= argc) { std::cerr << "--tc-lvgf-min-visual-lines requires a value" << std::endl; return 1; }
      tc_lvgf_options.min_visual_lines = std::stoi(argv[++i]);
      continue;
    }
    // --- opl_lvio ---
    if (arg == "--opl-lvio-fast-profile") {
      opl_lvio_options.source_voxel_size = 0.55;
      opl_lvio_options.max_source_points = 3500;
      opl_lvio_options.voxel_size = 1.1;
      opl_lvio_options.registration_voxel_size = 1.0;
      opl_lvio_options.max_registration_points = 2800;
      opl_lvio_options.image_width = 768;
      opl_lvio_options.image_height = 64;
      opl_lvio_options.max_icp_iterations = 18;
      opl_lvio_options.max_visual_points = 220;
      opl_lvio_options.max_lidar_lines = 120;
      opl_lvio_options.max_visual_lines = 80;
      opl_lvio_options.visual_point_weight = 0.06;
      opl_lvio_options.line_weight = 0.0;
      opl_lvio_options.direction_weight = 0.0;
      opl_lvio_options.local_map_radius = 55.0;
      opl_lvio_options.map_cleanup_interval = 3;
      continue;
    }
    if (arg == "--opl-lvio-dense-profile") {
      opl_lvio_options.source_voxel_size = 0.35;
      opl_lvio_options.max_source_points = 7000;
      opl_lvio_options.voxel_size = 0.8;
      opl_lvio_options.registration_voxel_size = 0.7;
      opl_lvio_options.max_registration_points = 5500;
      opl_lvio_options.image_width = 1024;
      opl_lvio_options.image_height = 80;
      opl_lvio_options.max_icp_iterations = 32;
      opl_lvio_options.max_visual_points = 420;
      opl_lvio_options.max_lidar_lines = 220;
      opl_lvio_options.max_visual_lines = 160;
      opl_lvio_options.visual_point_weight = 0.08;
      opl_lvio_options.line_weight = 0.0;
      opl_lvio_options.direction_weight = 0.0;
      opl_lvio_options.local_map_radius = 80.0;
      opl_lvio_options.map_cleanup_interval = 5;
      continue;
    }
    if (arg == "--opl-lvio-visual-point-weight") {
      if (i + 1 >= argc) { std::cerr << "--opl-lvio-visual-point-weight requires a value" << std::endl; return 1; }
      opl_lvio_options.visual_point_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--opl-lvio-line-weight") {
      if (i + 1 >= argc) { std::cerr << "--opl-lvio-line-weight requires a value" << std::endl; return 1; }
      opl_lvio_options.line_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--opl-lvio-direction-weight") {
      if (i + 1 >= argc) { std::cerr << "--opl-lvio-direction-weight requires a value" << std::endl; return 1; }
      opl_lvio_options.direction_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--opl-lvio-min-visual-points") {
      if (i + 1 >= argc) { std::cerr << "--opl-lvio-min-visual-points requires a value" << std::endl; return 1; }
      opl_lvio_options.min_visual_points = std::stoi(argv[++i]);
      continue;
    }
    if (applyVisualLidarAdapterProfileArg(arg, "v-loam15", &v_loam15_options) ||
        applyVisualLidarAdapterProfileArg(arg, "tc-vlo", &tc_vlo_options) ||
        applyVisualLidarAdapterProfileArg(arg, "ad-vlo", &ad_vlo_options) ||
        applyVisualLidarAdapterProfileArg(arg, "tc-mvlo", &tc_mvlo_options)) {
      continue;
    }
    // --- imls_slam ---
    if (arg == "--imls-slam-fast-profile") {
      imls_slam_options.source_voxel_size = 0.5;
      imls_slam_options.max_source_points = 4000;
      imls_slam_options.voxel_size = 1.0;
      imls_slam_options.imls_h = 0.5;
      imls_slam_options.max_iterations = 15;
      imls_slam_options.samples_per_axis = 100;
      imls_slam_options.local_map_radius = 45.0;
      imls_slam_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--imls-slam-dense-profile") {
      imls_slam_options.source_voxel_size = 0.35;
      imls_slam_options.max_source_points = 6000;
      imls_slam_options.voxel_size = 0.8;
      imls_slam_options.imls_h = 0.4;
      imls_slam_options.max_iterations = 20;
      imls_slam_options.samples_per_axis = 150;
      imls_slam_options.local_map_radius = 80.0;
      imls_slam_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--imls-slam-h") {
      if (i + 1 >= argc) { std::cerr << "--imls-slam-h requires a value" << std::endl; return 1; }
      imls_slam_options.imls_h = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-odometry") {
      imls_slam_options.paper_odometry = true;
      continue;
    }
    if (arg == "--imls-slam-paper-window" && i + 1 < argc) {
      imls_slam_options.paper_window_scans = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-samples" && i + 1 < argc) {
      imls_slam_options.paper_samples_per_list = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-iterations" && i + 1 < argc) {
      imls_slam_options.paper_iterations = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-h" && i + 1 < argc) {
      imls_slam_options.paper_h = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-r" && i + 1 < argc) {
      imls_slam_options.paper_r = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-normal-radius" && i + 1 < argc) {
      imls_slam_options.paper_scan_normal_radius = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-coarse-frames" && i + 1 < argc) {
      imls_slam_options.paper_coarse_frames = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-paper-coarse-radius" && i + 2 < argc) {
      imls_slam_options.paper_coarse_r = std::stod(argv[++i]);
      imls_slam_options.paper_coarse_h = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--imls-slam-no-sampling") {
      imls_slam_options.use_observability_sampling = false;
      continue;
    }
    // --- tricp_lo ---
    if (arg == "--tricp-lo-fast-profile") {
      tricp_lo_options.source_voxel_size = 0.5;
      tricp_lo_options.max_source_points = 4000;
      tricp_lo_options.voxel_size = 1.0;
      tricp_lo_options.max_iterations = 15;
      tricp_lo_options.local_map_radius = 45.0;
      tricp_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--tricp-lo-dense-profile") {
      tricp_lo_options.source_voxel_size = 0.35;
      tricp_lo_options.max_source_points = 6000;
      tricp_lo_options.voxel_size = 0.8;
      tricp_lo_options.max_iterations = 20;
      tricp_lo_options.local_map_radius = 80.0;
      tricp_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--tricp-lo-overlap") {
      if (i + 1 >= argc) { std::cerr << "--tricp-lo-overlap requires a value" << std::endl; return 1; }
      tricp_lo_options.overlap_ratio = std::stod(argv[++i]);
      tricp_lo_options.auto_overlap = false;
      continue;
    }
    if (arg == "--tricp-lo-fixed-overlap") {
      tricp_lo_options.auto_overlap = false;
      continue;
    }
    if (arg == "--tricp-lo-lambda") {
      if (i + 1 >= argc) { std::cerr << "--tricp-lo-lambda requires a value" << std::endl; return 1; }
      tricp_lo_options.frmsd_lambda = std::stod(argv[++i]);
      continue;
    }
    // --- kc_lo ---
    if (arg == "--kc-lo-fast-profile") {
      kc_lo_options.source_voxel_size = 0.5;
      kc_lo_options.max_source_points = 4000;
      kc_lo_options.voxel_size = 1.0;
      kc_lo_options.max_iterations = 15;
      kc_lo_options.local_map_radius = 45.0;
      kc_lo_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--kc-lo-dense-profile") {
      kc_lo_options.source_voxel_size = 0.35;
      kc_lo_options.max_source_points = 6000;
      kc_lo_options.voxel_size = 0.8;
      kc_lo_options.max_iterations = 20;
      kc_lo_options.kc_sigma = 0.4;
      kc_lo_options.kc_sigma_init = 1.5;
      kc_lo_options.local_map_radius = 80.0;
      kc_lo_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--kc-lo-sigma") {
      if (i + 1 >= argc) { std::cerr << "--kc-lo-sigma requires a value" << std::endl; return 1; }
      kc_lo_options.kc_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--kc-lo-sigma-init") {
      if (i + 1 >= argc) { std::cerr << "--kc-lo-sigma-init requires a value" << std::endl; return 1; }
      kc_lo_options.kc_sigma_init = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--kc-lo-no-anneal") {
      kc_lo_options.kc_sigma_init = kc_lo_options.kc_sigma;
      continue;
    }
    if (arg == "--degen-sense-fast-profile") {
      degen_sense_options.source_voxel_size = 0.5;
      degen_sense_options.max_source_points = 4000;
      degen_sense_options.voxel_size = 1.0;
      degen_sense_options.max_icp_iterations = 20;
      degen_sense_options.local_map_radius = 45.0;
      degen_sense_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--degen-sense-dense-profile") {
      degen_sense_options.source_voxel_size = 0.35;
      degen_sense_options.max_source_points = 6000;
      degen_sense_options.voxel_size = 0.8;
      degen_sense_options.max_icp_iterations = 40;
      degen_sense_options.local_map_radius = 80.0;
      degen_sense_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--degen-sense-mad-k") {
      if (i + 1 >= argc) { std::cerr << "--degen-sense-mad-k requires a value" << std::endl; return 1; }
      degen_sense_options.mad_k = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--vibration-lio-fast-profile") {
      vibration_lio_options.source_voxel_size = 0.5;
      vibration_lio_options.max_source_points = 4000;
      vibration_lio_options.voxel_size = 1.0;
      vibration_lio_options.max_icp_iterations = 20;
      vibration_lio_options.local_map_radius = 45.0;
      vibration_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--vibration-lio-dense-profile") {
      vibration_lio_options.source_voxel_size = 0.35;
      vibration_lio_options.max_source_points = 6000;
      vibration_lio_options.voxel_size = 0.8;
      vibration_lio_options.max_icp_iterations = 40;
      vibration_lio_options.local_map_radius = 80.0;
      vibration_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--vibration-lio-gamma") {
      if (i + 1 >= argc) { std::cerr << "--vibration-lio-gamma requires a value" << std::endl; return 1; }
      vibration_lio_options.gamma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--id-lio-fast-profile") {
      id_lio_options.source_voxel_size = 0.5;
      id_lio_options.max_source_points = 4000;
      id_lio_options.voxel_size = 1.0;
      id_lio_options.max_icp_iterations = 20;
      id_lio_options.range_image_width = 768;
      id_lio_options.range_image_height = 64;
      id_lio_options.local_map_radius = 45.0;
      id_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--id-lio-dense-profile") {
      id_lio_options.source_voxel_size = 0.35;
      id_lio_options.max_source_points = 7000;
      id_lio_options.voxel_size = 0.8;
      id_lio_options.max_icp_iterations = 40;
      id_lio_options.range_image_width = 1024;
      id_lio_options.range_image_height = 80;
      id_lio_options.local_map_radius = 80.0;
      id_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--id-lio-dynamic-weight") {
      if (i + 1 >= argc) { std::cerr << "--id-lio-dynamic-weight requires a value" << std::endl; return 1; }
      id_lio_options.dynamic_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--id-lio-delayed-removal-frames") {
      if (i + 1 >= argc) { std::cerr << "--id-lio-delayed-removal-frames requires a value" << std::endl; return 1; }
      id_lio_options.delayed_removal_frames = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--id-lio-new-object-margin") {
      if (i + 1 >= argc) { std::cerr << "--id-lio-new-object-margin requires a value" << std::endl; return 1; }
      id_lio_options.new_object_margin = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--id-lio-disappearance-margin") {
      if (i + 1 >= argc) { std::cerr << "--id-lio-disappearance-margin requires a value" << std::endl; return 1; }
      id_lio_options.disappearance_margin = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--rf-lio-fast-profile") {
      rf_lio_options.source_voxel_size = 0.5;
      rf_lio_options.max_source_points = 4000;
      rf_lio_options.voxel_size = 1.0;
      rf_lio_options.max_icp_iterations = 20;
      rf_lio_options.range_image_width = 768;
      rf_lio_options.range_image_height = 64;
      rf_lio_options.foreground_margin = 1.0;
      rf_lio_options.max_removal_fraction = 0.25;
      rf_lio_options.min_keep_points = 1400;
      rf_lio_options.local_map_radius = 45.0;
      rf_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--rf-lio-dense-profile") {
      rf_lio_options.source_voxel_size = 0.35;
      rf_lio_options.max_source_points = 7000;
      rf_lio_options.voxel_size = 0.8;
      rf_lio_options.max_icp_iterations = 40;
      rf_lio_options.range_image_width = 1024;
      rf_lio_options.range_image_height = 80;
      rf_lio_options.foreground_margin = 1.0;
      rf_lio_options.max_removal_fraction = 0.25;
      rf_lio_options.min_keep_points = 2200;
      rf_lio_options.local_map_radius = 80.0;
      rf_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--rf-lio-foreground-margin") {
      if (i + 1 >= argc) { std::cerr << "--rf-lio-foreground-margin requires a value" << std::endl; return 1; }
      rf_lio_options.foreground_margin = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--rf-lio-max-removal-fraction") {
      if (i + 1 >= argc) { std::cerr << "--rf-lio-max-removal-fraction requires a value" << std::endl; return 1; }
      rf_lio_options.max_removal_fraction = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--bievr-lio-fast-profile") {
      // bump-image は平面ベースなので密な入力が必要 (疎だと平面が形成されない)。
      bievr_lio_options.source_voxel_size = 0.3;
      bievr_lio_options.max_source_points = 8000;
      bievr_lio_options.voxel_size = 1.0;
      bievr_lio_options.pixel_res = 0.25;
      bievr_lio_options.max_icp_iterations = 20;
      bievr_lio_options.local_map_radius = 45.0;
      bievr_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--bievr-lio-dense-profile") {
      bievr_lio_options.source_voxel_size = 0.3;
      bievr_lio_options.max_source_points = 9000;
      bievr_lio_options.voxel_size = 0.8;
      bievr_lio_options.pixel_res = 0.2;
      bievr_lio_options.max_icp_iterations = 40;
      bievr_lio_options.local_map_radius = 80.0;
      bievr_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--ua-lio-fast-profile") {
      ua_lio_options.source_voxel_size = 0.5;
      ua_lio_options.max_source_points = 4000;
      ua_lio_options.voxel_size = 1.0;
      ua_lio_options.max_icp_iterations = 20;
      ua_lio_options.local_map_radius = 45.0;
      ua_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--ua-lio-dense-profile") {
      ua_lio_options.source_voxel_size = 0.35;
      ua_lio_options.max_source_points = 6000;
      ua_lio_options.voxel_size = 0.8;
      ua_lio_options.max_icp_iterations = 40;
      ua_lio_options.local_map_radius = 80.0;
      ua_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--ua-lio-no-ground") {
      ua_lio_options.ground_constraint = false;
      continue;
    }
    if (arg == "--cube-lio-fast-profile") {
      cube_lio_options.input_voxel_size = 0.5;
      cube_lio_options.max_input_points = 40000;
      cube_lio_options.voxel_size = 1.25;
      cube_lio_options.max_points_per_voxel = 10;
      cube_lio_options.max_icp_iterations = 20;
      cube_lio_options.cubemap_size = 192;
      cube_lio_options.local_map_radius = 45.0;
      cube_lio_options.map_cleanup_interval = 2;
      continue;
    }
    if (arg == "--cube-lio-dense-profile") {
      cube_lio_options.input_voxel_size = 0.3;
      cube_lio_options.max_input_points = 80000;
      cube_lio_options.voxel_size = 0.8;
      cube_lio_options.max_points_per_voxel = 16;
      cube_lio_options.max_icp_iterations = 40;
      cube_lio_options.cubemap_size = 320;
      cube_lio_options.local_map_radius = 80.0;
      cube_lio_options.map_cleanup_interval = 6;
      continue;
    }
    if (arg == "--cube-lio-semi-dense-quantile") {
      if (i + 1 >= argc) {
        std::cerr << "--cube-lio-semi-dense-quantile requires a value"
                  << std::endl;
        return 1;
      }
      cube_lio_options.semi_dense_quantile = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--cube-lio-intensity-sigma") {
      if (i + 1 >= argc) {
        std::cerr << "--cube-lio-intensity-sigma requires a value" << std::endl;
        return 1;
      }
      cube_lio_options.intensity_sigma = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--rko-lio-gyro-bias-gain") {
      if (i + 1 >= argc) {
        std::cerr << "--rko-lio-gyro-bias-gain requires a numeric value"
                  << std::endl;
        return 1;
      }
      rko_lio_options.gyro_bias_gain = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--rko-lio-gyro-bias-gain=", 0) == 0) {
      rko_lio_options.gyro_bias_gain =
          std::stod(arg.substr(std::string("--rko-lio-gyro-bias-gain=").size()));
      continue;
    }
    if (arg == "--fr-lio-fast-profile") {
      fr_lio_options.source_voxel_size = 0.5;
      fr_lio_options.max_source_points = 4500;
      fr_lio_options.voxel_size = 0.5;
      fr_lio_options.grid_size = 2.0;
      fr_lio_options.max_icp_iterations = 20;
      fr_lio_options.max_subframes = 3;
      fr_lio_options.min_valid_matches = 25;
      continue;
    }
    if (arg == "--fr-lio-dense-profile") {
      fr_lio_options.source_voxel_size = 0.3;
      fr_lio_options.max_source_points = 8000;
      fr_lio_options.voxel_size = 0.35;
      fr_lio_options.grid_size = 1.5;
      fr_lio_options.max_icp_iterations = 35;
      fr_lio_options.max_subframes = 4;
      fr_lio_options.min_valid_matches = 40;
      continue;
    }
    if (arg == "--pg-lio-fast-profile") {
      pg_lio_options.source_voxel_size = 0.5;
      pg_lio_options.max_source_points = 4500;
      pg_lio_options.voxel_size = 1.0;
      pg_lio_options.max_icp_iterations = 25;
      pg_lio_options.range_image_width = 512;
      pg_lio_options.range_image_height = 64;
      pg_lio_options.max_patches = 32;
      continue;
    }
    if (arg == "--pg-lio-dense-profile") {
      pg_lio_options.source_voxel_size = 0.3;
      pg_lio_options.max_source_points = 8000;
      pg_lio_options.voxel_size = 0.8;
      pg_lio_options.max_icp_iterations = 40;
      pg_lio_options.range_image_width = 768;
      pg_lio_options.range_image_height = 96;
      pg_lio_options.max_patches = 64;
      pg_lio_options.photometric_weight = 1.5;
      continue;
    }
    if (arg == "--kiss-source-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-source-voxel-size requires a numeric value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.source_voxel_size = std::stod(argv[++i]);
      kiss_multi_horizon_options.frontend.source_voxel_size =
          kiss_icp_options.source_voxel_size;
      continue;
    }
    if (arg.rfind("--kiss-source-voxel-size=", 0) == 0) {
      kiss_icp_options.source_voxel_size =
          std::stod(arg.substr(std::string("--kiss-source-voxel-size=").size()));
      kiss_multi_horizon_options.frontend.source_voxel_size =
          kiss_icp_options.source_voxel_size;
      continue;
    }
    if (arg == "--kiss-max-source-points") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-max-source-points requires an integer value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.max_source_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      kiss_multi_horizon_options.frontend.max_source_points =
          kiss_icp_options.max_source_points;
      continue;
    }
    if (arg.rfind("--kiss-max-source-points=", 0) == 0) {
      kiss_icp_options.max_source_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--kiss-max-source-points=").size()))));
      kiss_multi_horizon_options.frontend.max_source_points =
          kiss_icp_options.max_source_points;
      continue;
    }
    if (arg == "--kiss-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-voxel-size requires a numeric value" << std::endl;
        return 1;
      }
      kiss_icp_options.voxel_size = std::stod(argv[++i]);
      kiss_multi_horizon_options.frontend.voxel_size =
          kiss_icp_options.voxel_size;
      continue;
    }
    if (arg.rfind("--kiss-voxel-size=", 0) == 0) {
      kiss_icp_options.voxel_size =
          std::stod(arg.substr(std::string("--kiss-voxel-size=").size()));
      kiss_multi_horizon_options.frontend.voxel_size =
          kiss_icp_options.voxel_size;
      continue;
    }
    if (arg == "--kiss-initial-threshold") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-initial-threshold requires a numeric value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.initial_threshold = std::stod(argv[++i]);
      kiss_multi_horizon_options.frontend.initial_threshold =
          kiss_icp_options.initial_threshold;
      continue;
    }
    if (arg.rfind("--kiss-initial-threshold=", 0) == 0) {
      kiss_icp_options.initial_threshold = std::stod(
          arg.substr(std::string("--kiss-initial-threshold=").size()));
      kiss_multi_horizon_options.frontend.initial_threshold =
          kiss_icp_options.initial_threshold;
      continue;
    }
    if (arg == "--kiss-max-points-per-voxel") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-max-points-per-voxel requires an integer value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.max_points_per_voxel = std::max(1, std::stoi(argv[++i]));
      kiss_multi_horizon_options.frontend.max_points_per_voxel =
          kiss_icp_options.max_points_per_voxel;
      continue;
    }
    if (arg.rfind("--kiss-max-points-per-voxel=", 0) == 0) {
      kiss_icp_options.max_points_per_voxel = std::max(
          1, std::stoi(arg.substr(std::string("--kiss-max-points-per-voxel=").size())));
      kiss_multi_horizon_options.frontend.max_points_per_voxel =
          kiss_icp_options.max_points_per_voxel;
      continue;
    }
    if (arg == "--kiss-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.max_icp_iterations = std::max(1, std::stoi(argv[++i]));
      kiss_multi_horizon_options.frontend.max_icp_iterations =
          kiss_icp_options.max_icp_iterations;
      continue;
    }
    if (arg.rfind("--kiss-max-iterations=", 0) == 0) {
      kiss_icp_options.max_icp_iterations = std::max(
          1, std::stoi(arg.substr(std::string("--kiss-max-iterations=").size())));
      kiss_multi_horizon_options.frontend.max_icp_iterations =
          kiss_icp_options.max_icp_iterations;
      continue;
    }
    if (arg == "--kiss-local-map-radius") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-local-map-radius requires a numeric value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.local_map_radius = std::stod(argv[++i]);
      kiss_multi_horizon_options.frontend.local_map_radius =
          kiss_icp_options.local_map_radius;
      continue;
    }
    if (arg.rfind("--kiss-local-map-radius=", 0) == 0) {
      kiss_icp_options.local_map_radius = std::stod(
          arg.substr(std::string("--kiss-local-map-radius=").size()));
      kiss_multi_horizon_options.frontend.local_map_radius =
          kiss_icp_options.local_map_radius;
      continue;
    }
    if (arg == "--kiss-map-cleanup-interval") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-map-cleanup-interval requires an integer value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.map_cleanup_interval = std::max(0, std::stoi(argv[++i]));
      kiss_multi_horizon_options.frontend.map_cleanup_interval =
          kiss_icp_options.map_cleanup_interval;
      continue;
    }
    if (arg.rfind("--kiss-map-cleanup-interval=", 0) == 0) {
      kiss_icp_options.map_cleanup_interval = std::max(
          0, std::stoi(arg.substr(std::string("--kiss-map-cleanup-interval=").size())));
      kiss_multi_horizon_options.frontend.map_cleanup_interval =
          kiss_icp_options.map_cleanup_interval;
      continue;
    }
    if (arg == "--l-lo-set" && i + 1 < argc) {
      const std::string kv = argv[++i];
      if (!setLLOParam(l_lo_params, kv)) {
        std::cerr << "error: unknown --l-lo-set key in '" << kv << "'" << std::endl;
        return 1;
      }
      continue;
    }
    if (arg == "--lf-gicp-no-mitigation") {
      lf_gicp_options.enable_mitigation = false;
      continue;
    }
    if (arg == "--lf-gicp-field-beta" && i + 1 < argc) {
      lf_gicp_options.field_regularization = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--lf-gicp-beta" && i + 1 < argc) {
      lf_gicp_options.covariance_regularization = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--kiss-legacy-27-neighborhood") {
      // Upstream KISS-ICP / pre-2026-08-02 correspondence search; reproduces
      // KISS-ICP aggregates recorded before the v14 change.
      kiss_icp_options.neighbor_voxel_radius = 1;
      kiss_multi_horizon_options.frontend.neighbor_voxel_radius = 1;
      continue;
    }
    if (arg == "--kiss-update-full-voxels") {
      kiss_icp_options.update_full_voxels = true;
      kiss_multi_horizon_options.frontend.update_full_voxels = true;
      continue;
    }
    if (arg == "--kiss-deskew-mulran") {
      kiss_icp_options.deskew_mulran = true;
      kiss_multi_horizon_options.frontend.deskew_mulran = true;
      continue;
    }
    if (arg == "--kiss-motion-guard") {
      kiss_icp_options.enable_motion_guard = true;
      kiss_multi_horizon_options.frontend.enable_motion_guard = true;
      continue;
    }
    if (arg == "--kiss-adaptive-motion-guard") {
      kiss_icp_options.enable_adaptive_motion_guard = true;
      kiss_multi_horizon_options.frontend.enable_adaptive_motion_guard = true;
      continue;
    }
    if (arg == "--kiss-adaptive-guard-translation-consistency-m") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-adaptive-guard-translation-consistency-m requires a value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.adaptive_motion_guard_translation_consistency_m =
          std::max(0.0, std::stod(argv[++i]));
      kiss_multi_horizon_options.frontend
          .adaptive_motion_guard_translation_consistency_m =
          kiss_icp_options.adaptive_motion_guard_translation_consistency_m;
      continue;
    }
    if (arg == "--kiss-max-step-translation-m") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-max-step-translation-m requires a value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.max_step_translation_m =
          std::max(0.0, std::stod(argv[++i]));
      kiss_multi_horizon_options.frontend.max_step_translation_m =
          kiss_icp_options.max_step_translation_m;
      continue;
    }
    if (arg == "--kiss-max-step-rotation-deg") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-max-step-rotation-deg requires a value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.max_step_rotation_deg =
          std::max(0.0, std::stod(argv[++i]));
      kiss_multi_horizon_options.frontend.max_step_rotation_deg =
          kiss_icp_options.max_step_rotation_deg;
      continue;
    }
    if (arg == "--kiss-geman-mcclure-kernel") {
      kiss_icp_options.geman_mcclure_kernel = true;
      continue;
    }
    if (arg == "--kiss-map-min-point-distance") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-map-min-point-distance requires a value"
                  << std::endl;
        return 1;
      }
      kiss_icp_options.map_min_point_distance = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--kiss-model-deviation-threshold") {
      kiss_icp_options.use_model_deviation_threshold = true;
      kiss_multi_horizon_options.frontend.use_model_deviation_threshold =
          true;
      continue;
    }
    if (arg ==
        "--kiss-model-deviation-correspondence-multiplier") {
      if (i + 1 >= argc) {
        std::cerr
            << "--kiss-model-deviation-correspondence-multiplier requires a value"
            << std::endl;
        return 1;
      }
      const double multiplier = std::max(0.25, std::stod(argv[++i]));
      kiss_icp_options.model_deviation_correspondence_multiplier =
          multiplier;
      kiss_multi_horizon_options.frontend
          .model_deviation_correspondence_multiplier = multiplier;
      continue;
    }
    if (arg == "--kiss-vertical-angle-correction-deg") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-vertical-angle-correction-deg requires a value"
                  << std::endl;
        return 1;
      }
      const double correction_deg = std::stod(argv[++i]);
      kiss_icp_options.vertical_angle_correction_deg = correction_deg;
      kiss_multi_horizon_options.frontend.vertical_angle_correction_deg =
          correction_deg;
      continue;
    }
    if (arg.rfind("--kiss-vertical-angle-correction-deg=", 0) == 0) {
      const double correction_deg = std::stod(
          arg.substr(std::string("--kiss-vertical-angle-correction-deg=").size()));
      kiss_icp_options.vertical_angle_correction_deg = correction_deg;
      kiss_multi_horizon_options.frontend.vertical_angle_correction_deg =
          correction_deg;
      continue;
    }
    if (arg == "--kiss-mh-correction-gain") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-mh-correction-gain requires a value"
                  << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.correction_gain =
          std::clamp(std::stod(argv[++i]), 0.0, 1.0);
      continue;
    }
    if (arg == "--kiss-pg-scan-context-threshold") {
      if (i + 1 >= argc) {
        std::cerr
            << "--kiss-pg-scan-context-threshold requires a value"
            << std::endl;
        return 1;
      }
      kiss_pose_graph_scan_context_threshold =
          std::clamp(std::stod(argv[++i]), 0.0, 1.0);
      continue;
    }
    if (arg == "--kiss-pg-correction-gain") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-pg-correction-gain requires a value"
                  << std::endl;
        return 1;
      }
      kiss_pose_graph_correction_gain =
          std::clamp(std::stod(argv[++i]), 0.0, 1.0);
      continue;
    }
    if (arg == "--kiss-pg-external-poses") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-pg-external-poses requires a KITTI pose file"
                  << std::endl;
        return 1;
      }
      kiss_pose_graph_external_pose_path = argv[++i];
      continue;
    }
    if (arg.rfind("--kiss-pg-external-poses=", 0) == 0) {
      kiss_pose_graph_external_pose_path = arg.substr(
          std::string("--kiss-pg-external-poses=").size());
      continue;
    }
    if (arg == "--kiss-mh-keyframe-stride") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-mh-keyframe-stride requires an integer"
                  << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.keyframe_stride =
          std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--kiss-mh-horizons") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-mh-horizons requires comma-separated integers"
                  << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.horizons =
          parsePositiveIntList(argv[++i]);
      continue;
    }
    if (arg == "--kiss-mh-submap-frames") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-mh-submap-frames requires an integer"
                  << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.submap_frames =
          std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--kiss-mh-max-rmse") {
      if (i + 1 >= argc) {
        std::cerr << "--kiss-mh-max-rmse requires a value" << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.max_matcher_rmse =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg == "--kiss-mh-max-consensus-translation") {
      if (i + 1 >= argc) {
        std::cerr
            << "--kiss-mh-max-consensus-translation requires a value"
            << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.max_consensus_translation =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg == "--kiss-mh-max-consensus-rotation-rad") {
      if (i + 1 >= argc) {
        std::cerr
            << "--kiss-mh-max-consensus-rotation-rad requires a value"
            << std::endl;
        return 1;
      }
      kiss_multi_horizon_options.max_consensus_rotation_rad =
          std::max(0.0, std::stod(argv[++i]));
      continue;
    }
    if (arg == "--ct-icp-fast-profile") {
      ct_icp_options.source_voxel_size = 1.0;
      ct_icp_options.max_source_points = 350;
      ct_icp_options.voxel_resolution = 1.8;
      ct_icp_options.max_iterations = 6;
      ct_icp_options.ceres_max_iterations = 1;
      ct_icp_options.planarity_threshold = 0.10;
      ct_icp_options.keypoint_voxel_size = 1.5;
      ct_icp_options.max_frames_in_map = 6;
      ct_icp_options.multi_scale_correspondences = false;
      ct_icp_options.use_normal_cholesky_solver = false;
      continue;
    }
    if (arg == "--ct-icp-upstream-mechanics") {
      ct_icp_options.upstream_mechanics = true;
      continue;
    }
    if (arg == "--ct-icp-upstream-disable") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.upstream_disable = argv[++i];
      continue;
    }
    if (arg == "--ct-icp-dense-profile") {
      ct_icp_options.source_voxel_size = 0.6;
      ct_icp_options.max_source_points = 700;
      ct_icp_options.voxel_resolution = 1.2;
      ct_icp_options.max_iterations = 10;
      ct_icp_options.ceres_max_iterations = 6;
      ct_icp_options.planarity_threshold = 0.06;
      ct_icp_options.keypoint_voxel_size = 1.0;
      ct_icp_options.max_frames_in_map = 20;
      ct_icp_options.multi_scale_correspondences = true;
      ct_icp_options.use_normal_cholesky_solver = true;
      continue;
    }
    if (arg == "--ct-icp-source-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-source-voxel-size requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.source_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-source-voxel-size=", 0) == 0) {
      ct_icp_options.source_voxel_size = std::stod(
          arg.substr(std::string("--ct-icp-source-voxel-size=").size()));
      continue;
    }
    if (arg == "--ct-icp-max-source-points") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-max-source-points requires an integer value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.max_source_points =
          static_cast<size_t>(std::max(1, std::stoi(argv[++i])));
      continue;
    }
    if (arg.rfind("--ct-icp-max-source-points=", 0) == 0) {
      ct_icp_options.max_source_points = static_cast<size_t>(std::max(
          1, std::stoi(arg.substr(
                 std::string("--ct-icp-max-source-points=").size()))));
      continue;
    }
    if (arg == "--ct-icp-voxel-resolution") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-voxel-resolution requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.voxel_resolution = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-voxel-resolution=", 0) == 0) {
      ct_icp_options.voxel_resolution = std::stod(
          arg.substr(std::string("--ct-icp-voxel-resolution=").size()));
      continue;
    }
    if (arg == "--ct-icp-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ct-icp-max-iterations=", 0) == 0) {
      ct_icp_options.max_iterations = std::max(
          1, std::stoi(arg.substr(std::string("--ct-icp-max-iterations=").size())));
      continue;
    }
    if (arg == "--ct-icp-ceres-max-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-ceres-max-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.ceres_max_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ct-icp-ceres-max-iterations=", 0) == 0) {
      ct_icp_options.ceres_max_iterations = std::max(
          1, std::stoi(arg.substr(
                 std::string("--ct-icp-ceres-max-iterations=").size())));
      continue;
    }
    if (arg == "--ct-icp-max-correspondence-distance") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-max-correspondence-distance requires a numeric value (squared meters)"
                  << std::endl;
        return 1;
      }
      ct_icp_options.max_correspondence_dist = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-max-correspondence-distance=", 0) == 0) {
      ct_icp_options.max_correspondence_dist = std::stod(
          arg.substr(std::string("--ct-icp-max-correspondence-distance=").size()));
      continue;
    }
    if (arg == "--ct-icp-knn") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-knn requires an integer value" << std::endl;
        return 1;
      }
      ct_icp_options.knn = std::stoi(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-knn=", 0) == 0) {
      ct_icp_options.knn = std::stoi(
          arg.substr(std::string("--ct-icp-knn=").size()));
      continue;
    }
    if (arg == "--ct-icp-multi-scale") {
      ct_icp_options.multi_scale_correspondences = true;
      continue;
    }
    if (arg == "--ct-icp-normal-cholesky") {
      ct_icp_options.use_normal_cholesky_solver = true;
      continue;
    }
    if (arg == "--ct-icp-refinement-gate") {
      ct_icp_options.refinement_gate = true;
      continue;
    }
    if (arg == "--ct-icp-native-seed") {
      ct_icp_options.native_ct_icp_seed = true;
      continue;
    }
    if (arg == "--ct-icp-ndt-keyframe-interval") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_ndt_options.keyframe_interval = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ct-icp-ndt-keyframe-interval=", 0) == 0) {
      ct_icp_ndt_options.keyframe_interval = std::max(
          1, std::stoi(arg.substr(
                 std::string("--ct-icp-ndt-keyframe-interval=").size())));
      continue;
    }
    if (arg == "--ct-icp-ndt-max-correction-translation") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_ndt_options.max_correction_translation_delta = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-ndt-max-correction-translation=", 0) == 0) {
      ct_icp_ndt_options.max_correction_translation_delta = std::stod(
          arg.substr(std::string(
                         "--ct-icp-ndt-max-correction-translation=").size()));
      continue;
    }
    if (arg == "--ct-icp-ndt-max-correction-rotation-rad") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_ndt_options.max_correction_rotation_delta_rad = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-ndt-max-correction-rotation-rad=", 0) == 0) {
      ct_icp_ndt_options.max_correction_rotation_delta_rad = std::stod(
          arg.substr(std::string(
                         "--ct-icp-ndt-max-correction-rotation-rad=").size()));
      continue;
    }
    if (arg == "--ct-icp-ndt-max-score") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_ndt_options.max_ndt_score = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-ndt-max-score=", 0) == 0) {
      ct_icp_ndt_options.max_ndt_score =
          std::stod(arg.substr(std::string("--ct-icp-ndt-max-score=").size()));
      continue;
    }
    // Paper weight scheme bundle (Gap B+D+E+F):
    //   power_planarity=2, weight_alpha=0.9, weight_neighborhood=0.1,
    //   min_planarity_floor=0.01, planarity_threshold=0.01 (緩く),
    //   cauchy_loss_param=0.1, flat_regularizer_weight=true
    if (arg == "--ct-icp-paper-weights") {
      ct_icp_options.power_planarity = 2.0;
      ct_icp_options.weight_alpha = 0.9;
      ct_icp_options.weight_neighborhood = 0.1;
      ct_icp_options.min_planarity_floor = 0.01;
      ct_icp_options.planarity_threshold = 0.01;
      ct_icp_options.cauchy_loss_param = 0.1;
      ct_icp_options.flat_regularizer_weight = true;
      continue;
    }
    if (arg == "--ct-icp-power-planarity") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.power_planarity = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-weight-alpha") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.weight_alpha = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-weight-neighborhood") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.weight_neighborhood = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-min-planarity-floor") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.min_planarity_floor = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-flat-regularizer") {
      ct_icp_options.flat_regularizer_weight = true;
      continue;
    }
    if (arg == "--ct-icp-regularizer-n-cap") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.regularizer_n_cap = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-auto-regularizer-cap") {
      ct_icp_options.auto_regularizer_cap = true;
      continue;
    }
    if (arg == "--ct-icp-auto-regularizer-low-cap") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.auto_regularizer_low_cap =
          std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-icp-auto-regularizer-warmup-frames") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.auto_regularizer_warmup_frames =
          std::max(2, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-icp-auto-regularizer-max-step") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.auto_regularizer_max_step = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-auto-regularizer-min-rot-per-meter") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.auto_regularizer_min_rot_per_meter = std::stod(argv[++i]);
      continue;
    }
    // Pick 2 (Gap A+C): paper-aligned mapping & correspondence anchor.
    if (arg == "--ct-icp-paper-mapping") {
      // Bundle: closest-neighbor reference + PCA over 20 + min_distance 0.1.
      ct_icp_options.use_closest_neighbor_reference = true;
      ct_icp_options.pca_neighbor_count = 20;
      ct_icp_options.min_distance_between_points = 0.1;
      // paper の voxel insertion 前提では knn も増やす方が一貫
      if (ct_icp_options.knn <= 0) ct_icp_options.knn = 20;
      continue;
    }
    if (arg == "--ct-icp-closest-neighbor-reference") {
      ct_icp_options.use_closest_neighbor_reference = true;
      continue;
    }
    if (arg == "--ct-icp-pca-neighbor-count") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.pca_neighbor_count = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-min-distance-between-points") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.min_distance_between_points = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-coarse-to-fine") {
      ct_icp_options.coarse_to_fine = true;
      continue;
    }
    if (arg == "--ct-icp-coarse-iterations") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.coarse_iterations = std::max(0, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-icp-coarse-search-radius") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.coarse_search_radius = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg == "--ct-icp-coarse-planarity-threshold") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.coarse_planarity_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-coarse-cauchy-mult") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.coarse_cauchy_sigma_mult = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-cauchy-sigma") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.cauchy_loss_param = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-location-consistency-weight") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.location_consistency_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-orientation-consistency-weight") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.orientation_consistency_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-constant-velocity-weight") {
      if (i + 1 >= argc) { std::cerr << arg << " requires value\n"; return 1; }
      ct_icp_options.constant_velocity_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg == "--ct-icp-max-seed-translation-delta") {
      if (i + 1 >= argc) {
        std::cerr
            << "--ct-icp-max-seed-translation-delta requires a numeric value"
            << std::endl;
        return 1;
      }
      ct_icp_options.max_seed_translation_delta = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-max-seed-translation-delta=", 0) == 0) {
      ct_icp_options.max_seed_translation_delta = std::stod(arg.substr(
          std::string("--ct-icp-max-seed-translation-delta=").size()));
      continue;
    }
    if (arg == "--ct-icp-max-seed-rotation-delta-rad") {
      if (i + 1 >= argc) {
        std::cerr
            << "--ct-icp-max-seed-rotation-delta-rad requires a numeric value"
            << std::endl;
        return 1;
      }
      ct_icp_options.max_seed_rotation_delta_rad = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-max-seed-rotation-delta-rad=", 0) == 0) {
      ct_icp_options.max_seed_rotation_delta_rad = std::stod(arg.substr(
          std::string("--ct-icp-max-seed-rotation-delta-rad=").size()));
      continue;
    }
    if (arg == "--ct-icp-paper-arch") {
      // Bundle: multi-scale + normal-cholesky + refinement-gate (LiTAMIN2-style)
      ct_icp_options.multi_scale_correspondences = true;
      ct_icp_options.use_normal_cholesky_solver = true;
      ct_icp_options.refinement_gate = true;
      continue;
    }
    if (arg == "--ct-icp-planarity-threshold") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-planarity-threshold requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.planarity_threshold = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-planarity-threshold=", 0) == 0) {
      ct_icp_options.planarity_threshold = std::stod(
          arg.substr(std::string("--ct-icp-planarity-threshold=").size()));
      continue;
    }
    if (arg == "--ct-icp-keypoint-voxel-size") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-keypoint-voxel-size requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.keypoint_voxel_size = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-icp-keypoint-voxel-size=", 0) == 0) {
      ct_icp_options.keypoint_voxel_size = std::stod(
          arg.substr(std::string("--ct-icp-keypoint-voxel-size=").size()));
      continue;
    }
    if (arg == "--ct-icp-max-frames-in-map") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-icp-max-frames-in-map requires an integer value"
                  << std::endl;
        return 1;
      }
      ct_icp_options.max_frames_in_map = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ct-icp-max-frames-in-map=", 0) == 0) {
      ct_icp_options.max_frames_in_map = std::max(
          1, std::stoi(arg.substr(std::string("--ct-icp-max-frames-in-map=").size())));
      continue;
    }
    if (arg == "--xicp-fast-profile") {
      xicp_options.source_voxel_size = 1.4;
      xicp_options.max_source_points = 1800;
      xicp_options.max_iterations = 20;
      xicp_options.k_neighbors = 8;
      xicp_options.max_correspondence_distance = 2.2;
      xicp_options.map_max_points = 30000;
      xicp_options.refresh_interval = 6;
      xicp_options.map_radius = 35.0;
      xicp_options.max_seed_translation_delta = 1.5;
      xicp_options.max_seed_rotation_delta_rad = 0.20;
      continue;
    }
    if (arg == "--xicp-dense-profile") {
      xicp_options.source_voxel_size = 0.7;
      xicp_options.max_source_points = 3200;
      xicp_options.max_iterations = 40;
      xicp_options.k_neighbors = 12;
      xicp_options.max_correspondence_distance = 3.5;
      xicp_options.map_max_points = 50000;
      xicp_options.refresh_interval = 3;
      xicp_options.map_radius = 55.0;
      xicp_options.max_seed_translation_delta = 2.5;
      xicp_options.max_seed_rotation_delta_rad = 0.35;
      continue;
    }
    if (arg == "--fast-lio2-fast-profile") {
      fast_lio2_options.input_voxel_size = 0.7;
      fast_lio2_options.max_input_points = 3500;
      fast_lio2_options.max_iterations = 5;
      fast_lio2_options.ceres_max_iterations = 4;
      fast_lio2_options.voxel_resolution = 1.2;
      fast_lio2_options.keypoint_voxel_size = 0.7;
      fast_lio2_options.knn = 4;
      fast_lio2_options.max_correspondence_distance = 2.5;
      fast_lio2_options.planarity_threshold = 0.15;
      fast_lio2_options.max_frames_in_map = 20;
      continue;
    }
    if (arg == "--fast-lio2-dense-profile") {
      fast_lio2_options.input_voxel_size = 0.35;
      fast_lio2_options.max_input_points = 9000;
      fast_lio2_options.max_iterations = 10;
      fast_lio2_options.ceres_max_iterations = 8;
      fast_lio2_options.voxel_resolution = 0.8;
      fast_lio2_options.keypoint_voxel_size = 0.35;
      fast_lio2_options.knn = 6;
      fast_lio2_options.max_correspondence_distance = 3.5;
      fast_lio2_options.planarity_threshold = 0.08;
      fast_lio2_options.max_frames_in_map = 40;
      continue;
    }
    if (arg == "--hdl-graph-slam-fast-profile") {
      hdl_graph_slam_options.input_voxel_size = 0.7;
      hdl_graph_slam_options.max_input_points = 4000;
      hdl_graph_slam_options.registration_voxel_size = 0.9;
      hdl_graph_slam_options.map_voxel_size = 1.4;
      hdl_graph_slam_options.keyframe_stride = 2;
      hdl_graph_slam_options.max_keyframes_in_submap = 20;
      hdl_graph_slam_options.loop_stride = 5;
      hdl_graph_slam_options.enable_loop_closure = false;
      hdl_graph_slam_options.enable_floor_constraint = false;
      continue;
    }
    if (arg == "--hdl-graph-slam-dense-profile") {
      hdl_graph_slam_options.input_voxel_size = 0.35;
      hdl_graph_slam_options.max_input_points = 9000;
      hdl_graph_slam_options.registration_voxel_size = 0.5;
      hdl_graph_slam_options.map_voxel_size = 0.7;
      hdl_graph_slam_options.keyframe_stride = 1;
      hdl_graph_slam_options.max_keyframes_in_submap = 40;
      hdl_graph_slam_options.loop_stride = 2;
      hdl_graph_slam_options.enable_loop_closure = true;
      hdl_graph_slam_options.enable_floor_constraint = true;
      continue;
    }
    if (arg == "--vgicp-slam-fast-profile") {
      vgicp_slam_options.input_voxel_size = 0.7;
      vgicp_slam_options.max_input_points = 4000;
      vgicp_slam_options.registration_voxel_size = 0.55;
      vgicp_slam_options.map_voxel_size = 0.85;
      vgicp_slam_options.keyframe_stride = 2;
      vgicp_slam_options.max_keyframes_in_submap = 20;
      vgicp_slam_options.loop_stride = 5;
      vgicp_slam_options.enable_loop_closure = false;
      continue;
    }
    if (arg == "--vgicp-slam-dense-profile") {
      vgicp_slam_options.input_voxel_size = 0.35;
      vgicp_slam_options.max_input_points = 9000;
      vgicp_slam_options.registration_voxel_size = 0.3;
      vgicp_slam_options.map_voxel_size = 0.45;
      vgicp_slam_options.keyframe_stride = 1;
      vgicp_slam_options.max_keyframes_in_submap = 40;
      vgicp_slam_options.loop_stride = 2;
      vgicp_slam_options.enable_loop_closure = true;
      continue;
    }
    if (arg == "--suma-fast-profile") {
      suma_options.input_voxel_size = 0.7;
      suma_options.max_input_points = 4000;
      suma_options.surfel_resolution = 0.6;
      suma_options.surfel_stride = 2;
      suma_options.max_iterations = 3;
      suma_options.max_frames_in_map = 12;
      continue;
    }
    if (arg == "--suma-paper") {
      suma_options.paper = true;
      continue;
    }
    if (arg == "--suma-paper-set") {
      if (i + 1 >= argc) { std::cerr << "--suma-paper-set requires key=value" << std::endl; return 1; }
      const std::string kv = argv[++i];
      const auto eq = kv.find('=');
      if (eq == std::string::npos) { std::cerr << "--suma-paper-set requires key=value" << std::endl; return 1; }
      suma_options.paper_overrides.emplace_back(kv.substr(0, eq), std::stod(kv.substr(eq + 1)));
      continue;
    }
    if (arg == "--suma-n-scans") {
      if (i + 1 >= argc) { std::cerr << "--suma-n-scans requires a value" << std::endl; return 1; }
      suma_options.n_scans = std::stoi(argv[++i]);
      continue;
    }
    if (arg == "--suma-dense-profile") {
      suma_options.input_voxel_size = 0.35;
      suma_options.max_input_points = 9000;
      suma_options.surfel_resolution = 0.3;
      suma_options.surfel_stride = 1;
      suma_options.max_iterations = 6;
      suma_options.max_frames_in_map = 30;
      continue;
    }
    if (arg == "--balm2-fast-profile") {
      balm2_options.input_voxel_size = 0.7;
      balm2_options.max_input_points = 4000;
      balm2_options.corner_resolution = 0.4;
      balm2_options.surface_resolution = 0.8;
      balm2_options.corner_stride = 3;
      balm2_options.surface_stride = 4;
      balm2_options.window_size = 4;
      balm2_options.num_outer_iterations = 1;
      balm2_options.ceres_max_iterations = 4;
      continue;
    }
    if (arg == "--balm2-dense-profile") {
      balm2_options.input_voxel_size = 0.45;
      balm2_options.max_input_points = 7000;
      balm2_options.corner_resolution = 0.25;
      balm2_options.surface_resolution = 0.5;
      balm2_options.corner_stride = 1;
      balm2_options.surface_stride = 2;
      balm2_options.window_size = 6;
      balm2_options.num_outer_iterations = 2;
      balm2_options.ceres_max_iterations = 6;
      continue;
    }
    if (arg == "--isc-loam-fast-profile") {
      isc_loam_options.input_voxel_size = 0.7;
      isc_loam_options.max_input_points = 4000;
      isc_loam_options.keyframe_stride = 2;
      isc_loam_options.loop_stride = 5;
      isc_loam_options.enable_loop_closure = false;
      continue;
    }
    if (arg == "--isc-loam-dense-profile") {
      isc_loam_options.input_voxel_size = 0.35;
      isc_loam_options.max_input_points = 9000;
      isc_loam_options.keyframe_stride = 1;
      isc_loam_options.loop_stride = 2;
      isc_loam_options.enable_loop_closure = true;
      continue;
    }
    if (arg == "--loam-livox-fast-profile") {
      loam_livox_options.input_voxel_size = 0.7;
      loam_livox_options.max_input_points = 4000;
      loam_livox_options.less_flat_leaf_size = 0.35f;
      loam_livox_options.odom_outer_iters = 1;
      loam_livox_options.map_outer_iters = 1;
      loam_livox_options.map_line_resolution = 0.6;
      loam_livox_options.map_plane_resolution = 1.2;
      continue;
    }
    if (arg == "--loam-livox-dense-profile") {
      loam_livox_options.input_voxel_size = 0.35;
      loam_livox_options.max_input_points = 9000;
      loam_livox_options.less_flat_leaf_size = 0.15f;
      loam_livox_options.odom_outer_iters = 2;
      loam_livox_options.map_outer_iters = 2;
      loam_livox_options.map_line_resolution = 0.3;
      loam_livox_options.map_plane_resolution = 0.6;
      continue;
    }
    if (arg == "--lio-sam-fast-profile") {
      lio_sam_options.input_voxel_size = 0.7;
      lio_sam_options.max_input_points = 4000;
      lio_sam_options.keyframe_stride = 2;
      lio_sam_options.enable_loop_closure = false;
      lio_sam_options.enable_imu_rotation_prior = true;
      continue;
    }
    if (arg == "--lio-sam-dense-profile") {
      lio_sam_options.input_voxel_size = 0.45;
      lio_sam_options.max_input_points = 7000;
      lio_sam_options.keyframe_stride = 1;
      lio_sam_options.enable_loop_closure = true;
      lio_sam_options.enable_imu_rotation_prior = true;
      continue;
    }
    if (arg == "--lins-fast-profile") {
      lins_options.input_voxel_size = 0.7;
      lins_options.max_input_points = 4000;
      lins_options.registration_voxel_size = 0.7;
      lins_options.map_voxel_size = 1.0;
      lins_options.max_correspondences = 140;
      lins_options.max_keyframes_in_map = 20;
      continue;
    }
    if (arg == "--lins-dense-profile") {
      lins_options.input_voxel_size = 0.35;
      lins_options.max_input_points = 9000;
      lins_options.registration_voxel_size = 0.35;
      lins_options.map_voxel_size = 0.55;
      lins_options.max_correspondences = 280;
      lins_options.max_keyframes_in_map = 40;
      continue;
    }
    if (arg == "--fast-lio-slam-fast-profile") {
      fast_lio_slam_options.input_voxel_size = 0.7;
      fast_lio_slam_options.max_input_points = 3500;
      fast_lio_slam_options.max_iterations = 5;
      fast_lio_slam_options.ceres_max_iterations = 4;
      fast_lio_slam_options.voxel_resolution = 1.2;
      fast_lio_slam_options.keypoint_voxel_size = 0.7;
      fast_lio_slam_options.max_frames_in_map = 20;
      fast_lio_slam_options.keyframe_stride = 2;
      fast_lio_slam_options.loop_stride = 5;
      fast_lio_slam_options.enable_loop_closure = false;
      continue;
    }
    if (arg == "--fast-lio-slam-dense-profile") {
      fast_lio_slam_options.input_voxel_size = 0.35;
      fast_lio_slam_options.max_input_points = 9000;
      fast_lio_slam_options.max_iterations = 10;
      fast_lio_slam_options.ceres_max_iterations = 8;
      fast_lio_slam_options.voxel_resolution = 0.8;
      fast_lio_slam_options.keypoint_voxel_size = 0.35;
      fast_lio_slam_options.max_frames_in_map = 40;
      fast_lio_slam_options.keyframe_stride = 1;
      fast_lio_slam_options.loop_stride = 2;
      fast_lio_slam_options.enable_loop_closure = true;
      continue;
    }
    if (arg == "--point-lio-fast-profile") {
      point_lio_options.input_voxel_size = 0.7;
      point_lio_options.max_input_points = 4000;
      point_lio_options.registration_voxel_size = 0.6;
      point_lio_options.map_voxel_size = 0.9;
      point_lio_options.max_correspondences = 160;
      point_lio_options.max_keyframes_in_map = 20;
      continue;
    }
    if (arg == "--point-lio-dense-profile") {
      point_lio_options.input_voxel_size = 0.35;
      point_lio_options.max_input_points = 9000;
      point_lio_options.registration_voxel_size = 0.3;
      point_lio_options.map_voxel_size = 0.5;
      point_lio_options.max_correspondences = 320;
      point_lio_options.max_keyframes_in_map = 40;
      continue;
    }
    if (arg == "--clins-fast-profile") {
      clins_options.source_voxel_size = 1.0;
      clins_options.max_source_points = 300;
      continue;
    }
    if (arg == "--clins-dense-profile") {
      clins_options.source_voxel_size = 0.45;
      clins_options.max_source_points = 900;
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-window") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-lio-fixed-lag-window requires an integer value"
                  << std::endl;
        return 1;
      }
      ct_lio_fixed_lag_window = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ct-lio-fixed-lag-window=", 0) == 0) {
      ct_lio_fixed_lag_window = std::max(
          1, std::stoi(arg.substr(std::string("--ct-lio-fixed-lag-window=").size())));
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-velocity-weight") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-lio-fixed-lag-velocity-weight requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_lio_fixed_lag_velocity_weight = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-lio-fixed-lag-velocity-weight=", 0) == 0) {
      ct_lio_fixed_lag_velocity_weight = std::stod(
          arg.substr(std::string("--ct-lio-fixed-lag-velocity-weight=").size()));
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-gyro-bias-scale") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-lio-fixed-lag-gyro-bias-scale requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_lio_fixed_lag_gyro_bias_scale = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-lio-fixed-lag-gyro-bias-scale=", 0) == 0) {
      ct_lio_fixed_lag_gyro_bias_scale = std::stod(
          arg.substr(std::string("--ct-lio-fixed-lag-gyro-bias-scale=").size()));
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-accel-bias-scale") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-lio-fixed-lag-accel-bias-scale requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_lio_fixed_lag_accel_bias_scale = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-lio-fixed-lag-accel-bias-scale=", 0) == 0) {
      ct_lio_fixed_lag_accel_bias_scale = std::stod(
          arg.substr(std::string("--ct-lio-fixed-lag-accel-bias-scale=").size()));
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-history-decay") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-lio-fixed-lag-history-decay requires a numeric value"
                  << std::endl;
        return 1;
      }
      ct_lio_fixed_lag_history_decay = std::stod(argv[++i]);
      continue;
    }
    if (arg.rfind("--ct-lio-fixed-lag-history-decay=", 0) == 0) {
      ct_lio_fixed_lag_history_decay =
          std::stod(arg.substr(std::string("--ct-lio-fixed-lag-history-decay=").size()));
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-outer-iterations") {
      if (i + 1 >= argc) {
        std::cerr << "--ct-lio-fixed-lag-outer-iterations requires an integer value"
                  << std::endl;
        return 1;
      }
      ct_lio_fixed_lag_outer_iterations = std::max(1, std::stoi(argv[++i]));
      continue;
    }
    if (arg.rfind("--ct-lio-fixed-lag-outer-iterations=", 0) == 0) {
      ct_lio_fixed_lag_outer_iterations = std::max(
          1, std::stoi(arg.substr(
                 std::string("--ct-lio-fixed-lag-outer-iterations=").size())));
      continue;
    }
    if (arg == "--ct-lio-fixed-lag-smoother") {
      ct_lio_fixed_lag_smoother = true;
      continue;
    }
    if (arg == "--methods") {
      if (i + 1 >= argc) {
        std::cerr << "--methods requires a comma-separated value" << std::endl;
        return 1;
      }
      selected_methods = splitMethodList(argv[++i]);
      continue;
    }
    if (arg.rfind("--methods=", 0) == 0) {
      selected_methods = splitMethodList(arg.substr(std::string("--methods=").size()));
      continue;
    }
    if (!arg.empty() && arg[0] == '-') {
      std::cerr << "Unknown option: " << arg << std::endl;
      return 1;
    }
    max_frames = std::stoi(arg);
  }

  if (selected_methods.empty()) {
    std::cerr
        << "No methods selected. Supported methods: litamin2, gicp, small_gicp, "
        << "voxel_gicp, ndt, kiss_icp, kiss_multi_horizon, kiss_pose_graph, kiss_pose_graph_causal, dlo, dlio, aloam, floam, lego_loam, mulls, "
        << "ct_lio, ct_icp, ct_icp_ndt, ct_icp_ndt_keyframe, fixed_map_ndt, xicp, fast_lio2, hdl_graph_slam, vgicp_slam, "
        << "suma, balm2, isc_loam, loam_livox, lio_sam, lins, fast_lio_slam, "
        << "point_lio, clins"
        << std::endl;
    return 1;
  }
  for (const auto& method : selected_methods) {
    if (!isSupportedMethod(method)) {
      std::cerr << "Unsupported method: " << method
                << " (supported: litamin2, gicp, small_gicp, voxel_gicp, ndt, "
                   "kiss_icp, kiss_multi_horizon, kiss_pose_graph, kiss_pose_graph_causal, dlo, dlio, aloam, floam, lego_loam, mulls, ct_lio, "
                   "ct_icp, ct_icp_ndt, ct_icp_ndt_keyframe, fixed_map_ndt, xicp, fast_lio2, hdl_graph_slam, vgicp_slam, "
                   "suma, balm2, isc_loam, loam_livox, lio_sam, lins, "
                   "fast_lio_slam, point_lio, clins)"
                << std::endl;
      return 1;
    }
  }
  if (!inten_loam_options.paper_trace_jsonl.empty()) {
    const fs::path trace_path(inten_loam_options.paper_trace_jsonl);
    if (!inten_loam_options.paper_odometry || selected_methods.size() != 1 ||
        selected_methods.front() != "inten_loam") {
      std::cerr << "InTEn trace requires --methods inten_loam --inten-loam-paper-odometry" << std::endl;
      return 1;
    }
    if (trace_path.extension() != ".jsonl" ||
        (!summary_json_path.empty() && fs::weakly_canonical(trace_path) ==
                                      fs::weakly_canonical(fs::path(summary_json_path)))) {
      std::cerr << "InTEn trace needs a .jsonl path distinct from --summary-json" << std::endl;
      return 1;
    }
    inten_loam_options.trace_argv.assign(argv, argv + argc);
  }
  litamin2_options.seed_perturbation = seed_perturbation;
  gicp_options.seed_perturbation = seed_perturbation;
  small_gicp_options.seed_perturbation = seed_perturbation;
  voxel_gicp_options.seed_perturbation = seed_perturbation;
  ndt_options.seed_perturbation = seed_perturbation;

  auto pcd_dirs = listPCDDirs(pcd_dir);
  size_t total_pcd_frames = pcd_dirs.size();
  if (max_frames > 0 && max_frames < (int)pcd_dirs.size())
    pcd_dirs.resize(max_frames);

  TimeDomain gt_time_domain = TimeDomain::kUnknown;
  std::string gt_format = "unknown";
  std::vector<GTPose> gt_poses_raw;
  try {
    gt_poses_raw = loadGTPoses(gt_csv, &gt_time_domain, &gt_format);
  } catch (const std::exception& e) {
    std::cerr << "Failed to load GT poses: " << e.what() << std::endl;
    return 1;
  }
  if (gt_poses_raw.empty()) {
    std::cerr << "No GT poses loaded from " << gt_csv << std::endl;
    return 1;
  }
  std::string gt_sha256;
  try {
    gt_sha256 = sha256File(gt_csv);
  } catch (const std::exception& e) {
    std::cerr << "Failed to hash GT file: " << e.what() << std::endl;
    return 1;
  }
  if (isGlobalDogfoodingGtArtifact(gt_csv) && !allow_legacy_gt_artifact) {
    std::cerr
        << "Refusing dogfooding_results/gt.txt as canonical GT: this is a "
        << "mutable last-run artifact. Use dataset-specific reference GT, or "
        << "explicitly pass --allow-legacy-gt-artifact after verifying "
        << "provenance." << std::endl;
    return 1;
  }
  if (isGlobalDogfoodingGtArtifact(gt_csv) && allow_legacy_gt_artifact) {
    std::cerr
        << "Warning: using mutable dogfooding_results/gt.txt because "
        << "--allow-legacy-gt-artifact was set." << std::endl;
  }
  auto frame_timestamps = loadFrameTimestampsFromCsv(pcd_dir, pcd_dirs.size());
  FrameTimestampSource frame_timestamp_source =
      FrameTimestampSource::kFrameTimestampCsv;
  if (frame_timestamps.empty()) {
    frame_timestamps = loadFrameTimestampsFromGraph(pcd_dirs);
    frame_timestamp_source = FrameTimestampSource::kGraphTrajectory;
  }
  auto frame_gap_stats = computeFrameGapStats(frame_timestamps);
  GTAssociation gt_association;
  try {
    if (frame_timestamps.empty() && legacy_auto_association) {
      frame_timestamps =
          sampleFrameTimestamps(gt_poses_raw, pcd_dirs.size(), total_pcd_frames);
      frame_timestamp_source = FrameTimestampSource::kSampledGT;
      frame_gap_stats = computeFrameGapStats(frame_timestamps);
      gt_association = associateByLegacySampling(
          gt_poses_raw, pcd_dirs.size(), total_pcd_frames);
    } else if (legacy_auto_association) {
      try {
        gt_association =
            associateGTPoseMatrices(gt_poses_raw, frame_timestamps,
                                    association_max_dt);
      } catch (const std::exception& strict_error) {
        std::cerr << "Warning: strict GT association failed under "
                  << "--association-mode legacy-auto: " << strict_error.what()
                  << "; falling back to sampled GT timestamps." << std::endl;
        frame_timestamps = sampleFrameTimestamps(gt_poses_raw, pcd_dirs.size(),
                                                 total_pcd_frames);
        frame_timestamp_source = FrameTimestampSource::kSampledGT;
        frame_gap_stats = computeFrameGapStats(frame_timestamps);
        gt_association = associateByLegacySampling(
            gt_poses_raw, pcd_dirs.size(), total_pcd_frames);
      }
    } else {
      gt_association =
          associateGTPoseMatrices(gt_poses_raw, frame_timestamps,
                                  association_max_dt);
    }
  } catch (const std::exception& e) {
    std::cerr << "Failed to associate GT poses: " << e.what() << std::endl;
    return 1;
  }
  auto gt = gt_association.poses;
  if (gt.size() != pcd_dirs.size()) {
    std::cerr << "Associated GT pose count (" << gt.size()
              << ") does not match PCD frame count (" << pcd_dirs.size()
              << ")" << std::endl;
    return 1;
  }

  std::cout << "========================================" << std::endl;
  std::cout << "  PCD Dogfooding" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << "PCD frames: " << pcd_dirs.size() << std::endl;
  std::cout << "GT poses: " << gt.size() << std::endl;

  fs::path imu_csv_path = fs::path(pcd_dir) / "imu.csv";
  if (!fs::exists(imu_csv_path)) {
    imu_csv_path = fs::path(pcd_dir).parent_path() / "imu.csv";
  }
  std::vector<ImuSampleCsv> imu_samples;
  if (fs::exists(imu_csv_path)) {
    imu_samples = loadImuCsv(imu_csv_path.string());
    std::cout << "IMU samples: " << imu_samples.size() << std::endl;
  } else {
    std::cout << "IMU samples: 0 (imu.csv not found)" << std::endl;
  }

  std::cout << "Timestamp source: " << frameTimestampSourceName(frame_timestamp_source)
            << std::endl;
  std::cout << "GT format: " << gt_format
            << " (time_domain=" << timeDomainName(gt_time_domain) << ")"
            << std::endl;
  std::cout << "GT association: " << gt_association.mode << std::endl;
  if (frame_gap_stats.valid) {
    std::cout << "Frame gap [s]: min=" << std::fixed << std::setprecision(3)
              << frame_gap_stats.min_gap
              << " median=" << frame_gap_stats.median_gap
              << " mean=" << frame_gap_stats.mean_gap
              << " max=" << frame_gap_stats.max_gap << std::endl;
  } else {
    std::cout << "Frame gap [s]: unavailable" << std::endl;
  }

  // 走行距離
  double dist = 0;
  for (size_t i = 1; i < gt.size(); i++)
    dist += (gt[i].block<3, 1>(0, 3) - gt[i-1].block<3, 1>(0, 3)).norm();
  std::cout << "Trajectory length: " << std::fixed << std::setprecision(1) << dist << " m" << std::endl;

  std::vector<MethodResult> results;

  if (no_gt_seed) {
    std::cout << "[no-gt-seed] Scan-to-map methods will use velocity-model prediction instead of GT initialization." << std::endl;
  }
  if (ct_icp_gt_seed) {
    std::cout << "[ct-icp-gt-seed] CT-ICP TrajectoryFrame init will be seeded from GT begin/end poses." << std::endl;
  }
  if (seed_perturbation.enabled()) {
    std::cout << "[seed-perturb] local-frame dx=" << std::fixed
              << std::setprecision(3) << seed_perturbation.x
              << "m dy=" << seed_perturbation.y
              << "m dz=" << seed_perturbation.z
              << "m yaw="
              << seed_perturbation.yaw_rad * 180.0 / M_PI
              << "deg" << std::endl;
  }

  if (isMethodEnabled(selected_methods, "litamin2")) {
    std::cout << "\nRunning LiTAMIN2..." << std::endl;
    std::cout << "  voxel_resolution=" << litamin2_options.voxel_resolution
              << " max_iterations=" << litamin2_options.max_iterations
              << " max_source_points=" << litamin2_options.max_source_points
              << " refresh_interval=" << litamin2_options.refresh_interval
              << " map_max_points=" << litamin2_options.map_max_points
              << " map_radius=" << litamin2_options.map_radius
              << " local_map_policy="
              << litamin2LocalMapPolicyName(litamin2_options.local_map_policy)
              << " keyframe_translation="
              << litamin2_options.keyframe_translation
              << " keyframe_rotation="
              << litamin2_options.keyframe_rotation_rad
              << " max_seed_translation_delta="
              << litamin2_options.max_seed_translation_delta
              << " max_seed_rotation_delta="
              << litamin2_options.max_seed_rotation_delta_rad
              << " max_motion_translation_delta="
              << litamin2_options.max_motion_translation_delta
              << " max_motion_rotation_delta="
              << litamin2_options.max_motion_rotation_delta_rad
              << " min_cov_eigenvalue="
              << litamin2_options.min_cov_eigenvalue
              << " correspondence_search_radius="
              << litamin2_options.correspondence_search_radius
              << " max_correspondence_distance="
              << litamin2_options.max_correspondence_distance
              << " use_cov_cost=" << (litamin2_options.use_cov_cost ? "on" : "off")
              << " covariance_gradient="
              << (litamin2_options.optimize_covariance_cost ? "on" : "off")
              << " covariance_gradient_weight="
              << litamin2_options.covariance_gradient_weight
              << " line_search="
              << (litamin2_options.enable_line_search ? "on" : "off")
              << " line_search_min_step="
              << litamin2_options.line_search_min_step
              << " scan_to_scan="
              << (litamin2_options.scan_to_scan ? "on" : "off")
              << " coarse_to_fine_levels="
              << litamin2_options.coarse_to_fine_voxel_resolutions.size()
              << " coarse_to_fine_iteration_levels="
              << litamin2_options.coarse_to_fine_iterations.size()
              << " num_threads=" << litamin2_options.num_threads << std::endl;
    results.push_back(runLiTAMIN2(pcd_dirs, gt, litamin2_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "gicp")) {
    std::cout << "Running GICP..." << std::endl;
    std::cout << "  source_voxel_size=" << gicp_options.source_voxel_size
              << " max_source_points=" << gicp_options.max_source_points
              << " k_neighbors=" << gicp_options.k_neighbors
              << " max_iterations=" << gicp_options.max_iterations
              << " map_max_points=" << gicp_options.map_max_points << std::endl;
    results.push_back(runGICP(pcd_dirs, gt, gicp_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "small_gicp")) {
    std::cout << "Running Small-GICP..." << std::endl;
    std::cout << "  source_voxel_size=" << small_gicp_options.source_voxel_size
              << " max_source_points=" << small_gicp_options.max_source_points
              << " voxel_resolution=" << small_gicp_options.voxel_resolution
              << " k_neighbors=" << small_gicp_options.k_neighbors
              << " max_iterations=" << small_gicp_options.max_iterations
              << " max_correspondences=" << small_gicp_options.max_correspondences
              << " map_max_points=" << small_gicp_options.map_max_points
              << std::endl;
    results.push_back(
        runSmallGICP(pcd_dirs, gt, small_gicp_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "voxel_gicp")) {
    std::cout << "Running Voxel-GICP..." << std::endl;
    std::cout << "  source_voxel_size=" << voxel_gicp_options.source_voxel_size
              << " max_source_points=" << voxel_gicp_options.max_source_points
              << " voxel_resolution=" << voxel_gicp_options.voxel_resolution
              << " min_points_per_voxel="
              << voxel_gicp_options.min_points_per_voxel
              << " max_iterations=" << voxel_gicp_options.max_iterations
              << " map_max_points=" << voxel_gicp_options.map_max_points
              << std::endl;
    results.push_back(
        runVoxelGICP(pcd_dirs, gt, voxel_gicp_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "aloam")) {
    std::cout << "Running A-LOAM..." << std::endl;
    std::cout << "  n_scans=" << aloam_options.n_scans
              << " scan_period=" << aloam_options.scan_period
              << " curvature_threshold=" << aloam_options.curvature_threshold
              << " less_flat_leaf_size=" << aloam_options.less_flat_leaf_size
              << " odom_iters=" << aloam_options.odom_outer_iters
              << " map_iters=" << aloam_options.map_outer_iters
              << std::endl;
    results.push_back(runALOAM(pcd_dirs, gt, aloam_options));
  }

  if (isMethodEnabled(selected_methods, "floam")) {
    std::cout << "Running F-LOAM..." << std::endl;
    std::cout << "  n_scans=" << floam_options.n_scans
              << " stride=" << floam_options.input_point_stride
              << " map_interval=" << floam_options.mapping_update_interval
              << " curvature_threshold=" << floam_options.curvature_threshold
              << " odom_iters=" << floam_options.odom_outer_iters
              << " map_iters=" << floam_options.map_outer_iters
              << std::endl;
    results.push_back(runFLOAM(pcd_dirs, gt, floam_options));
  }

  if (isMethodEnabled(selected_methods, "lego_loam")) {
    std::cout << "Running LeGO-LOAM..." << std::endl;
    std::cout << "  n_scans=" << lego_loam_options.n_scans
              << " sensor_height=" << lego_loam_options.sensor_height
              << " ground_scan_limit=" << lego_loam_options.ground_scan_limit
              << " curvature_threshold=" << lego_loam_options.curvature_threshold
              << " odom_iters=" << lego_loam_options.odom_outer_iters
              << " map_iters=" << lego_loam_options.map_outer_iters
              << std::endl;
    results.push_back(runLeGOLOAM(pcd_dirs, gt, lego_loam_options));
  }

  if (isMethodEnabled(selected_methods, "mulls")) {
    std::cout << "Running MULLS..." << std::endl;
    std::cout << "  n_scans=" << mulls_options.n_scans
              << " mulls_map_iters=" << mulls_options.mulls_map_iters
              << " mulls_ceres_iters=" << mulls_options.mulls_ceres_iters
              << " max_frames_in_map=" << mulls_options.mulls_max_frames_in_map
              << " point_w=" << mulls_options.mulls_point_weight << std::endl;
    results.push_back(runMULLS(pcd_dirs, gt, mulls_options));
  }

  if (isMethodEnabled(selected_methods, "ndt")) {
    std::cout << "Running NDT..." << std::endl;
    std::cout << "  source_voxel_size=" << ndt_options.source_voxel_size
              << " max_source_points=" << ndt_options.max_source_points
              << " resolution=" << ndt_options.resolution
              << " max_iterations=" << ndt_options.max_iterations
              << " map_max_points=" << ndt_options.map_max_points << std::endl;
    results.push_back(runNDT(pcd_dirs, gt, ndt_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "fixed_map_ndt")) {
    std::cout << "Running FixedMap-NDT..." << std::endl;
    std::cout << "  source_voxel_size=" << ndt_options.source_voxel_size
              << " max_source_points=" << ndt_options.max_source_points
              << " resolution=" << ndt_options.resolution
              << " max_iterations=" << ndt_options.max_iterations
              << " map_max_points=" << ndt_options.map_max_points
              << " map_stride=" << fixed_map_ndt_options.map_stride
              << " map_ply="
              << (fixed_map_ndt_options.map_ply_path.empty()
                      ? "(sequence-built)"
                      : fixed_map_ndt_options.map_ply_path)
              << " seed_source=" << fixed_map_ndt_options.seed_source
              << " publish_min_stable_frames="
              << fixed_map_ndt_options.publish_min_stable_frames
              << " publish_max_hold_frames="
              << fixed_map_ndt_options.publish_max_hold_frames
              << " sc_relock_min_confirmations="
              << fixed_map_ndt_options.scan_context_relock_min_confirmations
              << " sc_relock_max_distance=" << std::fixed << std::setprecision(3)
              << fixed_map_ndt_options.scan_context_relock_max_distance
              << " sc_relock_max_ndt_score="
              << fixed_map_ndt_options.scan_context_relock_max_ndt_score
              << " trace_json="
              << (fixed_map_ndt_options.trace_json_path.empty()
                      ? "off"
                      : fixed_map_ndt_options.trace_json_path)
              << std::endl;
    results.push_back(runFixedMapNDT(pcd_dirs, gt, ndt_options,
                                     ct_icp_options, fixed_map_ndt_options));
  }

  if (isMethodEnabled(selected_methods, "kiss_icp")) {
    std::cout << "Running KISS-ICP..." << std::endl;
    std::cout << "  source_voxel_size=" << kiss_icp_options.source_voxel_size
              << " max_source_points=" << kiss_icp_options.max_source_points
              << " voxel_size=" << kiss_icp_options.voxel_size
              << " max_iterations=" << kiss_icp_options.max_icp_iterations
              << " local_map_radius=" << kiss_icp_options.local_map_radius
              << " update_full_voxels="
              << (kiss_icp_options.update_full_voxels ? "on" : "off")
              << " model_deviation_threshold="
              << (kiss_icp_options.use_model_deviation_threshold ? "on"
                                                                 : "off")
              << " model_deviation_correspondence_multiplier="
              << kiss_icp_options
                     .model_deviation_correspondence_multiplier
              << " mulran_deskew="
              << (kiss_icp_options.deskew_mulran ? "on" : "off")
              << " motion_guard="
              << (kiss_icp_options.enable_motion_guard ? "on" : "off")
              << " max_step_translation_m="
              << kiss_icp_options.max_step_translation_m
              << " max_step_rotation_deg="
              << kiss_icp_options.max_step_rotation_deg
              << std::endl;
    results.push_back(runKISSICP(pcd_dirs, gt, kiss_icp_options));
  }

  if (isMethodEnabled(selected_methods, "kiss_multi_horizon")) {
    std::cout << "Running KISS-Multi-Horizon..." << std::endl;
    std::cout << "  source_voxel_size="
              << kiss_multi_horizon_options.frontend.source_voxel_size
              << " max_source_points="
              << kiss_multi_horizon_options.frontend.max_source_points
              << " keyframe_stride="
              << kiss_multi_horizon_options.keyframe_stride
              << " matcher_voxel_size="
              << kiss_multi_horizon_options.matcher_voxel_size
              << " correction_gain="
              << kiss_multi_horizon_options.correction_gain << std::endl;
    results.push_back(runKISSMultiHorizon(
        pcd_dirs, gt, kiss_multi_horizon_options));
  }

  if (isMethodEnabled(selected_methods, "kiss_pose_graph") ||
      isMethodEnabled(selected_methods, "kiss_pose_graph_causal")) {
    const bool causal_pose_graph =
        isMethodEnabled(selected_methods, "kiss_pose_graph_causal");
    std::cout << "Running KISS-Pose-Graph"
              << (causal_pose_graph ? "-Causal" : "") << "..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size="
              << kiss_icp_options.source_voxel_size
              << " max_source_points="
              << kiss_icp_options.max_source_points
              << " voxel_size=" << kiss_icp_options.voxel_size
              << " keyframe_stride=10"
              << " scan_context_threshold="
              << kiss_pose_graph_scan_context_threshold
              << " correction_gain="
              << kiss_pose_graph_correction_gain
              << " external_poses="
              << (kiss_pose_graph_external_pose_path.empty()
                      ? "none"
                      : kiss_pose_graph_external_pose_path)
              << " output_policy="
              << (causal_pose_graph ? "causal_current_pose"
                                    : "offline_retrospective")
              << " floor_constraint=off" << std::setprecision(1)
              << std::endl;
    results.push_back(runKISSPoseGraph(
        pcd_dirs, gt, kiss_icp_options,
        kiss_pose_graph_scan_context_threshold,
        kiss_pose_graph_correction_gain,
        kiss_pose_graph_external_pose_path,
        causal_pose_graph));
  }

  if (isMethodEnabled(selected_methods, "genz_icp")) {
    std::cout << "Running GenZ-ICP..." << std::endl;
    std::cout << "  source_voxel_size=" << genz_icp_options.source_voxel_size
              << " max_source_points=" << genz_icp_options.max_source_points
              << " voxel_size=" << genz_icp_options.voxel_size
              << " planarity_threshold=" << genz_icp_options.planarity_threshold
              << " max_iterations=" << genz_icp_options.max_icp_iterations
              << std::endl;
    results.push_back(runGenZICP(pcd_dirs, gt, genz_icp_options));
  }

  if (isMethodEnabled(selected_methods, "l_lo")) {
    std::cout << "Running L-LO..." << std::endl;
    results.push_back(runLLO(pcd_dirs, gt, l_lo_params));
  }

  if (isMethodEnabled(selected_methods, "lf_gicp")) {
    std::cout << "Running LF-GICP..." << std::endl;
    std::cout << "  mitigation=" << (lf_gicp_options.enable_mitigation ? "on" : "off")
              << " beta=" << lf_gicp_options.covariance_regularization << std::endl;
    results.push_back(runLFGICP(pcd_dirs, gt, lf_gicp_options));
  }

  if (isMethodEnabled(selected_methods, "adaptive_icp")) {
    std::cout << "Running Adaptive-ICP..." << std::endl;
    std::cout << "  source_voxel_size=" << adaptive_icp_options.source_voxel_size
              << " voxel_size=" << adaptive_icp_options.voxel_size
              << " density_percentile=" << adaptive_icp_options.density_percentile
              << " reliable_tau=" << adaptive_icp_options.reliable_translation_tau
              << " max_iterations=" << adaptive_icp_options.max_icp_iterations
              << std::endl;
    results.push_back(runAdaptiveICP(pcd_dirs, gt, adaptive_icp_options));
  }

  if (isMethodEnabled(selected_methods, "rko_lio")) {
    std::cout << "Running RKO-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << rko_lio_options.source_voxel_size
              << " max_source_points=" << rko_lio_options.max_source_points
              << " voxel_size=" << rko_lio_options.voxel_size
              << " max_iterations=" << rko_lio_options.max_icp_iterations
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runRKOLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                                rko_lio_options));
  }

  if (isMethodEnabled(selected_methods, "fr_lio")) {
    std::cout << "Running FR-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << fr_lio_options.source_voxel_size
              << " voxel_size=" << fr_lio_options.voxel_size
              << " grid_size=" << fr_lio_options.grid_size
              << " max_subframes=" << fr_lio_options.max_subframes
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runFRLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                               fr_lio_options));
  }

  if (isMethodEnabled(selected_methods, "pg_lio")) {
    std::cout << "Running PG-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << pg_lio_options.source_voxel_size
              << " voxel_size=" << pg_lio_options.voxel_size
              << " range_image=" << pg_lio_options.range_image_width << "x"
              << pg_lio_options.range_image_height
              << " max_patches=" << pg_lio_options.max_patches
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runPGLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                               pg_lio_options));
  }

  if (isMethodEnabled(selected_methods, "d2lio")) {
    std::cout << "Running D2-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << d2lio_options.source_voxel_size
              << " voxel_size=" << d2lio_options.voxel_size
              << " degeneracy_ratio="
              << d2lio_options.degeneracy_ratio
              << " imu_prior_weight=" << d2lio_options.imu_prior_weight
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runD2LIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                               d2lio_options));
  }

  if (isMethodEnabled(selected_methods, "ct_voxelmap")) {
    std::cout << "Running CT-VoxelMap..." << std::endl;
    std::cout << "  source_voxel_size=" << ct_voxelmap_options.source_voxel_size
              << " voxel_size=" << ct_voxelmap_options.voxel_size
              << " voxel_min_points=" << ct_voxelmap_options.voxel_min_points
              << " planarity_ratio=" << ct_voxelmap_options.planarity_ratio
              << " max_iterations=" << ct_voxelmap_options.max_icp_iterations
              << std::endl;
    results.push_back(runCTVoxelMap(pcd_dirs, gt, ct_voxelmap_options));
  }

  if (isMethodEnabled(selected_methods, "r_voxelmap")) {
    std::cout << "Running R-VoxelMap..." << std::endl;
    std::cout << "  source_voxel_size=" << r_voxelmap_options.source_voxel_size
              << " voxel_size=" << r_voxelmap_options.voxel_size
              << " max_depth=" << r_voxelmap_options.max_depth
              << " inlier_dist=" << r_voxelmap_options.inlier_dist
              << " max_iterations=" << r_voxelmap_options.max_icp_iterations
              << " map_fallback_delta="
              << r_voxelmap_options.max_map_fallback_translation_delta << "m/"
              << r_voxelmap_options.max_map_fallback_rotation_delta << "rad"
              << std::endl;
    results.push_back(runRVoxelMap(pcd_dirs, gt, r_voxelmap_options));
  }

  if (isMethodEnabled(selected_methods, "damm_loam")) {
    std::cout << "Running DAMM-LOAM..." << std::endl;
    std::cout << "  source_voxel_size=" << damm_loam_options.source_voxel_size
              << " voxel_size=" << damm_loam_options.voxel_size
              << " degeneracy_ratio=" << damm_loam_options.degeneracy_ratio
              << " edge_weight=" << damm_loam_options.edge_weight
              << " max_iterations=" << damm_loam_options.max_icp_iterations
              << std::endl;
    results.push_back(runDammLoam(pcd_dirs, gt, damm_loam_options));
  }

  if (isMethodEnabled(selected_methods, "lodestar")) {
    std::cout << "Running LODESTAR..." << std::endl;
    std::cout << "  source_voxel_size=" << lodestar_options.source_voxel_size
              << " voxel_size=" << lodestar_options.voxel_size
              << " t_chi=" << lodestar_options.t_chi
              << " anchor_strength=" << lodestar_options.anchor_strength
              << " data_exploitation=" << lodestar_options.enable_data_exploitation
              << " max_iterations=" << lodestar_options.max_icp_iterations
              << std::endl;
    results.push_back(runLodestar(pcd_dirs, gt, lodestar_options));
  }

  if (isMethodEnabled(selected_methods, "terrain_rbf_lio")) {
    std::cout << "Running Terrain-RBF-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << terrain_rbf_options.source_voxel_size
              << " voxel_size=" << terrain_rbf_options.voxel_size
              << " terrain_cell=" << terrain_rbf_options.terrain_cell_size
              << " terrain_weight=" << terrain_rbf_options.terrain_weight
              << " max_iterations=" << terrain_rbf_options.max_icp_iterations
              << std::endl;
    results.push_back(runTerrainRbf(pcd_dirs, gt, terrain_rbf_options));
  }

  if (isMethodEnabled(selected_methods, "lidar_iba")) {
    std::cout << "Running LiDAR-IBA..." << std::endl;
    std::cout << "  source_voxel_size=" << lidar_iba_options.source_voxel_size
              << " voxel_size=" << lidar_iba_options.voxel_size
              << " enable_ba=" << lidar_iba_options.enable_ba
              << " window=" << lidar_iba_options.window_size
              << " pose_prior=" << lidar_iba_options.pose_prior_weight
              << " max_iterations=" << lidar_iba_options.max_icp_iterations
              << std::endl;
    results.push_back(runLidarIba(pcd_dirs, gt, lidar_iba_options));
  }

  if (isMethodEnabled(selected_methods, "dali_slam")) {
    std::cout << "Running DALI-SLAM..." << std::endl;
    std::cout << "  source_voxel_size=" << dali_slam_options.source_voxel_size
              << " voxel_size=" << dali_slam_options.voxel_size
              << " deskew=" << dali_slam_options.enable_deskew
              << " degeneracy_ratio=" << dali_slam_options.degeneracy_ratio
              << " max_iterations=" << dali_slam_options.max_icp_iterations
              << std::endl;
    results.push_back(runDaliSlam(pcd_dirs, gt, dali_slam_options));
  }

  if (isMethodEnabled(selected_methods, "intensity_flow")) {
    std::cout << "Running Intensity-Flow..." << std::endl;
    std::cout << "  source_voxel_size=" << intensity_flow_options.source_voxel_size
              << " voxel_size=" << intensity_flow_options.voxel_size
              << " keep_ratio=" << intensity_flow_options.gf_keep_ratio
              << " intensity=" << intensity_flow_options.enable_intensity
              << " max_iterations=" << intensity_flow_options.max_icp_iterations
              << std::endl;
    results.push_back(runIntensityFlow(pcd_dirs, gt, intensity_flow_options));
  }

  if (isMethodEnabled(selected_methods, "svn_icp")) {
    std::cout << "Running SVN-ICP..." << std::endl;
    std::cout << "  source_voxel_size=" << svn_icp_options.source_voxel_size
              << " voxel_size=" << svn_icp_options.voxel_size
              << " num_particles=" << svn_icp_options.num_particles
              << " svn_iterations=" << svn_icp_options.svn_iterations
              << " lidar_sigma=" << svn_icp_options.lidar_sigma
              << std::endl;
    results.push_back(runSvnIcp(pcd_dirs, gt, svn_icp_options));
  }

  if (isMethodEnabled(selected_methods, "pcr_dat")) {
    std::cout << "Running PCR-DAT..." << std::endl;
    std::cout << "  source_voxel_size=" << pcr_dat_options.source_voxel_size
              << " voxel_size=" << pcr_dat_options.voxel_size
              << " distribution_min_points="
              << pcr_dat_options.distribution_min_points
              << " distance_sigma=" << pcr_dat_options.distance_sigma
              << std::endl;
    results.push_back(runPcrDat(pcd_dirs, gt, pcr_dat_options));
  }

  if (isMethodEnabled(selected_methods, "small_mighty")) {
    std::cout << "Running Small-but-Mighty..." << std::endl;
    std::cout << "  source_voxel_size=" << small_mighty_options.source_voxel_size
              << " voxel_size=" << small_mighty_options.voxel_size
              << " contribution_gain=" << small_mighty_options.contribution_gain
              << " edge_weight=" << small_mighty_options.edge_weight
              << std::endl;
    results.push_back(runSmallMighty(pcd_dirs, gt, small_mighty_options));
  }

  if (isMethodEnabled(selected_methods, "m_gclo")) {
    std::cout << "Running M-GCLO..." << std::endl;
    std::cout << "  source_voxel_size=" << m_gclo_options.source_voxel_size
              << " voxel_size=" << m_gclo_options.voxel_size
              << " ground_constraints="
              << m_gclo_options.ground_constraints
              << " ground_weight=" << m_gclo_options.ground_weight
              << " ground_normal_threshold="
              << m_gclo_options.ground_normal_threshold << std::endl;
    results.push_back(runMGclo(pcd_dirs, gt, m_gclo_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "quadric_lo")) {
    std::cout << "Running Quadric-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << quadric_lo_options.source_voxel_size
              << " voxel_size=" << quadric_lo_options.voxel_size
              << " quadric_min_neighbors="
              << quadric_lo_options.quadric_min_neighbors
              << " plane_fallback="
              << quadric_lo_options.allow_plane_fallback
              << " quadric_weight=" << quadric_lo_options.quadric_weight
              << std::endl;
    results.push_back(runQuadricLo(pcd_dirs, gt, quadric_lo_options));
  }

  if (isMethodEnabled(selected_methods, "dilo")) {
    std::cout << "Running DiLO..." << std::endl;
    std::cout << "  source_voxel_size=" << dilo_options.source_voxel_size
              << " sri=" << dilo_options.sri_height << "x"
              << dilo_options.sri_width
              << " lookup_radius=" << dilo_options.lookup_radius
              << " lookup_max_dist=" << dilo_options.max_lookup_point_distance
              << " keyframe_translation=" << dilo_options.keyframe_translation
              << std::endl;
    results.push_back(runDilo(pcd_dirs, gt, dilo_options));
  }

  if (isMethodEnabled(selected_methods, "nhc_lio")) {
    std::cout << "Running NHC-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << nhc_lio_options.source_voxel_size
              << " voxel_size=" << nhc_lio_options.voxel_size
              << " nhc_weight=" << nhc_lio_options.nhc_weight
              << " enable_nhc=" << nhc_lio_options.enable_nhc << std::endl;
    results.push_back(runNhcLio(pcd_dirs, gt, nhc_lio_options));
  }

  if (isMethodEnabled(selected_methods, "student_t_lo")) {
    std::cout << "Running Student-T-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << student_t_lo_options.source_voxel_size
              << " voxel_size=" << student_t_lo_options.voxel_size
              << " dof=" << student_t_lo_options.student_t_dof
              << " enable_student_t=" << student_t_lo_options.enable_student_t
              << std::endl;
    results.push_back(runStudentTLo(pcd_dirs, gt, student_t_lo_options));
  }

  if (isMethodEnabled(selected_methods, "spectral_lo")) {
    std::cout << "Running Spectral-LO..." << std::endl;
    std::cout << "  bev_size=" << spectral_lo_options.bev_size
              << " bev_range=" << spectral_lo_options.bev_range
              << " max_yaw_deg=" << spectral_lo_options.max_yaw_deg
              << " translation_refinement_iters="
              << spectral_lo_options.translation_refinement_iterations
              << std::endl;
    results.push_back(runSpectralLo(pcd_dirs, gt, spectral_lo_options));
  }

  if (isMethodEnabled(selected_methods, "gmm_lo")) {
    std::cout << "Running GMM-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << gmm_lo_options.source_voxel_size
              << " voxel_size=" << gmm_lo_options.voxel_size
              << " sigma_init=" << gmm_lo_options.sigma_init
              << " sigma_final=" << gmm_lo_options.sigma_final << std::endl;
    results.push_back(runGmmLo(pcd_dirs, gt, gmm_lo_options));
  }

  if (isMethodEnabled(selected_methods, "gnc_lo")) {
    std::cout << "Running GNC-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << gnc_lo_options.source_voxel_size
              << " voxel_size=" << gnc_lo_options.voxel_size
              << " gnc_truncation=" << gnc_lo_options.gnc_truncation
              << " gnc_factor=" << gnc_lo_options.gnc_factor << std::endl;
    results.push_back(runGncLo(pcd_dirs, gt, gnc_lo_options));
  }

  if (isMethodEnabled(selected_methods, "mcc_lo")) {
    std::cout << "Running MCC-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << mcc_lo_options.source_voxel_size
              << " voxel_size=" << mcc_lo_options.voxel_size
              << " mcc_sigma=" << mcc_lo_options.mcc_sigma
              << " adaptive_sigma=" << mcc_lo_options.mcc_adaptive_sigma << std::endl;
    results.push_back(runMccLo(pcd_dirs, gt, mcc_lo_options));
  }

  if (isMethodEnabled(selected_methods, "imls_slam")) {
    std::cout << "Running IMLS-SLAM..." << std::endl;
    if (imls_slam_options.paper_odometry) {
      std::ostringstream info;
      info << "  paper odometry: raw scans, window=" << imls_slam_options.paper_window_scans
           << " h=" << imls_slam_options.paper_h << " r=" << imls_slam_options.paper_r
           << " samples/list=" << imls_slam_options.paper_samples_per_list
           << " iterations=" << imls_slam_options.paper_iterations
           << " coarse_frames=" << imls_slam_options.paper_coarse_frames;
      std::cout << info.str() << std::endl;
    } else {
      std::cout << "  source_voxel_size=" << imls_slam_options.source_voxel_size
                << " voxel_size=" << imls_slam_options.voxel_size
                << " imls_h=" << imls_slam_options.imls_h
                << " sampling=" << imls_slam_options.use_observability_sampling
                << std::endl;
    }
    results.push_back(runImlsSlam(pcd_dirs, gt, imls_slam_options));
  }

  if (isMethodEnabled(selected_methods, "mesh_loam")) {
    std::cout << "Running Mesh-LOAM..." << std::endl;
    std::cout << "  source_voxel_size=" << mesh_loam_options.source_voxel_size
              << " voxel_size=" << mesh_loam_options.voxel_size
              << " mesh_interval=" << mesh_loam_options.mesh_update_interval
              << " cos_gate=" << mesh_loam_options.cos_gate << std::endl;
    results.push_back(runMeshLoam(pcd_dirs, gt, mesh_loam_options));
  }

  if (isMethodEnabled(selected_methods, "elo")) {
    std::cout << "Running ELO..." << std::endl;
    std::cout << "  source_voxel_size=" << elo_options.source_voxel_size
              << " max_source_points=" << elo_options.max_source_points
              << " sri=" << elo_options.sri_width << "x" << elo_options.sri_height
              << " bev_res=" << elo_options.bev_resolution
              << " ground_weight=" << elo_options.ground_weight << std::endl;
    results.push_back(runElo(pcd_dirs, gt, elo_options));
  }

  if (isMethodEnabled(selected_methods, "tc_lvgf")) {
    std::cout << "Running TC-LVGF..." << std::endl;
    std::cout << "  source_voxel_size=" << tc_lvgf_options.source_voxel_size
              << " voxel_size=" << tc_lvgf_options.voxel_size
              << " image=" << tc_lvgf_options.image_width << "x"
              << tc_lvgf_options.image_height
              << " line_weight=" << tc_lvgf_options.line_weight
              << " direction_weight=" << tc_lvgf_options.direction_weight
              << " min_visual_lines=" << tc_lvgf_options.min_visual_lines
              << std::endl;
    results.push_back(runTcLvgf(pcd_dirs, gt, tc_lvgf_options));
  }

  if (isMethodEnabled(selected_methods, "opl_lvio")) {
    std::cout << "Running OPL-LVIO..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size=" << opl_lvio_options.source_voxel_size
              << " voxel_size=" << opl_lvio_options.voxel_size
              << " image=" << opl_lvio_options.image_width << "x"
              << opl_lvio_options.image_height
              << " visual_point_weight=" << opl_lvio_options.visual_point_weight
              << " line_weight=" << opl_lvio_options.line_weight
              << " direction_weight=" << opl_lvio_options.direction_weight
              << " min_visual_points=" << opl_lvio_options.min_visual_points
              << std::endl;
    results.push_back(runOplLvio(pcd_dirs, gt, opl_lvio_options));
  }

  if (isMethodEnabled(selected_methods, "v_loam15")) {
    std::cout << "Running V-LOAM2015..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size=" << v_loam15_options.source_voxel_size
              << " voxel_size=" << v_loam15_options.voxel_size
              << " image=" << v_loam15_options.image_width << "x"
              << v_loam15_options.image_height << std::endl;
    results.push_back(runVisualLidarAdapter<
                      localization_zoo::v_loam15::VLoam15Pipeline,
                      localization_zoo::v_loam15::VLoam15Params>(
        pcd_dirs, gt, v_loam15_options, "V-LOAM2015", "V-LOAM2015",
        "V-LOAM2015: visual-lidar odometry port with range-image "
        "pseudo-visual bootstrapping and LiDAR scan-to-map refinement; "
        "global mapping/loop closure are out of scope on KITTI PCD."));
  }

  if (isMethodEnabled(selected_methods, "tc_vlo")) {
    std::cout << "Running TC-VLO..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size=" << tc_vlo_options.source_voxel_size
              << " voxel_size=" << tc_vlo_options.voxel_size
              << " image=" << tc_vlo_options.image_width << "x"
              << tc_vlo_options.image_height << std::endl;
    results.push_back(runVisualLidarAdapter<
                      localization_zoo::tc_vlo::TcVloPipeline,
                      localization_zoo::tc_vlo::TcVloParams>(
        pcd_dirs, gt, tc_vlo_options, "TC-VLO", "TC-VLO",
        "TC-VLO: tightly coupled vision-lidar odometry port with separate "
        "visual point and LiDAR voxel maps jointly optimized through "
        "plane, point, and line residuals."));
  }

  if (isMethodEnabled(selected_methods, "ad_vlo")) {
    std::cout << "Running AD-VLO..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size=" << ad_vlo_options.source_voxel_size
              << " voxel_size=" << ad_vlo_options.voxel_size
              << " image=" << ad_vlo_options.image_width << "x"
              << ad_vlo_options.image_height << std::endl;
    results.push_back(runVisualLidarAdapter<
                      localization_zoo::ad_vlo::AdVloPipeline,
                      localization_zoo::ad_vlo::AdVloParams>(
        pcd_dirs, gt, ad_vlo_options, "AD-VLO", "AD-VLO",
        "AD-VLO: direct visual-laser odometry port with occlusion-aware "
        "range discontinuity gating, planar patch emphasis, and LiDAR "
        "scan-to-map refinement."));
  }

  if (isMethodEnabled(selected_methods, "tc_mvlo")) {
    std::cout << "Running TC-MVLO..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size=" << tc_mvlo_options.source_voxel_size
              << " voxel_size=" << tc_mvlo_options.voxel_size
              << " image=" << tc_mvlo_options.image_width << "x"
              << tc_mvlo_options.image_height << std::endl;
    results.push_back(runVisualLidarAdapter<
                      localization_zoo::tc_mvlo::TcMvloPipeline,
                      localization_zoo::tc_mvlo::TcMvloParams>(
        pcd_dirs, gt, tc_mvlo_options, "TC-MVLO", "TC-MVLO",
        "TC-MVLO: tightly coupled monocular visual-lidar odometry port "
        "using range-image visual points, fused visual/LiDAR line support, "
        "and LiDAR scan-to-map constraints; loop closure is out of scope."));
  }

  if (isMethodEnabled(selected_methods, "tricp_lo")) {
    std::cout << "Running TrICP-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << tricp_lo_options.source_voxel_size
              << " voxel_size=" << tricp_lo_options.voxel_size
              << " auto_overlap=" << tricp_lo_options.auto_overlap
              << " lambda=" << tricp_lo_options.frmsd_lambda << std::endl;
    results.push_back(runTricpLo(pcd_dirs, gt, tricp_lo_options));
  }

  if (isMethodEnabled(selected_methods, "kc_lo")) {
    std::cout << "Running KC-LO..." << std::endl;
    std::cout << "  source_voxel_size=" << kc_lo_options.source_voxel_size
              << " voxel_size=" << kc_lo_options.voxel_size
              << " kc_sigma=" << kc_lo_options.kc_sigma
              << " sigma_init=" << kc_lo_options.kc_sigma_init << std::endl;
    results.push_back(runKcLo(pcd_dirs, gt, kc_lo_options));
  }

  if (isMethodEnabled(selected_methods, "i_loam")) {
    std::cout << "Running I-LOAM..." << std::endl;
    std::cout << "  n_scans=" << i_loam_options.n_scans
              << " stride=" << i_loam_options.input_point_stride
              << " mapping=" << i_loam_options.enable_mapping
              << " intensity_weight=" << i_loam_options.use_intensity_weight
              << " intensity_corr=" << i_loam_options.use_intensity_correspondence
              << " intensity_sigma=" << i_loam_options.intensity_sigma
              << " corr_weight=" << i_loam_options.intensity_corr_weight
              << std::endl;
    results.push_back(runILoam(pcd_dirs, gt, i_loam_options));
  }
  if (isMethodEnabled(selected_methods, "pl_loam")) {
    std::cout << "\n=== PL-LOAM ===" << std::endl;
    std::cout << "  stride=" << pl_loam_options.input_stride
              << " points=" << pl_loam_options.max_point_features
              << " lines=" << pl_loam_options.max_line_features
              << " depth_prior=" << pl_loam_options.use_depth_prior
              << " line_features=" << pl_loam_options.use_line_features
              << " scale_corr=" << pl_loam_options.use_scale_correction
              << " rgb=" << pl_loam_options.use_rgb
              << std::endl;
    results.push_back(runPlLoam(pcd_dirs, gt, frame_timestamps, pl_loam_options));
  }
  if (isMethodEnabled(selected_methods, "inten_loam")) {
    std::cout << "\n=== InTEn-LOAM ===" << std::endl;
    std::cout << "  stride=" << inten_loam_options.input_stride
              << " cyl=" << inten_loam_options.cyl_width << "x"
              << inten_loam_options.cyl_height
              << " intensity_reg=" << inten_loam_options.use_intensity_registration
              << " tvf=" << inten_loam_options.enable_tvf
              << " dor=" << inten_loam_options.enable_dor
              << " mapping=" << inten_loam_options.enable_mapping
              << std::endl;
    try {
      results.push_back(runInTenLoam(pcd_dirs, gt, inten_loam_options));
    } catch (const std::exception& error) {
      std::cerr << "InTEn-LOAM failed: " << error.what() << std::endl;
      return 2;
    }
  }
  if (isMethodEnabled(selected_methods, "mcgicp")) {
    std::cout << "\n=== MCGICP-LO ===" << std::endl;
    std::cout << "  source_voxel_size=" << mcgicp_options.source_voxel_size
              << " voxel_size=" << mcgicp_options.voxel_size
              << " intensity_scale=" << mcgicp_options.intensity_scale
              << " enable_intensity=" << mcgicp_options.enable_intensity
              << std::endl;
    results.push_back(runMcGicpLo(pcd_dirs, gt, mcgicp_options));
  }
  if (isMethodEnabled(selected_methods, "icpsc")) {
    std::cout << "\n=== ICPSC-LO ===" << std::endl;
    std::cout << "  source_voxel_size=" << icpsc_options.source_voxel_size
              << " cyl=" << icpsc_options.cyl_width << "x"
              << icpsc_options.cyl_height
              << " enable_intensity=" << icpsc_options.enable_intensity
              << std::endl;
    results.push_back(runIcpscLo(pcd_dirs, gt, icpsc_options));
  }
  if (isMethodEnabled(selected_methods, "vlom")) {
    std::cout << "\n=== VLOM ===" << std::endl;
    std::cout << "  stride=" << vlom_options.input_point_stride
              << " bootstrap=" << vlom_options.enable_visual_bootstrap
              << " scale_corr=" << vlom_options.enable_scale_correction
              << " rgb=" << vlom_options.use_rgb
              << std::endl;
    results.push_back(runVlom(pcd_dirs, gt, frame_timestamps, vlom_options));
  }
  if (isMethodEnabled(selected_methods, "odonet")) {
    std::cout << "\n=== OdoNet ===" << std::endl;
    std::cout << "  weights=" << odonet_options.weights_path
              << " nhc=" << odonet_options.enable_nhc
              << " zupt=" << odonet_options.enable_zupt
              << " cnn=" << odonet_options.enable_cnn_speed << std::endl;
    results.push_back(
        runOdoNet(gt, frame_timestamps, imu_samples, odonet_options));
  }
  if (isMethodEnabled(selected_methods, "nhc_net")) {
    std::cout << "\n=== NHC-Net ===" << std::endl;
    std::cout << "  weights=" << nhc_net_options.weights_path
              << " adaptive=" << nhc_net_options.adaptive_gain
              << " gain=" << nhc_net_options.nhc_gain << std::endl;
    results.push_back(
        runNhcNet(gt, frame_timestamps, imu_samples, nhc_net_options));
  }
  if (isMethodEnabled(selected_methods, "nn_zupt")) {
    std::cout << "\n=== NN-ZUPT ===" << std::endl;
    std::cout << "  weights=" << nn_zupt_options.weights_path
              << " prob=" << nn_zupt_options.stop_prob_threshold
              << " threshold_only=" << nn_zupt_options.use_threshold_detector
              << std::endl;
    results.push_back(
        runNnZupt(gt, frame_timestamps, imu_samples, nn_zupt_options));
  }
  if (isMethodEnabled(selected_methods, "imu_dead_reckoning")) {
    std::cout << "\n=== IMU-DR ===" << std::endl;
    std::cout << "  static_init_sec="
              << imu_dead_reckoning_options.static_init_duration_s
              << " midpoint=" << imu_dead_reckoning_options.midpoint_integration
              << " zupt=" << imu_dead_reckoning_options.enable_zupt
              << std::endl;
    results.push_back(runImuDeadReckoning(gt, frame_timestamps, imu_samples,
                                          imu_dead_reckoning_options));
  }

  if (isMethodEnabled(selected_methods, "degen_sense")) {
    std::cout << "Running DegenSense..." << std::endl;
    std::cout << "  source_voxel_size=" << degen_sense_options.source_voxel_size
              << " voxel_size=" << degen_sense_options.voxel_size
              << " warmup_frames=" << degen_sense_options.warmup_frames
              << " mad_k=" << degen_sense_options.mad_k
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runDegenSense(pcd_dirs, gt, frame_timestamps, imu_samples,
                                    degen_sense_options));
  }

  if (isMethodEnabled(selected_methods, "vibration_lio")) {
    std::cout << "Running Vibration-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << vibration_lio_options.source_voxel_size
              << " voxel_size=" << vibration_lio_options.voxel_size
              << " gamma=" << vibration_lio_options.gamma
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runVibrationLIO(pcd_dirs, gt, frame_timestamps,
                                      imu_samples, vibration_lio_options));
  }

  if (isMethodEnabled(selected_methods, "id_lio")) {
    std::cout << "Running ID-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << id_lio_options.source_voxel_size
              << " voxel_size=" << id_lio_options.voxel_size
              << " range_image=" << id_lio_options.range_image_width << "x"
              << id_lio_options.range_image_height
              << " dynamic_weight=" << id_lio_options.dynamic_weight
              << " delayed_removal_frames="
              << id_lio_options.delayed_removal_frames
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runIDLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                               id_lio_options));
  }

  if (isMethodEnabled(selected_methods, "rf_lio")) {
    std::cout << "Running RF-LIO..." << std::endl;
    std::cout << std::setprecision(3)
              << "  source_voxel_size=" << rf_lio_options.source_voxel_size
              << " voxel_size=" << rf_lio_options.voxel_size
              << " range_image=" << rf_lio_options.range_image_width << "x"
              << rf_lio_options.range_image_height
              << " foreground_margin=" << rf_lio_options.foreground_margin
              << " max_removal_fraction="
              << rf_lio_options.max_removal_fraction
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runRFLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                               rf_lio_options));
  }

  if (isMethodEnabled(selected_methods, "bievr_lio")) {
    std::cout << "Running BIEVR-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << bievr_lio_options.source_voxel_size
              << " voxel_size=" << bievr_lio_options.voxel_size
              << " pixel_res=" << bievr_lio_options.pixel_res << std::endl;
    results.push_back(runBievrLIO(pcd_dirs, gt, bievr_lio_options));
  }

  if (isMethodEnabled(selected_methods, "ua_lio")) {
    std::cout << "Running UA-LIO..." << std::endl;
    std::cout << "  source_voxel_size=" << ua_lio_options.source_voxel_size
              << " voxel_size=" << ua_lio_options.voxel_size
              << " ground_constraint=" << ua_lio_options.ground_constraint
              << " imu=" << (imu_samples.empty() ? "absent" : "present")
              << std::endl;
    results.push_back(runUALIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                               ua_lio_options));
  }

  if (isMethodEnabled(selected_methods, "cube_lio")) {
    std::cout << "Running CUBE-LIO..." << std::endl;
    std::cout << "  input_voxel_size=" << cube_lio_options.input_voxel_size
              << " voxel_size=" << cube_lio_options.voxel_size
              << " cubemap_size=" << cube_lio_options.cubemap_size
              << " semi_dense_quantile=" << cube_lio_options.semi_dense_quantile
              << " intensity_sigma=" << cube_lio_options.intensity_sigma
              << std::endl;
    results.push_back(runCubeLIO(pcd_dirs, gt, cube_lio_options));
  }

  if (isMethodEnabled(selected_methods, "dlo")) {
    std::cout << "Running DLO..." << std::endl;
    std::cout << "  input_voxel_size=" << dlo_options.input_voxel_size
              << " max_input_points=" << dlo_options.max_input_points
              << " reg_voxel=" << dlo_options.registration_voxel_size
              << " map_voxel=" << dlo_options.map_voxel_size
              << " max_keyframes=" << dlo_options.max_keyframes_in_map
              << " gicp_iters=" << dlo_options.gicp_max_iterations << std::endl;
    results.push_back(runDLO(pcd_dirs, gt, dlo_options));
  }

  if (isMethodEnabled(selected_methods, "dlio")) {
    std::cout << "Running DLIO..." << std::endl;
    std::cout << "  input_voxel_size=" << dlio_options.input_voxel_size
              << " max_input_points=" << dlio_options.max_input_points
              << " reg_voxel=" << dlio_options.registration_voxel_size
              << " map_voxel=" << dlio_options.map_voxel_size
              << " imu_rot_w=" << dlio_options.imu_rotation_fusion_weight
              << " imu_trans_w=" << dlio_options.imu_translation_fusion_weight
              << std::endl;
    results.push_back(runDLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                              dlio_options));
  }

  constexpr double kCTLIORecommendedMedianGapSec = 0.5;
  if (isMethodEnabled(selected_methods, "ct_lio")) {
    if (imu_samples.empty()) {
      results.push_back(makeSkippedResult(
          "CT-LIO", "imu.csv not found. CT-LIO requires synchronized IMU samples."));
    } else if (!force_ct_lio &&
               frame_timestamp_source != FrameTimestampSource::kSampledGT &&
               frame_gap_stats.valid &&
               frame_gap_stats.median_gap > kCTLIORecommendedMedianGapSec) {
      std::ostringstream oss;
      oss << "median frame gap " << std::fixed << std::setprecision(3)
          << frame_gap_stats.median_gap << " s exceeds CT-LIO threshold "
          << kCTLIORecommendedMedianGapSec
          << " s. Input looks like sparse graph keyframes/submaps, not raw scans. "
          << "Use a dense scan sequence or pass --force-ct-lio to override.";
      results.push_back(makeSkippedResult("CT-LIO", oss.str()));
      std::cout << "Skipping CT-LIO: " << oss.str() << std::endl;
    } else {
      std::cout << "Running CT-LIO..." << std::endl;
      if (ct_lio_fixed_lag_window > 1) {
        std::cout << "  fixed-lag window=" << ct_lio_fixed_lag_window
                  << " velocity_weight=" << ct_lio_fixed_lag_velocity_weight
                  << " gyro_bias_scale=" << ct_lio_fixed_lag_gyro_bias_scale
                  << " accel_bias_scale=" << ct_lio_fixed_lag_accel_bias_scale
                  << " history_decay=" << ct_lio_fixed_lag_history_decay
                  << " outer_iterations=" << ct_lio_fixed_lag_outer_iterations
                  << " smoother="
                  << (ct_lio_fixed_lag_smoother ? "on" : "off")
                  << std::endl;
      }
      results.push_back(
          runCTLIO(pcd_dirs, gt, frame_timestamps, imu_samples,
                   ct_lio_estimate_bias, ct_lio_fixed_lag_window,
                   ct_lio_fixed_lag_velocity_weight,
                   ct_lio_fixed_lag_gyro_bias_scale,
                   ct_lio_fixed_lag_accel_bias_scale,
                   ct_lio_fixed_lag_history_decay,
                   ct_lio_fixed_lag_outer_iterations,
                   ct_lio_fixed_lag_smoother,
                   ct_lio_multi_scale,
                   ct_lio_coarse_to_fine,
                   ct_lio_coarse_iterations,
                   ct_lio_coarse_search_radius,
                   ct_lio_coarse_planarity_threshold,
                   ct_lio_coarse_cauchy_mult,
                   ct_lio_max_frames_in_map,
                   ct_lio_max_iterations,
                   ct_lio_bspline,
                   ct_lio_bspline_anchor_weight));
    }
  }

  if (isMethodEnabled(selected_methods, "ct_icp")) {
    std::cout << "Running CT-ICP..." << std::endl;
    std::cout << "  source_voxel_size=" << ct_icp_options.source_voxel_size
              << " max_source_points=" << ct_icp_options.max_source_points
              << " voxel_resolution=" << ct_icp_options.voxel_resolution
              << " max_iterations=" << ct_icp_options.max_iterations
              << " ceres_max_iterations="
              << ct_icp_options.ceres_max_iterations
              << " max_frames_in_map=" << ct_icp_options.max_frames_in_map
              << " multi_scale="
              << (ct_icp_options.multi_scale_correspondences ? "on" : "off")
              << " normal_cholesky="
              << (ct_icp_options.use_normal_cholesky_solver ? "on" : "off")
              << " regularizer_n_cap="
              << ct_icp_options.regularizer_n_cap
              << " auto_regularizer_cap="
              << (ct_icp_options.auto_regularizer_cap ? "on" : "off")
              << std::endl;
    results.push_back(runCTICP(pcd_dirs, gt, ct_icp_options, ct_icp_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "ct_icp_ndt")) {
    std::cout << "Running CT-ICP+NDT..." << std::endl;
    std::cout << "  ct_icp_voxel_resolution=" << ct_icp_options.voxel_resolution
              << " ct_icp_max_iterations=" << ct_icp_options.max_iterations
              << " ndt_resolution=" << ndt_options.resolution
              << " ndt_max_iterations=" << ndt_options.max_iterations
              << std::endl;
    results.push_back(runCTICPNDT(pcd_dirs, gt, ct_icp_options, ndt_options));
  }

  if (isMethodEnabled(selected_methods, "ct_icp_ndt_keyframe")) {
    std::cout << "Running CT-ICP+NDT keyframe..." << std::endl;
    std::cout << "  ct_icp_voxel_resolution=" << ct_icp_options.voxel_resolution
              << " ct_icp_max_iterations=" << ct_icp_options.max_iterations
              << " ndt_resolution=" << ndt_options.resolution
              << " ndt_max_iterations=" << ndt_options.max_iterations
              << " keyframe_interval="
              << ct_icp_ndt_options.keyframe_interval
              << " max_correction_translation="
              << ct_icp_ndt_options.max_correction_translation_delta
              << " max_correction_rotation_rad="
              << ct_icp_ndt_options.max_correction_rotation_delta_rad
              << std::endl;
    results.push_back(runCTICPNDTKeyframe(
        pcd_dirs, gt, ct_icp_options, ndt_options, ct_icp_ndt_options));
  }

  if (isMethodEnabled(selected_methods, "xicp")) {
    std::cout << "Running X-ICP..." << std::endl;
    results.push_back(runXICP(pcd_dirs, gt, xicp_options, no_gt_seed));
  }

  if (isMethodEnabled(selected_methods, "fast_lio2")) {
    std::cout << "Running FAST-LIO2..." << std::endl;
    results.push_back(runFastLio2(pcd_dirs, gt, frame_timestamps, imu_samples, fast_lio2_options));
  }

  if (isMethodEnabled(selected_methods, "hdl_graph_slam")) {
    std::cout << "Running HDL-Graph-SLAM..." << std::endl;
    results.push_back(runHdlGraphSlam(pcd_dirs, gt, hdl_graph_slam_options));
  }

  if (isMethodEnabled(selected_methods, "vgicp_slam")) {
    std::cout << "Running VGICP-SLAM..." << std::endl;
    results.push_back(runVgicpSlam(pcd_dirs, gt, vgicp_slam_options));
  }

  if (isMethodEnabled(selected_methods, "suma")) {
    std::cout << "Running SuMa..." << std::endl;
    results.push_back(runSuMa(pcd_dirs, gt, suma_options));
  }

  if (isMethodEnabled(selected_methods, "balm2")) {
    std::cout << "Running BALM2..." << std::endl;
    results.push_back(runBalm2(pcd_dirs, gt, balm2_options));
  }

  if (isMethodEnabled(selected_methods, "isc_loam")) {
    std::cout << "Running ISC-LOAM..." << std::endl;
    results.push_back(runIscLoam(pcd_dirs, gt, isc_loam_options));
  }

  if (isMethodEnabled(selected_methods, "loam_livox")) {
    std::cout << "Running LOAM-Livox..." << std::endl;
    results.push_back(runLoamLivox(pcd_dirs, gt, loam_livox_options));
  }

  if (isMethodEnabled(selected_methods, "lio_sam")) {
    std::cout << "Running LIO-SAM..." << std::endl;
    results.push_back(runLioSam(pcd_dirs, gt, frame_timestamps, imu_samples,
                                lio_sam_options));
  }

  if (isMethodEnabled(selected_methods, "lins")) {
    std::cout << "Running LINS..." << std::endl;
    results.push_back(runLINS(pcd_dirs, gt, frame_timestamps, imu_samples,
                              lins_options));
  }

  if (isMethodEnabled(selected_methods, "fast_lio_slam")) {
    std::cout << "Running FAST-LIO-SLAM..." << std::endl;
    results.push_back(runFastLioSlam(pcd_dirs, gt, frame_timestamps, imu_samples,
                                     fast_lio_slam_options));
  }

  if (isMethodEnabled(selected_methods, "point_lio")) {
    std::cout << "Running Point-LIO..." << std::endl;
    results.push_back(runPointLio(pcd_dirs, gt, frame_timestamps, imu_samples,
                                  point_lio_options));
  }

  if (isMethodEnabled(selected_methods, "clins")) {
    if (imu_samples.empty()) {
      results.push_back(makeSkippedResult(
          "CLINS", "imu.csv not found. CLINS requires synchronized IMU samples."));
    } else {
      std::cout << "Running CLINS..." << std::endl;
      results.push_back(runCLINS(pcd_dirs, gt, frame_timestamps, imu_samples,
                                 clins_options));
    }
  }

  fs::create_directories("dogfooding_results");
  const std::string artifact_stem = artifactStemFromPath(pcd_dir);
  const fs::path evaluated_gt_path =
      fs::path("dogfooding_results") / (artifact_stem + "_evaluated_gt.txt");
  const fs::path evaluation_manifest_path =
      fs::path("dogfooding_results") /
      (artifact_stem + "_evaluation_manifest.json");
  savePosesKITTI(gt, evaluated_gt_path.string());
  const fs::path legacy_gt_path = fs::path("dogfooding_results") / "gt.txt";
  bool legacy_gt_written = false;
  if (pathsEquivalentIfBothExist(fs::path(gt_csv), legacy_gt_path)) {
    std::cerr
        << "Warning: not overwriting legacy GT artifact because it is also "
        << "the input GT path: " << legacy_gt_path.string() << std::endl;
  } else {
    savePosesKITTI(gt, legacy_gt_path.string());
    legacy_gt_written = true;
  }

  // 結果表示
  std::cout << "\n========================================" << std::endl;
  std::cout << "  RESULTS (Real Data)" << std::endl;
  std::cout << "========================================" << std::endl;
  std::cout << std::left
            << std::setw(24) << "Method"
            << std::setw(12) << "Status"
            << std::setw(12) << "ATE [m]"
            << std::setw(15) << "Drift[m/100m]"
            << std::setw(12) << "Frames"
            << std::setw(15) << "Time [ms]"
            << std::setw(12) << "FPS"
            << std::endl;
  std::cout << std::string(102, '-') << std::endl;

  for (auto& r : results) {
    if (r.skipped) {
      std::cout << std::setw(24) << r.name
                << std::setw(12) << r.status
                << std::setw(12) << "-"
                << std::setw(15) << "-"
                << std::setw(12) << "-"
                << std::setw(15) << "-"
                << std::setw(12) << "-"
                << std::endl;
      continue;
    }

    r.ate = computeATE(r.poses, gt);
    const RPEMetrics rpe = computeRPE(r.poses, gt, rpeSegmentLengthM(dist));
    r.has_rpe = rpe.available;
    if (rpe.available) {
      r.rpe_trans_pct = rpe.trans_pct;
      r.rpe_rot_deg_per_m = rpe.rot_deg_per_m;
    }
    r.kitti_rte = computeKittiRTE(r.poses, gt);
    if (!std::isfinite(r.ate) ||
        (r.has_rpe && (!std::isfinite(r.rpe_trans_pct) ||
                       !std::isfinite(r.rpe_rot_deg_per_m)))) {
      r.status = "invalid_metric";
    }
    double fps = r.time_ms > 0.0 ? r.poses.size() / (r.time_ms / 1000.0) : 0.0;
    std::ostringstream drift_ss;
    if (r.has_rpe && std::isfinite(r.rpe_trans_pct)) {
      drift_ss << std::fixed << std::setprecision(3) << r.rpe_trans_pct;
    } else {
      drift_ss << "-";
    }
    std::cout << std::setw(24) << r.name
              << std::setw(12) << r.status
              << std::setw(12) << std::setprecision(3) << r.ate
              << std::setw(15) << drift_ss.str()
              << std::setw(12) << r.poses.size()
              << std::setw(15) << std::setprecision(1) << r.time_ms
              << std::setw(12) << std::setprecision(1) << fps
              << std::endl;

    std::string fname = r.name;
    std::replace(fname.begin(), fname.end(), '-', '_');
    savePosesKITTI(r.poses, "dogfooding_results/" + fname + ".txt");
  }

  bool printed_notes = false;
  for (const auto& r : results) {
    if (!r.note.empty()) {
      if (!printed_notes) {
        std::cout << "\nNotes:" << std::endl;
        printed_notes = true;
      }
      std::cout << "- " << r.name << ": " << r.note << std::endl;
    }
  }

  const std::string evaluator_commit = evaluatorGitCommit();
  writeSummaryJson(evaluation_manifest_path.string(), pcd_dir, gt_csv,
                   gt_sha256, evaluated_gt_path.string(),
                   legacy_gt_path.string(), legacy_gt_written,
                   evaluation_manifest_path.string(), evaluator_commit,
                   total_pcd_frames, pcd_dirs.size(), gt_poses_raw.size(),
                   frame_timestamps, gt_poses_raw, gt_association, dist,
                   frame_timestamp_source, gt_format, gt_time_domain,
                   association_max_dt, results);

  if (!summary_json_path.empty() &&
      !pathsEquivalentIfBothExist(fs::path(summary_json_path),
                                  evaluation_manifest_path)) {
    writeSummaryJson(summary_json_path, pcd_dir, gt_csv, gt_sha256,
                     evaluated_gt_path.string(), legacy_gt_path.string(),
                     legacy_gt_written, evaluation_manifest_path.string(),
                     evaluator_commit, total_pcd_frames, pcd_dirs.size(),
                     gt_poses_raw.size(), frame_timestamps, gt_poses_raw,
                     gt_association, dist, frame_timestamp_source, gt_format,
                     gt_time_domain, association_max_dt, results);
  }

  std::cout << "\nResults saved to dogfooding_results/"
            << " (evaluated GT: " << evaluated_gt_path.string()
            << ", manifest: " << evaluation_manifest_path.string() << ")"
            << std::endl;
  return 0;
}
